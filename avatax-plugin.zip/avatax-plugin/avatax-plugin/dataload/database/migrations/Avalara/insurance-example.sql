-- EXAMPLE ONLY Landed cost fixed cost insurance configuration begin
insert into calcode (
CALCODE_ID, CODE, CALUSAGE_ID, STOREENT_ID, PUBLISHED, SEQUENCE, COMBINATION, CALMETHOD_ID, CALMETHOD_ID_APP, CALMETHOD_ID_QFY, DESCRIPTION, DISPLAYLEVEL, STARTDATE, ENDDATE, FLAGS
) values (
10152, 'AvalaraInsurance', -6, 10201, 1, 0, 0, 
-707060103, 
-707060104, 
-707060102, 
'Calcode for calculate insurance for crossborder shippings',
0,
'2004-01-01 00:00:00.0',
'2999-12-31 23:59:59.0',
0
);

insert into calmethod (calmethod_id, storeent_id, calusage_id, taskname, description, subclass, name) 
values (10001, -1, -6, 'com.ac.commerce.tax.commands.ACCalculationRuleQualifyCmd', 'Avalara Insurance example', 6, 'ACCalculationRuleQualifyCmd');

insert into calrule (calrule_id, calcode_id, startdate, enddate, sequence, combination, calmethod_id, calmethod_id_qfy, flags, identifier)
values (10151, 10152, '1900-01-01 00:00:00.0', '9999-12-15 23:59:59.0', 0, 0, -707060107, 10001, 1, 1);

insert into calscale (calscale_id, code, description, storeent_id, calusage_id, calmethod_id)
values (10151, 'AvalaraInsurance', 'Avalara insurance example', 10201, -6, -707060108);

insert into calrange (calrange_id, calscale_id, calmethod_id, rangestart, cumulative, markfordelete) values (
10150, 10151, -707060110, 0, 0, 0);


insert into CRULESCALE (calscale_id, calrule_id) values(10151, 10151);

insert into calrlookup (calrlookup_id, setccurr, calrange_id, value) values 
(10151, 'USD', 10150, 11);


INSERT INTO STENCALUSG (STOREENT_ID,CALUSAGE_ID,ACTCC_CALMETHOD_ID,ACTRC_CALMETHOD_ID,CALCODE_ID,CALMETHOD_ID_APP,CALMETHOD_ID_SUM,CALMETHOD_ID_FIN,USAGEFLAGS,CALMETHOD_ID_INI,SEQUENCE,OPTCOUNTER)
  VALUES (10201,-6,-707060101,-707060105,10152,-707060112,-707060113,NULL,1,-707060111,0.1,1);

--EXAMPLE ONLY Landed cost fixed cost insurance configuration begin
