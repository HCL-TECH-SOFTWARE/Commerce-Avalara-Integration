--to make workaround with countries work properly
update STLOC set country = 'United States' where country = 'USA';
update address set country = 'United States' where country = 'USA';
--to make workaround with countries work properly

--to prevent intersection of orders and return ids
update keys set lowerbound = 5000000000000, counter = 5000000000001 where tablename = 'rma';

--- Calcualtion framework customization for tax calcualtion  




    
INSERT INTO CALMETHOD (CALMETHOD_ID, STOREENT_ID, CALUSAGE_ID,
  TASKNAME, DESCRIPTION, SUBCLASS, NAME)
  VALUES (1001, 10201, -3, 'com.ac.commerce.tax.commands.ACAvalaraApplyCalculationUsageCmd',
    'Avalara tax plugin.', 12, 'ACAvalaraApplyCalculationUsageCmd');
    
INSERT INTO CALMETHOD (CALMETHOD_ID, STOREENT_ID, CALUSAGE_ID,
  TASKNAME, DESCRIPTION, SUBCLASS, NAME)
  VALUES (1002, 10201, -3, 'com.ac.commerce.tax.commands.ACAvalaraInitializeSalesTaxCmd',
    'Avalara tax plugin.', 11, 'Cleanup custom data');        
    
INSERT INTO STENCALUSG (STOREENT_ID, CALUSAGE_ID, ACTCC_CALMETHOD_ID,
  ACTRC_CALMETHOD_ID, CALCODE_ID, CALMETHOD_ID_APP, CALMETHOD_ID_SUM,
  CALMETHOD_ID_FIN, USAGEFLAGS, CALMETHOD_ID_INI, SEQUENCE)
  VALUES (10201, -3, -41, -45, NULL, 1001, -223, NULL, 1, 1002,
    3.0);


  
-----------------
  
INSERT into CMDREG (STOREENT_ID, INTERFACENAME, DESCRIPTION, CLASSNAME, TARGET, PROPERTIES) values(10201,
'com.ibm.commerce.inventory.commands.ReleaseManifestCmd','Release Manifestwith Avalara Commit',
'com.ac.commerce.inventory.commands.ACReleaseManifestCmdImpl',
'Local', 'retriable=1');
    
INSERT into CMDREG (STOREENT_ID, INTERFACENAME, DESCRIPTION, CLASSNAME, TARGET) values(10201,
'com.ibm.commerce.order.commands.OrderProcessCmd','OrderProcessCmd Extension',
'com.ac.commerce.order.commands.ACOrderProcessCmdImpl',
'Local');
--------------  
 INSERT into CMDREG (STOREENT_ID, INTERFACENAME, DESCRIPTION, CLASSNAME, TARGET) values(10201,
'com.ibm.commerce.usermanagement.commands.PostUserRegistrationUpdateCmd','PostUserRegistrationAddCmd Extension',
'com.ac.commerce.usermanagement.commands.ACPostUserRegistrationAvalaraUpdateCmdImpl',
'Local');
 INSERT into CMDREG (STOREENT_ID, INTERFACENAME, DESCRIPTION, CLASSNAME, TARGET) values(10201,
'com.ibm.commerce.usermanagement.commands.PostUserRegistrationAddCmd','PostUserRegistrationAddCmd Extension',
'com.ac.commerce.usermanagement.commands.ACPostUserRegistrationAvalaraAddCmdImpl',
'Local');

  
CREATE TABLE X_AVATAX_CONF (
	STOREENT_ID BIGINT NOT NULL,
	URLTOCONNECT VARCHAR(255) NOT NULL,
	ACCNUM VARCHAR(128) NOT NULL,
	COMPANYCODE VARCHAR(128) NOT NULL,
	TAXCALCULATIONMODE VARCHAR(32) NOT NULL,
	TRANSACTIONLOGGING SMALLINT NOT NULL,
	TRANSLOGKEEPHOURS INTEGER,
	SUPPORTEDCOUNTRIES VARCHAR(255),
	TAXCOUNTRIES VARCHAR(800),
	ADDROUNTRIES VARCHAR(800),
	BEHAVIORONERROR VARCHAR(32) NOT NULL,
	DEFAULTTAX DECIMAL(5,2) NOT NULL,
	ADDRVALIDATIONPLACES VARCHAR(255),
	CUSTOMERVATID SMALLINT NOT NULL,
	PRICECONTAINSTAXES SMALLINT NOT NULL,
	ORDERITEMTAXESDISPLAYED SMALLINT NOT NULL DEFAULT 0,
	LOGREQUESTTYPES VARCHAR(255),
	AUTHKEY VARCHAR(128) NOT NULL,
	TAXCODEIDENTIFIER VARCHAR(128),
	DAPCOUNTRIES VARCHAR(800),
	DDPCOUNTRIES VARCHAR(800), 	
	OPTCOUNTER 	SMALLINT NOT NULL DEFAULT 0,
	CONSTRAINT X_AVATAX_CONF_PK PRIMARY KEY(STOREENT_ID), 
	CONSTRAINT X_AVATAX_CONF_FK FOREIGN KEY (STOREENT_ID) REFERENCES STOREENT(STOREENT_ID) ON DELETE CASCADE
);


CREATE TABLE X_AVATAX_DTL (
	ORDERS_ID BIGINT,
	ORDERITEMS_ID BIGINT,
	TYPE VARCHAR(3),
	TAXTYPE VARCHAR(125),
	TAXNAME VARCHAR(125),	
	TAXABLE VARCHAR(25),
	RATE VARCHAR(25),	
	TAX VARCHAR(25),
	NONTAXABLE VARCHAR(25),
	EXEMPTION VARCHAR(25),
	CONSTRAINT X_AVATAX_DTL_ORD_FK FOREIGN KEY (ORDERS_ID) REFERENCES ORDERS(ORDERS_ID) ON DELETE CASCADE,
	CONSTRAINT X_AVATAX_DTL_ORDI_FK FOREIGN KEY (ORDERITEMS_ID) REFERENCES ORDERITEMS(ORDERITEMS_ID) ON DELETE CASCADE
);		

CREATE TABLE X_AVATAX_SHPMDDTL (
	SHIPMODE_ID INTEGER NOT NULL,
	MODE VARCHAR(25),
	TAX_CODE VARCHAR(25),
	IS_EXPRESS VARCHAR(1),
	CONSTRAINT X_AVATAX_SHPMDDTL_YN	check (IS_EXPRESS in ('Y','N')),
	CONSTRAINT X_AVATAX_SHPMDDTL_PK PRIMARY KEY(SHIPMODE_ID),	
	CONSTRAINT X_AVATAX_SHPMDDTL_FK FOREIGN KEY (SHIPMODE_ID) REFERENCES SHIPMODE(SHIPMODE_ID) ON DELETE CASCADE
);
		


CREATE TABLE X_AVATAX_USERS (
	ADDRESS_ID BIGINT NOT NULL,
	CUSTOMERVATID VARCHAR(255) NOT NULL,
	CONSTRAINT X_AVATAX_USERS_PK PRIMARY KEY(ADDRESS_ID)
);


INSERT into CMDREG (STOREENT_ID, INTERFACENAME, DESCRIPTION, CLASSNAME, TARGET) values(10201,
'com.ibm.commerce.tools.optools.order.commands.CSROrderCancelCmd','CancelProcessCmd Extension',
'com.ac.commerce.order.commands.ACCSROrderCancelCmdImpl',
'Local');

INSERT into CMDREG (STOREENT_ID, INTERFACENAME, DESCRIPTION, CLASSNAME, TARGET) values(10201,
'com.ibm.commerce.returns.commands.CalculateReturnTaxCmd','Calculate taxes for return',
'com.ac.commerce.returns.commands.ACCalculateReturnTaxCmdImpl',
'Local');


INSERT into CMDREG (STOREENT_ID, INTERFACENAME, DESCRIPTION, CLASSNAME, TARGET) values(10201,
'com.ibm.commerce.returns.commands.ExtendReturnCancelCmd','Cancel avalara transaction when return is cancelled',
'com.ac.commerce.returns.commands.ACExtendReturnCancelCmdImpl',
'Local');

INSERT into CMDREG (STOREENT_ID, INTERFACENAME, DESCRIPTION, CLASSNAME, TARGET, PROPERTIES) values(10201,
'com.ibm.commerce.returns.commands.ExtendReturnProcessCmd','Return process extention for commit document at avalara side',
'com.ac.commerce.returns.commands.ACAvalaraExtendReturnProcessCmdImpl',
'Local', 'retriable=1');

INSERT into CMDREG (STOREENT_ID, INTERFACENAME, DESCRIPTION, CLASSNAME, TARGET, PROPERTIES) values(10201,
'com.ibm.commerce.returns.commands.AdminReturnApproveCmd','Manual Approve of return for commit document at avalara side',
'com.ac.commerce.returns.commands.ACAvalaraAdminReturnApproveCmdImpl',
'Local', 'retriable=1');


CREATE TABLE X_AVATAX_MBRGRP (
	MBRGRP_ID BIGINT NOT NULL,
	TAX_CODE VARCHAR(255),
	OPTCOUNTER 	SMALLINT  DEFAULT 0,
	CONSTRAINT X_AVATAX_MGRGRP_PK PRIMARY KEY(MBRGRP_ID), 
	CONSTRAINT X_AVATAX_MGRGRP_FK FOREIGN KEY (MBRGRP_ID) REFERENCES MBRGRP(MBRGRP_ID) ON DELETE CASCADE
);


-------------------

UPDATE CMDREG SET CLASSNAME='com.ac.commerce.member.facade.server.commands.ACChangeMemberGroupCmdImpl' where 
INTERFACENAME='com.ibm.commerce.member.facade.server.commands.ChangeMemberGroupCmd';

UPDATE CMDREG SET CLASSNAME='com.ac.commerce.member.facade.server.commands.ACChangeMemberGroupBasePartCmdImpl' where
INTERFACENAME='com.ibm.commerce.member.facade.server.commands.ChangeMemberGroupPartActionCmd+/MemberGroup[]';

INSERT into CMDREG (STOREENT_ID, INTERFACENAME, CLASSNAME, TARGET) values(10201,
'com.ibm.commerce.member.facade.server.commands.ComposeMemberGroupFromDataBeanCmd+IBM_Admin_Details',
'com.ac.commerce.member.facade.server.commands.ACComposeMemberGroupFromDataBeanDetailCmdImpl',
'Local');



insert into cmdreg(STOREENT_ID,INTERFACENAME,CLASSNAME, TARGET)
values(10201,'com.ibm.commerce.order.commands.GetOrderTotalAmountCmd',
'com.ac.commerce.order.commands.ACGetOrderTotalAmountCmdImpl','Local');


insert into cmdreg(STOREENT_ID,INTERFACENAME,CLASSNAME, TARGET)
values(10201,'com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmd',
'com.ac.commerce.order.commands.ACGetOrderItemsTotalAmountCmdImpl','Local');


insert into cmdreg(STOREENT_ID,INTERFACENAME,CLASSNAME, TARGET)
values(10201,'com.ibm.commerce.order.commands.GetHistoryOrderTotalAmountCmd',
'com.ac.commerce.order.commands.ACGetHistoryOrderTotalAmountCmdImpl','Local');


insert into cmdreg(STOREENT_ID,INTERFACENAME,CLASSNAME, TARGET)
values(10201,'com.ibm.commerce.order.commands.GetOrderReleaseTotalAmountCmd',
'com.ac.commerce.order.commands.ACGetOrderReleaseTotalAmountCmdImpl','Local');

UPDATE CMDREG SET CLASSNAME='com.ac.commerce.order.commands.ACOrderProfileUpdateCmdImpl' where
INTERFACENAME='com.ibm.commerce.order.commands.OrderProfileUpdateCmd';
