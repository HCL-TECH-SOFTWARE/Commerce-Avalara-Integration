# ac-avatax-logic

Task Migrate to v9 ( migrate EJB references to new JPA Beans)

1)  Replace ServerJDBCHelperAccessBean jdbcHelper = new ServerJDBCHelperAccessBean();
with  ServerJDBCHelperBean jdbcHelper = new ServerJDBCHelperBean();

2)  Change refreshCopyHelper(); to instantiateEntity();  This isn't needed the JPA. So it is now commented out.

3)  Change 'InEJBType' to 'InEntityType'