package com.ac.commerce.usermanagement.commands;

import java.io.IOException;
import java.util.ArrayList;

import net.avalara.avatax.rest.client.AvaTaxClient;
import net.avalara.avatax.rest.client.enums.ResolutionQuality;
import net.avalara.avatax.rest.client.enums.TextCase;
import net.avalara.avatax.rest.client.models.AddressInfo;
import net.avalara.avatax.rest.client.models.AddressResolutionModel;
import net.avalara.avatax.rest.client.models.AddressValidationInfo;
import net.avalara.avatax.rest.client.models.AvaTaxMessage;
import net.avalara.avatax.rest.client.models.ValidatedAddressInfo;

import org.apache.commons.json.JSONObject;
import org.apache.commons.lang3.StringUtils;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.settings.ACAvalaraConstants;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ac.avalara.utility.ACAvalaraUtils;
import com.ac.avatax.rest.logger.AvalaraLogger;
import com.ac.avatax.rest.logger.AvalaraLoggerSettings;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.command.ControllerCommandImpl;
import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.ras.ECMessage;
import com.ibm.commerce.ras.ECMessageHelper;

/**
 * This class is called when we make an Ajax call to action
 * AjaxAvalaraAddVerify. It's used to validate the address entered by user.
 * Internally it calls AvalaraTaxUtils.validateAddress method to verify address.
 * 
 * @author askosyr
 */
@SuppressWarnings("serial")
public class ACAvalaraAddressVerificationCmdImpl extends ControllerCommandImpl implements ACAvalaraAddressVerificationCmd {

	private static final String CLASSNAME = ACAvalaraAddressVerificationCmdImpl.class.getName();
	private static final ACLogger LOGGER = new ACLogger(ACAvalaraAddressVerificationCmdImpl.class);
	private static final AvalaraLogger AVA_LOGGER =  new AvalaraLogger();	
	private static final String ZIP_CODE_KEY = "zipcode";
	private static final String DEFAULT_ZIPCODE_US_PATTERN = "(^\\d{5}(?:[-\\s]\\d{4})?$)|(^\\d{9}$)";
	private static final String UNDEFINED_ERROR_MESSAGE = "Some information is incorrect in your address(es). Please re-check your address data and try again. If the problem persists please contact us via Live Chat or call (888) 818-7283.";	
	private ACAvalaraSettings settings;
	private AvalaraLoggerSettings loggerSettings;

	@Override
	public void performExecute() throws ECException {
		String methodName = "performExecute";
		// tracing method entry
		LOGGER.entering(methodName);
		AVA_LOGGER.init(loggerSettings);
		TypedProperty rspProp = new TypedProperty();
		AddressValidationInfo address = null;
		try {
			TypedProperty requestProps = getRequestProperties();
			String country = requestProps.getString(ACAvalaraConstants.COUNTRY);
			String countries = this.settings.getAddrCountries();
			if (null != countries && countries.contains(country)) {
				address = createAddress(requestProps);

				AvaTaxClient client = ACAvalaraUtils.getAvaTaxClient(settings);
				

				
				if (loggerSettings.isLogEnabled() && loggerSettings.isLogValidateAddressRequest()){				
					AVA_LOGGER.log("Requesting URL: " + settings.getUrl());
					AVA_LOGGER.log("Request parameter: " + address);
				}
				AddressResolutionModel response = null;
				try {
					response = client.resolveAddressPost(address);
				} catch (IOException e) {
					LOGGER.error(methodName, "IOException during avalara connect: " + e);
					response = getDefaultResponse(address);
					
				}
				if (loggerSettings.isLogEnabled() && loggerSettings.isLogValidateAddressRequest()){					
					AVA_LOGGER.log("Response: " + response);
				}					
				
				if (isErrorsInResponse(response)) {
					LOGGER.error(methodName, String.valueOf(response.getMessages()));
					rspProp.put("messages", response.getMessages());
				}

				/* AddressResolutionModel uses GSON and not JSON. 
				 * Not entirely sure if this is the root cause of the problem. Will Investigate it in future.
				 */
				
				JSONObject responseObject = new JSONObject(response.toString());
				
				rspProp.put("avaResponse", responseObject);

				LOGGER.info(methodName, "normalized addresses: {0}", response);
			} else {
				LOGGER.trace(methodName, "Skipping address validation since country {0} is not configured for validation for current store ", country);
			}
		} catch (Exception e) {
			LOGGER.error(methodName, e.getMessage(), e);
			rspProp.put("Exception", StringUtils.isEmpty(e.getMessage()) ? UNDEFINED_ERROR_MESSAGE : e.getMessage());
		}

		setResponseProperties(rspProp);
		LOGGER.exiting(methodName);
	}

	private AddressResolutionModel getDefaultResponse(AddressValidationInfo address) {
		String methodName = "getDefaultResponse";
		LOGGER.entering(methodName);
		AddressResolutionModel retval = new AddressResolutionModel();
		AddressInfo addressInfo = new AddressInfo();
		addressInfo.setCity(address.getCity());
		addressInfo.setCountry(address.getCountry());
		addressInfo.setLatitude(address.getLatitude());
		addressInfo.setLine1(address.getLine1());
		addressInfo.setLine2(address.getLine2());
		addressInfo.setLine3(address.getLine3());
		addressInfo.setLongitude(address.getLongitude());
		addressInfo.setPostalCode(address.getPostalCode());
		addressInfo.setRegion(address.getRegion());					
		retval.setAddress(addressInfo);
		retval.setResolutionQuality(ResolutionQuality.NotCoded);
		ArrayList<ValidatedAddressInfo> validatedAddresses = new ArrayList<>();
		ValidatedAddressInfo validatedAddress = new ValidatedAddressInfo();
		validatedAddress.setAddressType("SameAsInputCausedByIOError");
		validatedAddress.setCity(address.getCity());
		validatedAddress.setCountry(address.getCountry());
		validatedAddress.setLatitude(address.getLatitude());
		validatedAddress.setLine1(address.getLine1());
		validatedAddress.setLine2(address.getLine2());
		validatedAddress.setLine3(address.getLine3());
		validatedAddress.setLongitude(address.getLongitude());
		validatedAddress.setPostalCode(address.getPostalCode());
		validatedAddress.setRegion(address.getRegion());
		validatedAddresses.add(validatedAddress);
		retval.setValidatedAddresses(validatedAddresses);
		
		LOGGER.exiting(methodName);
		return retval;
	}

	private boolean isErrorsInResponse(AddressResolutionModel response) {
		if (null != response.getMessages()) {
			for (AvaTaxMessage message : response.getMessages()) {
				if ("Error".equals(message.getSeverity())) {
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public void validateParameters() throws ECException {
		String methodName = "validateParameters";
		LOGGER.entering(methodName);
		super.validateParameters();

		TypedProperty requestProps = getRequestProperties();


			ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
			bean.setCommandContext(getCommandContext());
			try {
				bean.populate();
			} catch (Exception e) { 
				LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
				throw new ECApplicationException(ECMessage._ERR_GENERIC, CLASSNAME, methodName, new Object[] { e.getMessage() });
			}

			this.settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);
			this.loggerSettings = ACAvalaraSettingsUtils.loadAvalaraLoggerSettings(bean);
			String country =  requestProps.getString(ACAvalaraConstants.COUNTRY);
			String countries = this.settings.getAddrCountries();
			if (null != requestProps && null!= countries && countries.contains(country)) {
				if (requestProps.containsKey(ZIP_CODE_KEY)) {
					Integer storeId = commandContext == null ? null : commandContext.getStoreId();
					String zipCodePattern = ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.ZIP_CODE_PATTERN + requestProps.getString(ACAvalaraConstants.COUNTRY));
					if (zipCodePattern == null || StringUtils.isEmpty(zipCodePattern.trim())) {
						zipCodePattern = DEFAULT_ZIPCODE_US_PATTERN;
					}
					String zipCode = requestProps.getString(ZIP_CODE_KEY, "");
					if (zipCode != null && StringUtils.isNotEmpty(zipCode.trim()) && !zipCode.matches(zipCodePattern)) {
						throw new ECApplicationException(new ECMessage("_ERR_CMD_INVALID_PARAM.5140"), new Object[]{});
					}
					
				}
			}
		LOGGER.exiting(methodName);
	}

	private AddressValidationInfo createAddress(TypedProperty typedProperty) {
		AddressValidationInfo address = new AddressValidationInfo();

		// setting user input address from typedProperty to address object
		address.setLine1(typedProperty.getString("address1", ""));
		address.setLine2(typedProperty.getString("address2", ""));
		address.setCity(typedProperty.getString("city", ""));
		address.setRegion(typedProperty.getString("state", ""));
		address.setCountry(typedProperty.getString("country", ""));
		address.setPostalCode(typedProperty.getString("zipcode", ""));
		address.setTextCase(TextCase.Mixed);
		return address;
	}

	@Override
	public boolean isGeneric() {
		return true;
	}

}
