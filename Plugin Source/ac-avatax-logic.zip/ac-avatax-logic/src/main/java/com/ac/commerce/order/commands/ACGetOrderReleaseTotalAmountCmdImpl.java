package com.ac.commerce.order.commands;

import java.math.BigDecimal;
import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.exception.ECSystemException;
import com.ibm.commerce.inventory.objects.OrderReleaseTotalsAccessBean;
import com.ibm.commerce.order.commands.GetOrderReleaseTotalAmountCmd;
import com.ibm.commerce.order.commands.GetOrderReleaseTotalAmountCmdImpl;
import com.ibm.commerce.ras.ECMessage;
import com.ibm.commerce.ras.ECTrace;

public class ACGetOrderReleaseTotalAmountCmdImpl extends
		GetOrderReleaseTotalAmountCmdImpl implements
		GetOrderReleaseTotalAmountCmd {
	private static String CLASS_NAME = "com.ac.commerce.order.commands.ACGetOrderReleaseTotalAmountCmdImpl";
	private OrderReleaseTotalsAccessBean iabOrderReleaseTotals[];
	private BigDecimal idTotalAmount;

	public ACGetOrderReleaseTotalAmountCmdImpl() {
		iabOrderReleaseTotals = null;

		idTotalAmount = new BigDecimal(0);
	}

	public void performExecute() throws ECException {
		String methodName = "performExecute";
		if (ECTrace.traceEnabled(3L))
			ECTrace.entry(
					3L,
					CLASS_NAME,
					methodName);

		try {
			if (iabOrderReleaseTotals != null
					&& iabOrderReleaseTotals.length > 0) {

				ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
				bean.setCommandContext(commandContext);
				bean.populate();
				ACAvalaraSettings settings = ACAvalaraSettingsUtils
						.loadAvalaraGeneralSettings(bean);

				BigDecimal totalProduct = BigDecimal.valueOf(0L);
				BigDecimal totalBaseShipping = BigDecimal.valueOf(0L);
				BigDecimal totalSalesTax = BigDecimal.valueOf(0L);
				BigDecimal totalShippingTax = BigDecimal.valueOf(0L);
				BigDecimal totalAdjustment = BigDecimal.valueOf(0L);

				for (int i = 0; i < iabOrderReleaseTotals.length; i++)
					if (iabOrderReleaseTotals[i] != null)
						if (iabOrderReleaseTotals[i].getChargeType().equals(
								"totalAdjustment"))
							totalAdjustment = iabOrderReleaseTotals[i]
									.getAmountInEntityType();
						else if (iabOrderReleaseTotals[i].getChargeType()
								.equals("totalProduct"))
							totalProduct = iabOrderReleaseTotals[i]
									.getAmountInEntityType();
						else if (iabOrderReleaseTotals[i].getChargeType()
								.equals("baseShippingCharge"))
							totalBaseShipping = iabOrderReleaseTotals[i]
									.getAmountInEntityType();
						else if (iabOrderReleaseTotals[i].getChargeType()
								.equals("shippingTax"))
							totalShippingTax = iabOrderReleaseTotals[i]
									.getAmountInEntityType();
						else if (iabOrderReleaseTotals[i].getChargeType()
								.equals("salesTax"))
							totalSalesTax = iabOrderReleaseTotals[i]
									.getAmountInEntityType();

				if (settings.getTaxIncluded()) {
					idTotalAmount = idTotalAmount.add(totalAdjustment)
							.add(totalProduct).add(totalBaseShipping);
				} else {
					idTotalAmount = idTotalAmount.add(totalAdjustment)
							.add(totalProduct).add(totalBaseShipping)
							.add(totalShippingTax).add(totalSalesTax);
				}
				ECTrace.trace(
						3L,
						CLASS_NAME,
						methodName,
						(new StringBuilder("idTotalAmount = ")).append(
								idTotalAmount).toString());
			}
		} catch (CreateException e) {
			throw new ECSystemException(
					ECMessage._ERR_CREATE_EXCEPTION,
					"com.ibm.commerce.orderitems.commands.GetOrderReleaseTotalAmountCmdImpl",
					"performExecute", new Object[] { e.toString() }, e);
		} catch (FinderException e) {
			throw new ECSystemException(
					ECMessage._ERR_FINDER_EXCEPTION,
					"com.ibm.commerce.orderitems.commands.GetOrderReleaseTotalAmountCmdImpl",
					"performExecute", new Object[] { e.toString() }, e);
		} catch (NamingException e) {
			throw new ECSystemException(
					ECMessage._ERR_NAMING_EXCEPTION,
					"com.ibm.commerce.orderitems.commands.GetOrderReleaseTotalAmountCmdImpl",
					"performExecute", new Object[] { e.toString() }, e);
		} catch (RemoteException e) {
			throw new ECSystemException(
					ECMessage._ERR_REMOTE_EXCEPTION,
					"com.ibm.commerce.orderitems.commands.GetOrderReleaseTotalAmountCmdImpl",
					"performExecute", new Object[] { e.toString() }, e);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (ECTrace.traceEnabled(3L))
			ECTrace.exit(
					3L,
					CLASS_NAME,
					methodName);

	}

	public void reset() {
		super.reset();
		iabOrderReleaseTotals = null;
		idTotalAmount = new BigDecimal(0);
	}

	public OrderReleaseTotalsAccessBean[] getOrderReleaseTotalsAccessBean() {
		return iabOrderReleaseTotals;
	}

	public BigDecimal getTotalAmount() {
		return idTotalAmount;
	}

	public void setOrderReleaseTotals(
			OrderReleaseTotalsAccessBean abOrderReleaseTotals[]) {
		iabOrderReleaseTotals = abOrderReleaseTotals;
	}
}
