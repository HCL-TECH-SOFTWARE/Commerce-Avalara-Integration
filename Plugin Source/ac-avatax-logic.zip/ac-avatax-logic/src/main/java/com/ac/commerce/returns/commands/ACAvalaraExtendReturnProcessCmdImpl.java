package com.ac.commerce.returns.commands;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ac.commerce.order.commands.ACAvalaraCommitTransactionTaskCmd;
import com.ac.commerce.util.CommandFactory;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.ordermanagement.objects.RMAAccessBean;
import com.ibm.commerce.returns.commands.ExtendReturnProcessCmd;
import com.ibm.commerce.returns.commands.ExtendReturnProcessCmdImpl;

public class ACAvalaraExtendReturnProcessCmdImpl extends ExtendReturnProcessCmdImpl implements ExtendReturnProcessCmd {
	private final ACLogger LOGGER = new ACLogger(ACAvalaraExtendReturnProcessCmdImpl.class);
	private RMAAccessBean rma;

	@Override
	public void performExecute() throws ECException {
		String methodName = "performExecute";
		super.performExecute();

		ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
		bean.setCommandContext(commandContext);
		try {
			bean.populate();
		} catch (Exception e) {

			LOGGER.error(methodName, "Error occured while loading avatax configuration:" + e.getMessage());
		}
		ACAvalaraSettings settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);

		if (settings.isTaxSubmissionEnabled()) {
			try {
				if ("APP".equals(rma.getStatus())) {
					ACAvalaraCommitTransactionTaskCmd task = CommandFactory.createTask(ACAvalaraCommitTransactionTaskCmd.class, commandContext);
					task.setOrderId(rma.getRmaIdInEntityType());
					task.execute();
				}
			} catch (Exception e) {
				throw new ECApplicationException(e);
			}
		}
	}

	@Override
	public void setRMAAB(RMAAccessBean anRMAAB) {
		super.setRMAAB(anRMAAB);
		this.rma = anRMAAB;
	}
}
