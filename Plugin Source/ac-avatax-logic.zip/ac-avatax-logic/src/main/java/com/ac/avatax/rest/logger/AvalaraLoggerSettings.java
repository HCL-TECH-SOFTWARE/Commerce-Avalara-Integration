package com.ac.avatax.rest.logger;

public class AvalaraLoggerSettings {

	private String fileName;
	private String directory;
	private int hoursToKeepLogs = 24;
	private boolean logEnabled = true;
	private boolean logPingRequest = true;
	private boolean logValidateAddressRequest = true;
	private boolean logCalculateRequest = true;
	private boolean logCancelRequest = true;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getDirectory() {
		return directory;
	}

	public void setDirectory(String directory) {
		this.directory = directory;
	}

	public int getHoursToKeepLogs() {
		return hoursToKeepLogs;
	}

	public void setHoursToKeepLogs(int hoursToKeepLogs) {
		this.hoursToKeepLogs = hoursToKeepLogs;
	}

	public boolean isLogPingRequest() {
		return logPingRequest;
	}

	public void setLogPingRequest(boolean logPingRequest) {
		this.logPingRequest = logPingRequest;
	}

	public boolean isLogValidateAddressRequest() {
		return logValidateAddressRequest;
	}

	public void setLogValidateAddressRequest(boolean logValidateAddressRequest) {
		this.logValidateAddressRequest = logValidateAddressRequest;
	}

	public boolean isLogCalculateRequest() {
		return logCalculateRequest;
	}

	public void setLogCalculateRequest(boolean logCalculateRequest) {
		this.logCalculateRequest = logCalculateRequest;
	}


	public boolean isLogCancelRequest() {
		return logCancelRequest;
	}

	public void setLogCancelRequest(boolean logCancelRequest) {
		this.logCancelRequest = logCancelRequest;
	}

	public boolean isLogEnabled() {
		return logEnabled;
	}

	public void setLogEnabled(boolean logEnabled) {
		this.logEnabled = logEnabled;
	}
	
}
