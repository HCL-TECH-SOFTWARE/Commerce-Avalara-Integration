/**
 */
package com.ac.commerce.infrastructure.facade.server.entity.datatypes;

import java.math.BigDecimal;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Xavatax conf</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getStoreent_id <em>Storeent id</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getUrltoconnect <em>Urltoconnect</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getAccnum <em>Accnum</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getCompanycode <em>Companycode</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTaxcalculationmode <em>Taxcalculationmode</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTransactionlogging <em>Transactionlogging</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTranslogkeephours <em>Translogkeephours</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getSupportedcountries <em>Supportedcountries</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTaxcountries <em>Taxcountries</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getAddrountries <em>Addrountries</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getBehavioronerror <em>Behavioronerror</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getDefaulttax <em>Defaulttax</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getAddrvalidationplaces <em>Addrvalidationplaces</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getCustomervatid <em>Customervatid</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getPricecontainstaxes <em>Pricecontainstaxes</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getOitaxesdisplayed <em>Oitaxesdisplayed</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getLogrequesttypes <em>Logrequesttypes</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getAuthkey <em>Authkey</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTaxcodeidentifier <em>Taxcodeidentifier</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getDapcountries <em>Dapcountries</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getDdpcountries <em>Ddpcountries</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getOptcounter <em>Optcounter</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getStoreentForX_avatax_conf <em>Storeent For Xavatax conf</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf()
 * @model
 * @generated
 */
public interface X_avatax_conf
{
  /**
   * Returns the value of the '<em><b>Storeent id</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Storeent id</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Storeent id</em>' attribute.
   * @see #setStoreent_id(int)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Storeent_id()
   * @model
   * @generated
   */
  int getStoreent_id();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getStoreent_id <em>Storeent id</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Storeent id</em>' attribute.
   * @see #getStoreent_id()
   * @generated
   */
  void setStoreent_id(int value);

  /**
   * Returns the value of the '<em><b>Urltoconnect</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Urltoconnect</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Urltoconnect</em>' attribute.
   * @see #setUrltoconnect(String)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Urltoconnect()
   * @model unique="false"
   * @generated
   */
  String getUrltoconnect();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getUrltoconnect <em>Urltoconnect</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Urltoconnect</em>' attribute.
   * @see #getUrltoconnect()
   * @generated
   */
  void setUrltoconnect(String value);

  /**
   * Returns the value of the '<em><b>Accnum</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Accnum</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Accnum</em>' attribute.
   * @see #setAccnum(String)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Accnum()
   * @model unique="false"
   * @generated
   */
  String getAccnum();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getAccnum <em>Accnum</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Accnum</em>' attribute.
   * @see #getAccnum()
   * @generated
   */
  void setAccnum(String value);

  /**
   * Returns the value of the '<em><b>Companycode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Companycode</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Companycode</em>' attribute.
   * @see #setCompanycode(String)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Companycode()
   * @model unique="false"
   * @generated
   */
  String getCompanycode();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getCompanycode <em>Companycode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Companycode</em>' attribute.
   * @see #getCompanycode()
   * @generated
   */
  void setCompanycode(String value);

  /**
   * Returns the value of the '<em><b>Taxcalculationmode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Taxcalculationmode</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Taxcalculationmode</em>' attribute.
   * @see #setTaxcalculationmode(String)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Taxcalculationmode()
   * @model unique="false"
   * @generated
   */
  String getTaxcalculationmode();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTaxcalculationmode <em>Taxcalculationmode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Taxcalculationmode</em>' attribute.
   * @see #getTaxcalculationmode()
   * @generated
   */
  void setTaxcalculationmode(String value);

  /**
   * Returns the value of the '<em><b>Transactionlogging</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Transactionlogging</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Transactionlogging</em>' attribute.
   * @see #setTransactionlogging(short)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Transactionlogging()
   * @model unique="false"
   * @generated
   */
  short getTransactionlogging();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTransactionlogging <em>Transactionlogging</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Transactionlogging</em>' attribute.
   * @see #getTransactionlogging()
   * @generated
   */
  void setTransactionlogging(short value);

  /**
   * Returns the value of the '<em><b>Translogkeephours</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Translogkeephours</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Translogkeephours</em>' attribute.
   * @see #setTranslogkeephours(Integer)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Translogkeephours()
   * @model unique="false"
   * @generated
   */
  Integer getTranslogkeephours();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTranslogkeephours <em>Translogkeephours</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Translogkeephours</em>' attribute.
   * @see #getTranslogkeephours()
   * @generated
   */
  void setTranslogkeephours(Integer value);

  /**
   * Returns the value of the '<em><b>Supportedcountries</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Supportedcountries</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Supportedcountries</em>' attribute.
   * @see #setSupportedcountries(String)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Supportedcountries()
   * @model unique="false"
   * @generated
   */
  String getSupportedcountries();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getSupportedcountries <em>Supportedcountries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Supportedcountries</em>' attribute.
   * @see #getSupportedcountries()
   * @generated
   */
  void setSupportedcountries(String value);

  /**
   * Returns the value of the '<em><b>Taxcountries</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Taxcountries</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Taxcountries</em>' attribute.
   * @see #setTaxcountries(String)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Taxcountries()
   * @model unique="false"
   * @generated
   */
  String getTaxcountries();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTaxcountries <em>Taxcountries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Taxcountries</em>' attribute.
   * @see #getTaxcountries()
   * @generated
   */
  void setTaxcountries(String value);

  /**
   * Returns the value of the '<em><b>Addrountries</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Addrountries</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Addrountries</em>' attribute.
   * @see #setAddrountries(String)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Addrountries()
   * @model unique="false"
   * @generated
   */
  String getAddrountries();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getAddrountries <em>Addrountries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Addrountries</em>' attribute.
   * @see #getAddrountries()
   * @generated
   */
  void setAddrountries(String value);

  /**
   * Returns the value of the '<em><b>Behavioronerror</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Behavioronerror</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Behavioronerror</em>' attribute.
   * @see #setBehavioronerror(String)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Behavioronerror()
   * @model unique="false"
   * @generated
   */
  String getBehavioronerror();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getBehavioronerror <em>Behavioronerror</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Behavioronerror</em>' attribute.
   * @see #getBehavioronerror()
   * @generated
   */
  void setBehavioronerror(String value);

  /**
   * Returns the value of the '<em><b>Defaulttax</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Defaulttax</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Defaulttax</em>' attribute.
   * @see #setDefaulttax(BigDecimal)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Defaulttax()
   * @model unique="false"
   * @generated
   */
  BigDecimal getDefaulttax();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getDefaulttax <em>Defaulttax</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Defaulttax</em>' attribute.
   * @see #getDefaulttax()
   * @generated
   */
  void setDefaulttax(BigDecimal value);

  /**
   * Returns the value of the '<em><b>Addrvalidationplaces</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Addrvalidationplaces</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Addrvalidationplaces</em>' attribute.
   * @see #setAddrvalidationplaces(String)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Addrvalidationplaces()
   * @model unique="false"
   * @generated
   */
  String getAddrvalidationplaces();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getAddrvalidationplaces <em>Addrvalidationplaces</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Addrvalidationplaces</em>' attribute.
   * @see #getAddrvalidationplaces()
   * @generated
   */
  void setAddrvalidationplaces(String value);

  /**
   * Returns the value of the '<em><b>Customervatid</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Customervatid</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Customervatid</em>' attribute.
   * @see #setCustomervatid(short)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Customervatid()
   * @model unique="false"
   * @generated
   */
  short getCustomervatid();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getCustomervatid <em>Customervatid</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Customervatid</em>' attribute.
   * @see #getCustomervatid()
   * @generated
   */
  void setCustomervatid(short value);

  /**
   * Returns the value of the '<em><b>Pricecontainstaxes</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Pricecontainstaxes</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Pricecontainstaxes</em>' attribute.
   * @see #setPricecontainstaxes(short)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Pricecontainstaxes()
   * @model unique="false"
   * @generated
   */
  short getPricecontainstaxes();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getPricecontainstaxes <em>Pricecontainstaxes</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Pricecontainstaxes</em>' attribute.
   * @see #getPricecontainstaxes()
   * @generated
   */
  void setPricecontainstaxes(short value);

  /**
   * Returns the value of the '<em><b>Oitaxesdisplayed</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Oitaxesdisplayed</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Oitaxesdisplayed</em>' attribute.
   * @see #setOitaxesdisplayed(short)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Oitaxesdisplayed()
   * @model unique="false"
   * @generated
   */
  short getOitaxesdisplayed();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getOitaxesdisplayed <em>Oitaxesdisplayed</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Oitaxesdisplayed</em>' attribute.
   * @see #getOitaxesdisplayed()
   * @generated
   */
  void setOitaxesdisplayed(short value);

  /**
   * Returns the value of the '<em><b>Logrequesttypes</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Logrequesttypes</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Logrequesttypes</em>' attribute.
   * @see #setLogrequesttypes(String)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Logrequesttypes()
   * @model unique="false"
   * @generated
   */
  String getLogrequesttypes();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getLogrequesttypes <em>Logrequesttypes</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Logrequesttypes</em>' attribute.
   * @see #getLogrequesttypes()
   * @generated
   */
  void setLogrequesttypes(String value);

  /**
   * Returns the value of the '<em><b>Authkey</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Authkey</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Authkey</em>' attribute.
   * @see #setAuthkey(String)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Authkey()
   * @model unique="false"
   * @generated
   */
  String getAuthkey();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getAuthkey <em>Authkey</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Authkey</em>' attribute.
   * @see #getAuthkey()
   * @generated
   */
  void setAuthkey(String value);

  /**
   * Returns the value of the '<em><b>Taxcodeidentifier</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Taxcodeidentifier</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Taxcodeidentifier</em>' attribute.
   * @see #setTaxcodeidentifier(String)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Taxcodeidentifier()
   * @model unique="false"
   * @generated
   */
  String getTaxcodeidentifier();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTaxcodeidentifier <em>Taxcodeidentifier</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Taxcodeidentifier</em>' attribute.
   * @see #getTaxcodeidentifier()
   * @generated
   */
  void setTaxcodeidentifier(String value);

  /**
   * Returns the value of the '<em><b>Dapcountries</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Dapcountries</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Dapcountries</em>' attribute.
   * @see #setDapcountries(String)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Dapcountries()
   * @model unique="false"
   * @generated
   */
  String getDapcountries();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getDapcountries <em>Dapcountries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Dapcountries</em>' attribute.
   * @see #getDapcountries()
   * @generated
   */
  void setDapcountries(String value);

  /**
   * Returns the value of the '<em><b>Ddpcountries</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Ddpcountries</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Ddpcountries</em>' attribute.
   * @see #setDdpcountries(String)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Ddpcountries()
   * @model unique="false"
   * @generated
   */
  String getDdpcountries();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getDdpcountries <em>Ddpcountries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Ddpcountries</em>' attribute.
   * @see #getDdpcountries()
   * @generated
   */
  void setDdpcountries(String value);

  /**
   * Returns the value of the '<em><b>Optcounter</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Optcounter</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Optcounter</em>' attribute.
   * @see #setOptcounter(short)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_Optcounter()
   * @model unique="false"
   * @generated
   */
  short getOptcounter();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getOptcounter <em>Optcounter</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Optcounter</em>' attribute.
   * @see #getOptcounter()
   * @generated
   */
  void setOptcounter(short value);

  /**
   * Returns the value of the '<em><b>Storeent For Xavatax conf</b></em>' reference.
   * It is bidirectional and its opposite is '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACStoreent#getX_avatax_confForStoreent <em>Xavatax conf For Storeent</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Storeent For Xavatax conf</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Storeent For Xavatax conf</em>' reference.
   * @see #setStoreentForX_avatax_conf(ACStoreent)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getX_avatax_conf_StoreentForX_avatax_conf()
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACStoreent#getX_avatax_confForStoreent
   * @model opposite="X_avatax_confForStoreent" resolveProxies="false"
   * @generated
   */
  ACStoreent getStoreentForX_avatax_conf();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getStoreentForX_avatax_conf <em>Storeent For Xavatax conf</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Storeent For Xavatax conf</em>' reference.
   * @see #getStoreentForX_avatax_conf()
   * @generated
   */
  void setStoreentForX_avatax_conf(ACStoreent value);

} // X_avatax_conf
