package com.ac.avalara.settings;

public class ACAvalaraConstants {
	public static final String LOG_REQUEST_TYPE = "LOG_REQUEST_TYPE";
	public static final String VAT_ID_CONFIGURATION_ENABLED = "VAT_ID_CONFIGURATION_ENABLED";
	public static final String BEHAVIOUR_ON_ERROR = "BEHAVIOUR_ON_ERROR";
	public static final String TAX_CALCULATION_MODE = "TAX_CALCULATION_MODE";
	public static String AVALARA_TAX_PROPERTIES = "com.ac.tax.avalara.avatax";
	public static String API_URL = "URL";
	public static String API_ACCOUNT = "ACCOUNT";
	public static String API_AUTH_KEY = "AUTH_KEY";
	public static String API_COMPANYCODE = "COMPANY_CODE";
	public static String API_TIMEOUT = "TIMEOUT_REQUEST";
	public static String API_ADDRESS_VALIDATION_URL = "ADDRESS_VALIDATION_URL";
	public static String API_HEADER_USER_AGENT="HEADER_USER_AGENT";
	public static String API_CALCULATION_URL="CALCULATION_URL";
	public static String API_RECORD_URL="RECORD_URL";
	public static String API_STATE_TRANSITIONS_URL = "STATE_TRANSITIONS_URL";
	
	public static String PING_ADDRESS1="PING_ADDRESS1";
	public static String PING_COUNTRY="PING_COUNTRY";
	public static String PING_STATE="PING_STATE";
	public static String PING_CITY="PING_CITY";
	public static String PING_ZIP_CODE="PING_ZIP_CODE";
	
	public static String ZIP_CODE_PATTERN = "ZIP_CODE_PATTERN_";
	
	public static String COUNTRY = "country";
	
	public static String LOG_DIRECTORY = "LOG_DIRECTORY";
	public static String LOG_FILENAME = "LOG_FILENAME";
	public static String LOG_KEEP_HOURS = "LOG_KEEP_HOURS";
	
	public static String MULTIPLE_FULFILLMENT_CENTER = "MULTIPLE_FULFILLMENT_CENTER";
	
	public static String DEFAULT_ADDRESS_LINE1 = "DEFAULT_ADDRESS_LINE1";
	public static String DEFAULT_ADDRESS_LINE2 = "DEFAULT_ADDRESS_LINE2";
	public static String DEFAULT_ADDRESS_CITY = "DEFAULT_ADDRESS_CITY";
	public static String DEFAULT_ADDRESS_STATE = "DEFAULT_ADDRESS_STATE";
	public static String DEFAULT_ADDRESS_COUNTRY = "DEFAULT_ADDRESS_COUNTRY";
	public static String DEFAULT_ADDRESS_ZIP_CODE = "DEFAULT_ADDRESS_ZIP_CODE";
	
	public static String DEFAULT_TAX_RATE = "DEFAULT_TAX_RATE";
	
	public static String AVATAX_COMMIT_ON_ORDER_STATUS = "AVATAX_COMMIT_ON_ORDER_STATUS";
	
	public static String TAX_INCLUDED = "TAX_INLUDED";
	public static String CUSTOMER_VAT_ID = "AvalaraVatBinID";
	public static String ADDRESS_VALIDATION_COUNTRY_SUPPORT = "ADDRESS_VALIDATION_COUNTRY_SUPPORT";
	public static String LANDED_COST_DAP_COUNTRY_SUPPORT = "LANDED_COST_DAP_COUNTRY_SUPPORT";
	public static String LANDED_COST_DDP_COUNTRY_SUPPORT = "LANDED_COST_DDP_COUNTRY_SUPPORT";
	
	public static final String DISABLED_TAX_CALCULATION = "DISABLE";
	public static final String ENABLE_CALCULATION_TAX = "ENABLE_WITHOUT_TAX";
	public static final String ENABLE_SUBMITTING_TAX = "ENABLE_WITH_TAX";
	public static final String TAX_CODE_IDENTIFIER = "TAX_CODE_IDENTIFIER";
	public static final String AVALARA_HTS_ATTRIBUTE_PREFIX = "AVALARA_HTS_ATTRIBUTE_PREFIX";
	public static final String AVALARA_LANDED_COST_UNITAMOUNT_PREFIX = "AVALARA_LANDED_COST_UNITAMOUNT_PREFIX";
	public static final String AVALARA_LANDED_COST_UNITNAME_PREFIX = "AVALARA_LANDED_COST_UNITNAME_PREFIX";
	
	
	
	
	public static final String PRICES_INCLUDE_TAXES = "PRICES_INCLUDE_TAXES";
	public static final String ENABLE_TAX_DISPLAY_FOR_LINE_ITEM = "ENABLE_TAX_DISPLAY_FOR_LINE_ITEM";
	
	public static final String CLNT_APP_NAME = "a0o5a0000064fBFAAY";
	public static final String CLNT_APP_VERSION = "HCLCommerce-V9.x";
	
}
