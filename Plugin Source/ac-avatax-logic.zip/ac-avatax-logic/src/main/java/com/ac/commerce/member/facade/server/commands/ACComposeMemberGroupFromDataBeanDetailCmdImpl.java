package com.ac.commerce.member.facade.server.commands;

import com.ac.avalara.order.bean.ACAvalaraTaxCodeBean;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.foundation.common.datatypes.CommerceFoundationFactory;
import com.ibm.commerce.foundation.common.datatypes.UserDataType;
import com.ibm.commerce.member.facade.datatypes.MemberGroupType;
import com.ibm.commerce.member.facade.server.commands.ComposeMemberGroupFromDataBeanCmd;
import com.ibm.commerce.member.facade.server.commands.ComposeMemberGroupFromDataBeanDetailCmdImpl;
import com.ibm.websphere.command.CommandException;

public class ACComposeMemberGroupFromDataBeanDetailCmdImpl extends
		ComposeMemberGroupFromDataBeanDetailCmdImpl implements
		ComposeMemberGroupFromDataBeanCmd {

	private static final ACLogger LOGGER = new ACLogger(ACChangeMemberGroupBasePartCmdImpl.class);
	public static final String TAXCODE_USERDATA_FIELD = "taxcode";

	@Override
	public void execute() throws CommandException {
		String METHODNAME = "execute()";
		LOGGER.entering(METHODNAME);
		
		super.execute();
		MemberGroupType memberGroup = getMemberGroup();
		try {
			ACAvalaraTaxCodeBean bean = new ACAvalaraTaxCodeBean();
			bean.setSegmentId(memberGroup.getMemberGroupIdentifier().getUniqueID());
			bean.populate();
			
			if (bean.getTaxCode() != null && !bean.getTaxCode().isEmpty()){
				if (memberGroup.getUserData() == null){
					UserDataType userData = CommerceFoundationFactory.eINSTANCE.createUserDataType();
					memberGroup.setUserData(userData);
				}
				memberGroup.getUserData().getUserDataField().put(TAXCODE_USERDATA_FIELD, bean.getTaxCode());
			}
		} catch (Exception e){
			LOGGER.error(METHODNAME, "Error occured while populating tax code value: " + e.getMessage());
		}
		LOGGER.exiting(METHODNAME);
	}

	
	
}
