package com.ac.commerce.tax.commands;

import com.ac.avalara.order.bean.ACAvalaraTaxDetailsDataBean;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.order.calculation.InitializeSalesTaxCmdImpl;
import com.ibm.commerce.ras.ECMessageHelper;

public class ACAvalaraInitializeSalesTaxCmdImpl extends InitializeSalesTaxCmdImpl implements ACAvalaraInitializeSalesTaxCmd {
	private final ACLogger LOGGER = new ACLogger(ACAvalaraInitializeSalesTaxCmdImpl.class);

	@Override
	public void performExecute() throws ECException {
		String methodName = "performExecute";
		super.performExecute();
		
		LOGGER.entering(methodName);
		ACAvalaraTaxDetailsDataBean bean = new ACAvalaraTaxDetailsDataBean();
		try {
			bean.setOrderId(getOrder().getOrderIdInEntityType());
			bean.cleanupEntireOrder();
		} catch (ECException e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw e;
		} catch (Exception e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw new ECApplicationException(e);
		}
		LOGGER.exiting(methodName);
	}
}
