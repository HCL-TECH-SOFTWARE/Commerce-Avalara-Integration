package com.ac.commerce.order.commands;

import com.ac.avalara.settings.ACAvalaraSettings;
import com.ibm.commerce.command.TaskCommand;
import com.ibm.commerce.order.calculation.Item;

public interface ACAvalaraTaxCalculationFallbackCmd extends TaskCommand{
	String defaultCommandClassName = ACAvalaraTaxCalculationFallbackCmdImpl.class.getName();
	void setItems(Item[] items);
	void setConfigurationSettings(ACAvalaraSettings settings);
}
