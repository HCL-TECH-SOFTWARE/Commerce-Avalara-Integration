package com.ac.avalara.order.bean;

public enum ACAvalaraTaxDetailsType {
	SHP, //shipping taxes
	LN, //line taxes
	CF, //Landed Cost DDP Customs fee
	CD, //Landed Cost DAP Customs duties
	DAP//Landed Cost DAP details
}
