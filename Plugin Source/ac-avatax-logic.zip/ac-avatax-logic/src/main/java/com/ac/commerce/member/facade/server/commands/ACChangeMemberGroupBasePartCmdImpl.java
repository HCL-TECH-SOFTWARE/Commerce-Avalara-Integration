package com.ac.commerce.member.facade.server.commands;

import java.util.List;

import com.ac.avalara.order.bean.ACAvalaraTaxCodeBean;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.component.contextservice.ActivityToken;
import com.ibm.commerce.component.contextservice.BusinessContextService;
import com.ibm.commerce.component.contextservice.BusinessContextServiceFactory;
import com.ibm.commerce.component.contextserviceimpl.BusinessContextInternalService;
import com.ibm.commerce.foundation.common.exception.AbstractApplicationException;
import com.ibm.commerce.member.facade.datatypes.impl.MemberGroupTypeImpl;
import com.ibm.commerce.member.facade.server.commands.ChangeMemberGroupBasePartCmdImpl;
import com.ibm.commerce.member.internal.persistence.MemberGroupPersistenceManager;
import com.ibm.commerce.user.objects.MemberGroupAccessBean;

public class ACChangeMemberGroupBasePartCmdImpl extends
		ChangeMemberGroupBasePartCmdImpl {

	private static final ACLogger LOGGER = new ACLogger(ACChangeMemberGroupBasePartCmdImpl.class);
	
	@Override
	protected void change(Object noun, Object nounPart, List controlParameters)
			throws AbstractApplicationException {
		String METHODNAME = "change(Object, Object, List)";
		Object value = ((MemberGroupTypeImpl)noun).getUserData().getUserDataField().get(ACComposeMemberGroupFromDataBeanDetailCmdImpl.TAXCODE_USERDATA_FIELD);
		if (value != null){
			try {
				ACAvalaraTaxCodeBean bean = new ACAvalaraTaxCodeBean();
				bean.setTaxCode(String.valueOf(value));
				bean.setSegmentId(((MemberGroupTypeImpl)noun).getMemberGroupIdentifier().getUniqueID());
				bean.update();
				BusinessContextService service = BusinessContextServiceFactory.getBusinessContextService();
				ActivityToken actToken = ((BusinessContextInternalService)service).getActivityToken();
				String memberGroupId = ((MemberGroupTypeImpl)noun).getMemberGroupIdentifier().getUniqueID();
				MemberGroupAccessBean mbrgrpAccessBean = new MemberGroupAccessBean();
				mbrgrpAccessBean.setInitKey_memberId(memberGroupId);
//				mbrgrpAccessBean.instantiateEntity();
				MemberGroupPersistenceManager.changeMemberGroupName(memberGroupId, mbrgrpAccessBean.getMbrGrpName(), actToken);
			} catch (Exception e) {
				LOGGER.error(METHODNAME, "Error occured while changing member group bean " + e.getMessage());
			}
		} else {
			super.change(noun, nounPart, controlParameters);
		}
	}

	@Override
	protected void add(Object noun, Object nounPart, List controlParameters)
			throws AbstractApplicationException {
		// TODO Auto-generated method stub
		super.add(noun, nounPart, controlParameters);
	}



	@Override
	protected void validateChange(Object noun, Object nounPart,
			List controlParameters) throws AbstractApplicationException {
		super.validateChange(noun, nounPart, controlParameters);
	}

	@Override
	public void performExecute() throws Exception {
		super.performExecute();
	}
	
	

}
