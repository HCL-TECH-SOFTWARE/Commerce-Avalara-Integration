package com.ac.avalara.order.bean;

import java.util.Vector;

import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.base.objects.ServerJDBCHelperBean;
import com.ibm.commerce.beans.SmartDataBean;
import com.ibm.commerce.beans.SmartDataBeanImpl;
import com.ibm.commerce.user.objects.AddressAccessBean;


public class ACAvalaraUsersDataBean extends SmartDataBeanImpl implements
		SmartDataBean {

	private String addressId;
	private String customerVatId;
	private static final ACLogger LOGGER = new ACLogger(ACAvalaraUsersDataBean.class);
	
	@Override
	public void populate() throws Exception {
		String methodName = "populate()";
		try {
			if (addressId == null){
				AddressAccessBean aab = new AddressAccessBean().findSelfAddressByMember(getCommandContext().getUserId());
				if (aab != null){
					addressId = aab.getAddressId();
				}
			}
			if (addressId != null){
				ServerJDBCHelperBean jdbcHelper = new ServerJDBCHelperBean();
				
	            Vector<Vector<?>> vRecords = jdbcHelper.executeQuery(String.format("select * from X_AVATAX_USERS where ADDRESS_ID=%d", Long.valueOf(addressId)));
	            if (vRecords != null && !vRecords.isEmpty()) {
	                for (Vector<?> oRecord : vRecords) {
	                	this.customerVatId = (String) oRecord.get(1);
	                }
	            } else {
	            	this.customerVatId = "";
	            }
			} else {
				this.customerVatId = "";
			}
		}catch (Exception e){
			LOGGER.error(methodName, "Error occured while getting custom avatax users information " + e.getMessage());
		}
	}
	
	public void update() throws Exception {
		String methodName = "update()";
		try {
			if (addressId != null){
				ServerJDBCHelperBean jdbcHelper = new ServerJDBCHelperBean();
				
	            Vector<Vector<?>> vRecords = jdbcHelper.executeQuery("select * from X_AVATAX_USERS where ADDRESS_ID=" + addressId);
	            if (vRecords != null && !vRecords.isEmpty()) {
	            	if (null != customerVatId) {
	            		jdbcHelper.executeUpdate(String.format("update X_AVATAX_USERS set CUSTOMERVATID='%s' where ADDRESS_ID = %d", customerVatId, Long.valueOf(addressId)));	            		
	            	} else {
	            		jdbcHelper.executeUpdate(String.format("delete from X_AVATAX_USERS where ADDRESS_ID = %d", Long.valueOf(addressId)));
	            	}
	            } else if (customerVatId != null){
	            	jdbcHelper.executeUpdate(String.format("insert into X_AVATAX_USERS(ADDRESS_ID, CUSTOMERVATID) VALUES(%d, '%s')", Long.valueOf(addressId), customerVatId));
	            }
			}
		}catch (Exception e){
			LOGGER.error(methodName, "Error occured while updating custom avatax users information " + e.getMessage());
		}
	}

	public String getAddressId() {
		return addressId;
	}

	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}

	public String getCustomerVatId() {
		return customerVatId;
	}

	public void setCustomerVatId(String customerVatId) {
		this.customerVatId = customerVatId;
	}

}
