package com.ac.commerce.order.commands;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.settings.ACAvalaraConstants;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ac.avalara.utility.ACAvalaraTaxUtils;
import com.ac.avalara.utility.ACAvalaraUtils;
import com.ac.avatax.rest.logger.AvalaraLoggerSettings;
import com.ac.commerce.util.CommandFactory;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.order.calculation.Item;
import com.ibm.commerce.order.commands.OrderProcessCmdImpl;
import com.ibm.commerce.order.objects.OrderAccessBean;
import com.ibm.commerce.ras.ECMessageHelper;

/**
 * This class extends OrderProcessCmdImpl to implement avalara tax plugin. It
 * makes a call to Avalara to calculate taxes.
 * 
 * @author askosyr
 */
@SuppressWarnings("serial")
public class ACOrderProcessCmdImpl extends OrderProcessCmdImpl {
	private static final ACLogger LOGGER = new ACLogger(ACOrderProcessCmdImpl.class);

	@Override
	public void performExecute() throws ECException {
		String methodName = "performExecute";
		LOGGER.entering(methodName);

		super.performExecute();

		ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
		bean.setCommandContext(commandContext);
		try {
			bean.populate();
		} catch (Exception e) {
			LOGGER.error(methodName, "Error occured while loading avatax configuration:" + e.getMessage());
		}
		ACAvalaraSettings settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);
		AvalaraLoggerSettings loggerSettings = ACAvalaraSettingsUtils.loadAvalaraLoggerSettings(bean);
		
		try {
			for (OrderAccessBean order : this.getOrders()) {
//				order.instantiateEntity();
				Long orderId = order.getOrderIdInEntityType();
				
				if(settings.isTaxSubmissionEnabled()) {
					Item[] items = ACAvalaraUtils.getItemBeans(order.getOrderItems());
					ACAvalaraTaxUtils.createOrAdjustSaleAndSubmit(items, getCommandContext(), settings, loggerSettings);
				
					if (ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.AVATAX_COMMIT_ON_ORDER_STATUS).equals(order.getStatus())) {
						ACAvalaraCommitTransactionTaskCmd task = CommandFactory.createTask(ACAvalaraCommitTransactionTaskCmd.class, commandContext);
						task.setOrderId(orderId);
						task.execute();
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
		}

		LOGGER.exiting(methodName);
	}
}
