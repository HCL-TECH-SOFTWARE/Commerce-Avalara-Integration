package com.ac.commerce.order.commands;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import com.ac.avalara.order.bean.ACAvalaraTaxDetails;
import com.ac.avalara.order.bean.ACAvalaraTaxDetailsDataBean;
import com.ac.avalara.order.bean.ACAvalaraTaxDetailsType;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.command.TaskCommandImpl;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.order.calculation.Item;

public class ACAvalaraTaxCalculationFallbackCmdImpl extends TaskCommandImpl implements ACAvalaraTaxCalculationFallbackCmd{
	private static final ACLogger LOGGER = new ACLogger(ACAvalaraTaxCalculationFallbackCmdImpl.class);
	
	private ACAvalaraSettings settings;

	private Item[] items;
	
	public void setItems(Item[] items) {
		this.items = items;
	}
	                    
	@Override
	public void performExecute() throws ECException {
		final String methodName = "performExecute";
		LOGGER.entering(methodName);
		super.performExecute();
		if (!settings.isTaxCalculationEnabled()) {
			LOGGER.exiting(methodName);
			LOGGER.trace(methodName, "Tax calculation is disabled. Exiting...");
			return;
		}
        // Method uses defaultTaxRate value in property file to calculate default tax in case of exception from Avalara side.
		BigDecimal defaultTaxRate = BigDecimal.ZERO;
		if (settings.isErrorSetDefaultTax()){
			defaultTaxRate = settings.getDefaultTaxRate();
			defaultTaxRate = defaultTaxRate.divide(new BigDecimal(100.0d), 2, RoundingMode.HALF_UP);
		}
        LOGGER.trace(methodName, "defaultTaxRate used in case of exception: {0}", defaultTaxRate);
        
        for (Item item : items) {
            Long orderId = null;
            Long orderItemId = null;
            try {
                orderId = item.getOrderItem().getOrderIdInEntityType();
                orderItemId = item.getOrderItemId();
                BigDecimal orderItemTax = defaultTaxRate.multiply(item.getProductTotal().add(item.getAdjustmentTotal().subtract(item.getAdjustmentTotal(-7))));
                item.setSalesTaxTotal(orderItemTax.setScale(2, BigDecimal.ROUND_HALF_UP));
                
                if (item.getShippingTotal().compareTo(BigDecimal.ZERO) > 0) {
                    BigDecimal orderItemShippingTax = defaultTaxRate.multiply(item.getShippingTotal().add(item.getAdjustmentTotal(-7)));
                    item.setShippingTaxTotal(orderItemShippingTax.setScale(2, BigDecimal.ROUND_HALF_UP));
                }
                
                
				ACAvalaraTaxDetailsDataBean detailsDataBean = new ACAvalaraTaxDetailsDataBean();
				detailsDataBean.setOrderId(orderId);
				detailsDataBean.setOrderItemId(orderItemId);
				List<ACAvalaraTaxDetails> details = new ArrayList<ACAvalaraTaxDetails>();
				
				ACAvalaraTaxDetails itemDetail = new ACAvalaraTaxDetails();
				itemDetail.setOrderId(orderId);
				itemDetail.setOrderItemId(orderItemId);
				itemDetail.setRate(String.valueOf(defaultTaxRate));
				itemDetail.setTax(String.valueOf(item.getSalesTaxTotal()));
				itemDetail.setTaxtype("FAIL-DEFAULT");
				itemDetail.setTaxname("Default");
				itemDetail.setType(ACAvalaraTaxDetailsType.LN);
				details.add(itemDetail);
				
				
				ACAvalaraTaxDetails shipDetail = new ACAvalaraTaxDetails();
				shipDetail.setOrderId(orderId);
				shipDetail.setOrderItemId(orderItemId);
				shipDetail.setRate(String.valueOf(defaultTaxRate));
				shipDetail.setTax(String.valueOf(item.getShippingTaxTotal()));				
				shipDetail.setTaxtype("FAIL-DEFAULT");
				shipDetail.setTaxname("Default");
				shipDetail.setType(ACAvalaraTaxDetailsType.SHP);
				details.add(shipDetail);
				
				detailsDataBean.setDetails(details);
				detailsDataBean.update();
                
                
            } catch (Exception e) {
                LOGGER.error(methodName, "Exception on calculating default tax for order " + orderId, e);
                throw new ECApplicationException(e);
            }
        }

		LOGGER.exiting(methodName);
	}

	@Override
	public void setConfigurationSettings(ACAvalaraSettings settings) {
		this.settings = settings;
	}

}
