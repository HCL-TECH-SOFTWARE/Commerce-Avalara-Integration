package com.ac.commerce.returns.commands;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.lang3.StringUtils;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ac.avalara.utility.ACAvalaraTaxUtils;
import com.ac.commerce.util.logging.ACLogger;
import com.ac.avatax.exception.AvalaraException;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.order.objects.OrderItemAccessBean;
import com.ibm.commerce.ordermanagement.objects.RMAItemAccessBean;
import com.ibm.commerce.price.utils.MonetaryAmount;
import com.ibm.commerce.ras.ECMessage;
import com.ibm.commerce.ras.ECMessageHelper;
import com.ibm.commerce.returns.commands.CalculateReturnTaxCmd;
import com.ibm.commerce.returns.commands.CalculateReturnTaxCmdImpl;

public class ACCalculateReturnTaxCmdImpl extends CalculateReturnTaxCmdImpl implements CalculateReturnTaxCmd {

	private static final String CLASS_NAME = ACCalculateReturnTaxCmdImpl.class.getName();
	private final ACLogger LOGGER = new ACLogger(ACCalculateReturnTaxCmdImpl.class);

	private Vector iRMAItemABVector = null;
	private Set<String> ordersId = new HashSet<String>();
	private ACAvalaraSettings settings;
	private String rmaId;
	private Vector taxCredits;

	protected Vector getRMAItemABs() {
		return this.iRMAItemABVector;
	}

	@Override
	public void validateParameters() throws ECException {
		String methodName = "validateParameters";
		super.validateParameters();
		LOGGER.entering(methodName);

		ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
		bean.setCommandContext(commandContext);
		try {
			bean.populate();
		} catch (Exception e) {
			LOGGER.error(methodName, "Error occured while loading avatax configuration:" + e.getMessage());
		}
		this.settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);

		
		this.ordersId = new HashSet<String>();
		
		try {
			for (RMAItemAccessBean rmaItem : (Vector<RMAItemAccessBean>) this.iRMAItemABVector) {
				if (!StringUtils.isEmpty(rmaItem.getOrderItemsId())) {
					OrderItemAccessBean orderItemAB = new OrderItemAccessBean();
					orderItemAB.setInitKey_orderItemId(rmaItem.getOrderItemsId());
					this.ordersId.add(orderItemAB.getOrderId());
					this.rmaId = rmaItem.getRmaId();
				}
			}
		} catch (Exception e) {
			LOGGER.error(methodName, "Error occured while verifying orders information:" + ECMessageHelper.getExceptionStackTrace(e));
			throw new ECApplicationException(ECMessage._ERR_BAD_MISSING_CMD_PARAMETER, CLASS_NAME, methodName, new Object[] { "Error getting data about orders" });
		}

		if (this.ordersId.size() > 1) {
			LOGGER.error(methodName, "Avalara can return one order at time only. Please create one return per order");
			throw new ECApplicationException(ECMessage._ERR_BAD_MISSING_CMD_PARAMETER, CLASS_NAME, methodName, new Object[] { "ORDER_ID. Avalara plugin supports only one order_id per return. Please create one return per order" });
		}


		LOGGER.exiting(methodName);
	}

	@Override
	public Vector getTaxCredits() {		
		return this.taxCredits;
	}
	public void performExecute() throws ECException {
		String methodName = "performExecute";
		LOGGER.entering(methodName);

		super.performExecute();		
		
		
		List<String> orders = new ArrayList<String>(this.ordersId);
		try {
			if (this.settings.isTaxSubmissionEnabled()) {
				this.taxCredits = ACAvalaraTaxUtils.calculateAndSubmitReturnTax(this.iRMAItemABVector, commandContext, this.rmaId, orders.get(0));
			} else if (this.settings.isTaxCalculationEnabled()) {
				this.taxCredits = ACAvalaraTaxUtils.calculateOnlyReturnTax(this.iRMAItemABVector, commandContext, this.rmaId, orders.get(0));
			} else {
				this.taxCredits = new Vector<>(this.iRMAItemABVector.size());
				for(int i = 0; i < this.iRMAItemABVector.size(); i++) {
					this.taxCredits.add(new MonetaryAmount(BigDecimal.ZERO, ((RMAItemAccessBean)this.iRMAItemABVector.get(i)).getCurrency()));	
				}
			}
		} catch (AvalaraException e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			try {
				this.taxCredits = ACAvalaraTaxUtils.calculateReturnTaxDefault(this.iRMAItemABVector, commandContext, this.rmaId, orders.get(0));	
			} catch (Exception ee) {
				LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
				throw new ECApplicationException(ECMessage._ERR_GENERIC, CLASS_NAME, methodName, new String[] { "Exception occured while calculation default tax rates." + e.getMessage() });					
			}
		} catch (Exception e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw new ECApplicationException(e);
		}
		
		 LOGGER.exiting(methodName);
	}

	public void setRMAItemABs(Vector aRMAItemABVec) {
		super.setRMAItemABs(aRMAItemABVec);
		this.iRMAItemABVector = aRMAItemABVec;
	}

}
