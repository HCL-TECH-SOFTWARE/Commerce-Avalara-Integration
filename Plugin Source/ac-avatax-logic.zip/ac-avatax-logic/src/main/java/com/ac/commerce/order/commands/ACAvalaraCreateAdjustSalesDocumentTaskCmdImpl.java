package com.ac.commerce.order.commands;

import java.math.BigDecimal;
import java.util.Enumeration;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ac.avalara.utility.ACAvalaraTaxUtils;
import com.ac.avatax.exception.AvalaraException;
import com.ac.avatax.rest.logger.AvalaraLoggerSettings;
import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.exception.ACApplicationException;
import com.ibm.commerce.command.CommandFactory;
import com.ibm.commerce.command.TaskCommandImpl;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.order.calculation.Item;
import com.ibm.commerce.ras.ECMessage;
import com.ibm.commerce.ras.ECMessageHelper;
import com.ibm.commerce.ras.ECMessageSeverity;
import com.ibm.commerce.ras.ECMessageType;
import com.ibm.commerce.user.objects.AddressAccessBean;
import com.ibm.commerce.user.objects.UserAccessBean;

@SuppressWarnings("serial")
public class ACAvalaraCreateAdjustSalesDocumentTaskCmdImpl extends TaskCommandImpl implements ACAvalaraCreateAdjustSalesDocumentTaskCmd {

	private static final String CLASS_NAME = ACAvalaraCreateAdjustSalesDocumentTaskCmdImpl.class.getName();
	private static final ACLogger LOGGER = new ACLogger(ACAvalaraCreateAdjustSalesDocumentTaskCmdImpl.class);
	private Item[] items;
	static final String errorBundle = "avalaraStoreErrorMessages";
	public static final ECMessage _ERR_LANDED_COST_MULTIPLE_DESTINATION = new ECMessage(ECMessageSeverity.ERROR, ECMessageType.USER, "_ERR_LANDED_COST_MULTIPLE_DESTINATION", errorBundle);

	@Override
	public void performExecute() throws ECException {
		String methodName = "performExecute";
		LOGGER.entering(methodName);

		super.performExecute();

		try {
			UserAccessBean user = getCommandContext().getUser();
			if (null != user && "G".equals(user.getRegisterType())) {
				AddressAccessBean addressAccessBean = new AddressAccessBean();

				Enumeration addresses = addressAccessBean.findByMemberId(user.getMemberIdInEntityType());
				if (!addresses.hasMoreElements()) {
					LOGGER.info("Guest user {0} has no addresses. Skipping tax calculation", user.getMemberIdInEntityType());
					return;
				}
			}
		} catch (Exception e) {
			LOGGER.error(methodName, "Unable to get information about customer: " + ECMessageHelper.getExceptionStackTrace(e));
			throw new ACApplicationException(ECMessage._ERR_GENERIC, CLASS_NAME, methodName, true);
		}

		boolean fallbackRequired = false;
		ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
		bean.setCommandContext(commandContext);
		try {
			bean.populate();
		} catch (Exception e) {
			LOGGER.error(methodName, "Error occured while loading avatax configuration:" + e.getMessage());
		}
		ACAvalaraSettings settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);
		AvalaraLoggerSettings loggerSettings = ACAvalaraSettingsUtils.loadAvalaraLoggerSettings(bean);

		if (settings.isTaxCalculationEnabled()) {
			try {				
				ACAvalaraTaxUtils.createOrAdjustSaleCalculateOnly(this.items, getCommandContext(), settings, loggerSettings);			
			} catch (AvalaraException e) {
				if (settings.isStopCheckout()) {
					stopCheckout(e);
				} else if (settings.isErrorSetDefaultTax()) {
					setDefaultTax(settings);
				} else if (settings.isErrorSetZeroTax()) {
					setZeroTax();
				}
			}

		}

		LOGGER.exiting(methodName);
	}

	private void setZeroTax() {
		String methodName = "setZeroTax";
		LOGGER.entering(methodName);
		for (Item item : this.items) {
			item.setShippingTaxTotal(BigDecimal.ZERO);
			item.setSalesTaxTotal(BigDecimal.ZERO);
		}

		LOGGER.exiting(methodName);
	}

	private void setDefaultTax(ACAvalaraSettings settings) throws ECException {
		String methodName = "setDefaultTax";
		LOGGER.entering(methodName);
		ACAvalaraTaxCalculationFallbackCmd fallbackCmd = (ACAvalaraTaxCalculationFallbackCmd) CommandFactory.createCommand(ACAvalaraTaxCalculationFallbackCmd.class.getName(), getCommandContext().getStoreId());
		fallbackCmd.setItems(this.items);
		fallbackCmd.setCommandContext(getCommandContext());
		fallbackCmd.setConfigurationSettings(settings);
		fallbackCmd.execute();
		LOGGER.exiting(methodName);

	}

	private void stopCheckout(Exception e) throws ECApplicationException {
		String methodName = "stopCheckout";
		LOGGER.entering(methodName);
		LOGGER.error(methodName, "Stopping processing checkout. Error with avatax communication because of: " + e.getMessage());
		if ("_ERR_LANDED_COST_MULTIPLE_DESTINATION".equals(e.getMessage())) {
			throw new ECApplicationException(this._ERR_LANDED_COST_MULTIPLE_DESTINATION, CLASS_NAME, methodName, true);
		}
		throw new ECApplicationException(ECMessage._ERR_REMOTE_EXCEPTION, CLASS_NAME, methodName, new Object[] { e.getMessage() }, true);
	}

	@Override
	public void validateParameters() throws ECException {
		String methodName = "validateParameters";
		String orderId;
		super.validateParameters();
		if (null == this.items || 0 == this.items.length) {
			throw new ECApplicationException(ECMessage._ERR_BAD_CMD_PARAMETER, CLASS_NAME, methodName, new Object[] { " items " });
		}
		try {
			orderId = this.items[0].getOrderItem().getOrderId();
			for (Item item : this.items) {
				if (!orderId.equals(item.getOrderItem().getOrderId())) {
					LOGGER.error(methodName, "Command is not able to process items from different order simultaneously {0}", new Object[] { this.items });
					throw new ECApplicationException(ECMessage._ERR_BAD_CMD_PARAMETER, CLASS_NAME, methodName, new Object[] { "orderId in orderItems" });
				}
			}
		} catch (ECApplicationException e) {
			throw e;
		} catch (Exception e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw new ECApplicationException(ECMessage._ERR_GENERIC, CLASS_NAME, methodName);
		}
	}

	@Override
	public void setItems(Item[] items) {
		this.items = items;
	}

}
