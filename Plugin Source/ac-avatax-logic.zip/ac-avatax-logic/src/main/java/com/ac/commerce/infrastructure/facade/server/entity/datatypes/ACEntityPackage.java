/**
 */
package com.ac.commerce.infrastructure.facade.server.entity.datatypes;

import com.ibm.commerce.infrastructure.facade.server.entity.datatypes.InfrastructureEntityPackage;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityFactory
 * @model kind="package"
 * @generated
 */
public interface ACEntityPackage extends EPackage
{
  /**
   * The package name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNAME = "datatypes";

  /**
   * The package namespace URI.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_URI = "http://www.ibm.com/xmlns/prod/commerce/9/AC/entity";

  /**
   * The package namespace name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_PREFIX = "_ac";

  /**
   * The singleton instance of the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  ACEntityPackage eINSTANCE = com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACEntityPackageImpl.init();

  /**
   * The meta object id for the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACRootImpl <em>AC Root</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACRootImpl
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACEntityPackageImpl#getACRoot()
   * @generated
   */
  int AC_ROOT = 0;

  /**
   * The feature id for the '<em><b>Curlist</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__CURLIST = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__CURLIST;

  /**
   * The feature id for the '<em><b>Folder</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__FOLDER = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__FOLDER;

  /**
   * The feature id for the '<em><b>Folder Item</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__FOLDER_ITEM = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__FOLDER_ITEM;

  /**
   * The feature id for the '<em><b>Mbrrole</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__MBRROLE = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__MBRROLE;

  /**
   * The feature id for the '<em><b>Page Layout</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__PAGE_LAYOUT = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__PAGE_LAYOUT;

  /**
   * The feature id for the '<em><b>Page Layout Type</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__PAGE_LAYOUT_TYPE = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__PAGE_LAYOUT_TYPE;

  /**
   * The feature id for the '<em><b>SEO Page Definition</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__SEO_PAGE_DEFINITION = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__SEO_PAGE_DEFINITION;

  /**
   * The feature id for the '<em><b>SEO Page Definition Description</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__SEO_PAGE_DEFINITION_DESCRIPTION = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__SEO_PAGE_DEFINITION_DESCRIPTION;

  /**
   * The feature id for the '<em><b>SEO Page Definition Override</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__SEO_PAGE_DEFINITION_OVERRIDE = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__SEO_PAGE_DEFINITION_OVERRIDE;

  /**
   * The feature id for the '<em><b>SEO Substitution Parameter</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__SEO_SUBSTITUTION_PARAMETER = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__SEO_SUBSTITUTION_PARAMETER;

  /**
   * The feature id for the '<em><b>SEO Redirect</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__SEO_REDIRECT = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__SEO_REDIRECT;

  /**
   * The feature id for the '<em><b>SEO Redirect Traffic</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__SEO_REDIRECT_TRAFFIC = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__SEO_REDIRECT_TRAFFIC;

  /**
   * The feature id for the '<em><b>SEO Token Usage Type</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__SEO_TOKEN_USAGE_TYPE = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__SEO_TOKEN_USAGE_TYPE;

  /**
   * The feature id for the '<em><b>SEO Url</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__SEO_URL = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__SEO_URL;

  /**
   * The feature id for the '<em><b>SEO Url Keyword</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__SEO_URL_KEYWORD = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__SEO_URL_KEYWORD;

  /**
   * The feature id for the '<em><b>Staddress</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__STADDRESS = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__STADDRESS;

  /**
   * The feature id for the '<em><b>Store</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__STORE = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__STORE;

  /**
   * The feature id for the '<em><b>Storeconf</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__STORECONF = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__STORECONF;

  /**
   * The feature id for the '<em><b>Storedefcat</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__STOREDEFCAT = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__STOREDEFCAT;

  /**
   * The feature id for the '<em><b>Storeent</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__STOREENT = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__STOREENT;

  /**
   * The feature id for the '<em><b>Storeentds</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__STOREENTDS = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__STOREENTDS;

  /**
   * The feature id for the '<em><b>Storelang</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__STORELANG = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__STORELANG;

  /**
   * The feature id for the '<em><b>Store Page Layout Type Relation</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__STORE_PAGE_LAYOUT_TYPE_RELATION = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__STORE_PAGE_LAYOUT_TYPE_RELATION;

  /**
   * The feature id for the '<em><b>Storerel</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__STOREREL = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__STOREREL;

  /**
   * The feature id for the '<em><b>Streltyp</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__STRELTYP = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__STRELTYP;

  /**
   * The feature id for the '<em><b>Streltypds</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__STRELTYPDS = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT__STRELTYPDS;

  /**
   * The feature id for the '<em><b>Xavatax conf</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__XAVATAX_CONF = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>AC Storeent</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT__AC_STOREENT = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT_FEATURE_COUNT + 1;

  /**
   * The number of structural features of the '<em>AC Root</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_ROOT_FEATURE_COUNT = InfrastructureEntityPackage.INFRASTRUCTURE_ROOT_FEATURE_COUNT + 2;

  /**
   * The meta object id for the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl <em>Xavatax conf</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACEntityPackageImpl#getX_avatax_conf()
   * @generated
   */
  int XAVATAX_CONF = 1;

  /**
   * The feature id for the '<em><b>Storeent id</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__STOREENT_ID = 0;

  /**
   * The feature id for the '<em><b>Urltoconnect</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__URLTOCONNECT = 1;

  /**
   * The feature id for the '<em><b>Accnum</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__ACCNUM = 2;

  /**
   * The feature id for the '<em><b>Companycode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__COMPANYCODE = 3;

  /**
   * The feature id for the '<em><b>Taxcalculationmode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__TAXCALCULATIONMODE = 4;

  /**
   * The feature id for the '<em><b>Transactionlogging</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__TRANSACTIONLOGGING = 5;

  /**
   * The feature id for the '<em><b>Translogkeephours</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__TRANSLOGKEEPHOURS = 6;

  /**
   * The feature id for the '<em><b>Supportedcountries</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__SUPPORTEDCOUNTRIES = 7;

  /**
   * The feature id for the '<em><b>Taxcountries</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__TAXCOUNTRIES = 8;

  /**
   * The feature id for the '<em><b>Addrountries</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__ADDROUNTRIES = 9;

  /**
   * The feature id for the '<em><b>Behavioronerror</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__BEHAVIORONERROR = 10;

  /**
   * The feature id for the '<em><b>Defaulttax</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__DEFAULTTAX = 11;

  /**
   * The feature id for the '<em><b>Addrvalidationplaces</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__ADDRVALIDATIONPLACES = 12;

  /**
   * The feature id for the '<em><b>Customervatid</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__CUSTOMERVATID = 13;

  /**
   * The feature id for the '<em><b>Pricecontainstaxes</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__PRICECONTAINSTAXES = 14;

  /**
   * The feature id for the '<em><b>Oitaxesdisplayed</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__OITAXESDISPLAYED = 15;

  /**
   * The feature id for the '<em><b>Logrequesttypes</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__LOGREQUESTTYPES = 16;

  /**
   * The feature id for the '<em><b>Authkey</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__AUTHKEY = 17;

  /**
   * The feature id for the '<em><b>Taxcodeidentifier</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__TAXCODEIDENTIFIER = 18;

  /**
   * The feature id for the '<em><b>Dapcountries</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__DAPCOUNTRIES = 19;

  /**
   * The feature id for the '<em><b>Ddpcountries</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__DDPCOUNTRIES = 20;

  /**
   * The feature id for the '<em><b>Optcounter</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__OPTCOUNTER = 21;

  /**
   * The feature id for the '<em><b>Storeent For Xavatax conf</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF__STOREENT_FOR_XAVATAX_CONF = 22;

  /**
   * The number of structural features of the '<em>Xavatax conf</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int XAVATAX_CONF_FEATURE_COUNT = 23;

  /**
   * The meta object id for the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACStoreentImpl <em>AC Storeent</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACStoreentImpl
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACEntityPackageImpl#getACStoreent()
   * @generated
   */
  int AC_STOREENT = 2;

  /**
   * The feature id for the '<em><b>Storeent id</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__STOREENT_ID = InfrastructureEntityPackage.STOREENT__STOREENT_ID;

  /**
   * The feature id for the '<em><b>Member id</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__MEMBER_ID = InfrastructureEntityPackage.STOREENT__MEMBER_ID;

  /**
   * The feature id for the '<em><b>Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__TYPE = InfrastructureEntityPackage.STOREENT__TYPE;

  /**
   * The feature id for the '<em><b>Setccurr</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__SETCCURR = InfrastructureEntityPackage.STOREENT__SETCCURR;

  /**
   * The feature id for the '<em><b>Identifier</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__IDENTIFIER = InfrastructureEntityPackage.STOREENT__IDENTIFIER;

  /**
   * The feature id for the '<em><b>Markfordelete</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__MARKFORDELETE = InfrastructureEntityPackage.STOREENT__MARKFORDELETE;

  /**
   * The feature id for the '<em><b>Optcounter</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__OPTCOUNTER = InfrastructureEntityPackage.STOREENT__OPTCOUNTER;

  /**
   * The feature id for the '<em><b>Curlist For Storeent</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__CURLIST_FOR_STOREENT = InfrastructureEntityPackage.STOREENT__CURLIST_FOR_STOREENT;

  /**
   * The feature id for the '<em><b>Folder For Storeent</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__FOLDER_FOR_STOREENT = InfrastructureEntityPackage.STOREENT__FOLDER_FOR_STOREENT;

  /**
   * The feature id for the '<em><b>Folderitem For Storeent</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__FOLDERITEM_FOR_STOREENT = InfrastructureEntityPackage.STOREENT__FOLDERITEM_FOR_STOREENT;

  /**
   * The feature id for the '<em><b>Page Layout</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__PAGE_LAYOUT = InfrastructureEntityPackage.STOREENT__PAGE_LAYOUT;

  /**
   * The feature id for the '<em><b>SEO Page Definition For Storeent</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__SEO_PAGE_DEFINITION_FOR_STOREENT = InfrastructureEntityPackage.STOREENT__SEO_PAGE_DEFINITION_FOR_STOREENT;

  /**
   * The feature id for the '<em><b>SEO Substitution Parameter For Storeent</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__SEO_SUBSTITUTION_PARAMETER_FOR_STOREENT = InfrastructureEntityPackage.STOREENT__SEO_SUBSTITUTION_PARAMETER_FOR_STOREENT;

  /**
   * The feature id for the '<em><b>SEO Token Usage Type For Storeent</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__SEO_TOKEN_USAGE_TYPE_FOR_STOREENT = InfrastructureEntityPackage.STOREENT__SEO_TOKEN_USAGE_TYPE_FOR_STOREENT;

  /**
   * The feature id for the '<em><b>SEO Url Keyword For Storeent</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__SEO_URL_KEYWORD_FOR_STOREENT = InfrastructureEntityPackage.STOREENT__SEO_URL_KEYWORD_FOR_STOREENT;

  /**
   * The feature id for the '<em><b>Store For Storeent</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__STORE_FOR_STOREENT = InfrastructureEntityPackage.STOREENT__STORE_FOR_STOREENT;

  /**
   * The feature id for the '<em><b>Storeconf For Storeent</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__STORECONF_FOR_STOREENT = InfrastructureEntityPackage.STOREENT__STORECONF_FOR_STOREENT;

  /**
   * The feature id for the '<em><b>Storedefcat For Storeent</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__STOREDEFCAT_FOR_STOREENT = InfrastructureEntityPackage.STOREENT__STOREDEFCAT_FOR_STOREENT;

  /**
   * The feature id for the '<em><b>Storeentds For Storeent</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__STOREENTDS_FOR_STOREENT = InfrastructureEntityPackage.STOREENT__STOREENTDS_FOR_STOREENT;

  /**
   * The feature id for the '<em><b>Storelang For Storeent</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__STORELANG_FOR_STOREENT = InfrastructureEntityPackage.STOREENT__STORELANG_FOR_STOREENT;

  /**
   * The feature id for the '<em><b>Store Page Layout Type Relation</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__STORE_PAGE_LAYOUT_TYPE_RELATION = InfrastructureEntityPackage.STOREENT__STORE_PAGE_LAYOUT_TYPE_RELATION;

  /**
   * The feature id for the '<em><b>Xavatax conf For Storeent</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT__XAVATAX_CONF_FOR_STOREENT = InfrastructureEntityPackage.STOREENT_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>AC Storeent</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AC_STOREENT_FEATURE_COUNT = InfrastructureEntityPackage.STOREENT_FEATURE_COUNT + 1;


  /**
   * Returns the meta object for class '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACRoot <em>AC Root</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>AC Root</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACRoot
   * @generated
   */
  EClass getACRoot();

  /**
   * Returns the meta object for the containment reference list '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACRoot#getX_avatax_conf <em>Xavatax conf</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Xavatax conf</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACRoot#getX_avatax_conf()
   * @see #getACRoot()
   * @generated
   */
  EReference getACRoot_X_avatax_conf();

  /**
   * Returns the meta object for the containment reference list '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACRoot#getACStoreent <em>AC Storeent</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>AC Storeent</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACRoot#getACStoreent()
   * @see #getACRoot()
   * @generated
   */
  EReference getACRoot_ACStoreent();

  /**
   * Returns the meta object for class '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf <em>Xavatax conf</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Xavatax conf</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf
   * @generated
   */
  EClass getX_avatax_conf();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getStoreent_id <em>Storeent id</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Storeent id</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getStoreent_id()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Storeent_id();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getUrltoconnect <em>Urltoconnect</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Urltoconnect</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getUrltoconnect()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Urltoconnect();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getAccnum <em>Accnum</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Accnum</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getAccnum()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Accnum();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getCompanycode <em>Companycode</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Companycode</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getCompanycode()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Companycode();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTaxcalculationmode <em>Taxcalculationmode</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Taxcalculationmode</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTaxcalculationmode()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Taxcalculationmode();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTransactionlogging <em>Transactionlogging</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Transactionlogging</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTransactionlogging()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Transactionlogging();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTranslogkeephours <em>Translogkeephours</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Translogkeephours</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTranslogkeephours()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Translogkeephours();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getSupportedcountries <em>Supportedcountries</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Supportedcountries</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getSupportedcountries()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Supportedcountries();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTaxcountries <em>Taxcountries</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Taxcountries</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTaxcountries()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Taxcountries();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getAddrountries <em>Addrountries</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Addrountries</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getAddrountries()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Addrountries();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getBehavioronerror <em>Behavioronerror</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Behavioronerror</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getBehavioronerror()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Behavioronerror();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getDefaulttax <em>Defaulttax</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Defaulttax</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getDefaulttax()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Defaulttax();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getAddrvalidationplaces <em>Addrvalidationplaces</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Addrvalidationplaces</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getAddrvalidationplaces()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Addrvalidationplaces();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getCustomervatid <em>Customervatid</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Customervatid</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getCustomervatid()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Customervatid();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getPricecontainstaxes <em>Pricecontainstaxes</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Pricecontainstaxes</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getPricecontainstaxes()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Pricecontainstaxes();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getOitaxesdisplayed <em>Oitaxesdisplayed</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Oitaxesdisplayed</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getOitaxesdisplayed()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Oitaxesdisplayed();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getLogrequesttypes <em>Logrequesttypes</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Logrequesttypes</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getLogrequesttypes()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Logrequesttypes();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getAuthkey <em>Authkey</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Authkey</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getAuthkey()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Authkey();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTaxcodeidentifier <em>Taxcodeidentifier</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Taxcodeidentifier</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getTaxcodeidentifier()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Taxcodeidentifier();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getDapcountries <em>Dapcountries</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dapcountries</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getDapcountries()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Dapcountries();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getDdpcountries <em>Ddpcountries</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Ddpcountries</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getDdpcountries()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Ddpcountries();

  /**
   * Returns the meta object for the attribute '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getOptcounter <em>Optcounter</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Optcounter</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getOptcounter()
   * @see #getX_avatax_conf()
   * @generated
   */
  EAttribute getX_avatax_conf_Optcounter();

  /**
   * Returns the meta object for the reference '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getStoreentForX_avatax_conf <em>Storeent For Xavatax conf</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Storeent For Xavatax conf</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getStoreentForX_avatax_conf()
   * @see #getX_avatax_conf()
   * @generated
   */
  EReference getX_avatax_conf_StoreentForX_avatax_conf();

  /**
   * Returns the meta object for class '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACStoreent <em>AC Storeent</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>AC Storeent</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACStoreent
   * @generated
   */
  EClass getACStoreent();

  /**
   * Returns the meta object for the reference '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACStoreent#getX_avatax_confForStoreent <em>Xavatax conf For Storeent</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Xavatax conf For Storeent</em>'.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACStoreent#getX_avatax_confForStoreent()
   * @see #getACStoreent()
   * @generated
   */
  EReference getACStoreent_X_avatax_confForStoreent();

  /**
   * Returns the factory that creates the instances of the model.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the factory that creates the instances of the model.
   * @generated
   */
  ACEntityFactory getACEntityFactory();

  /**
   * <!-- begin-user-doc -->
   * Defines literals for the meta objects that represent
   * <ul>
   *   <li>each class,</li>
   *   <li>each feature of each class,</li>
   *   <li>each enum,</li>
   *   <li>and each data type</li>
   * </ul>
   * <!-- end-user-doc -->
   * @generated
   */
  interface Literals
  {
    /**
     * The meta object literal for the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACRootImpl <em>AC Root</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACRootImpl
     * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACEntityPackageImpl#getACRoot()
     * @generated
     */
    EClass AC_ROOT = eINSTANCE.getACRoot();

    /**
     * The meta object literal for the '<em><b>Xavatax conf</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference AC_ROOT__XAVATAX_CONF = eINSTANCE.getACRoot_X_avatax_conf();

    /**
     * The meta object literal for the '<em><b>AC Storeent</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference AC_ROOT__AC_STOREENT = eINSTANCE.getACRoot_ACStoreent();

    /**
     * The meta object literal for the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl <em>Xavatax conf</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl
     * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACEntityPackageImpl#getX_avatax_conf()
     * @generated
     */
    EClass XAVATAX_CONF = eINSTANCE.getX_avatax_conf();

    /**
     * The meta object literal for the '<em><b>Storeent id</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__STOREENT_ID = eINSTANCE.getX_avatax_conf_Storeent_id();

    /**
     * The meta object literal for the '<em><b>Urltoconnect</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__URLTOCONNECT = eINSTANCE.getX_avatax_conf_Urltoconnect();

    /**
     * The meta object literal for the '<em><b>Accnum</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__ACCNUM = eINSTANCE.getX_avatax_conf_Accnum();

    /**
     * The meta object literal for the '<em><b>Companycode</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__COMPANYCODE = eINSTANCE.getX_avatax_conf_Companycode();

    /**
     * The meta object literal for the '<em><b>Taxcalculationmode</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__TAXCALCULATIONMODE = eINSTANCE.getX_avatax_conf_Taxcalculationmode();

    /**
     * The meta object literal for the '<em><b>Transactionlogging</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__TRANSACTIONLOGGING = eINSTANCE.getX_avatax_conf_Transactionlogging();

    /**
     * The meta object literal for the '<em><b>Translogkeephours</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__TRANSLOGKEEPHOURS = eINSTANCE.getX_avatax_conf_Translogkeephours();

    /**
     * The meta object literal for the '<em><b>Supportedcountries</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__SUPPORTEDCOUNTRIES = eINSTANCE.getX_avatax_conf_Supportedcountries();

    /**
     * The meta object literal for the '<em><b>Taxcountries</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__TAXCOUNTRIES = eINSTANCE.getX_avatax_conf_Taxcountries();

    /**
     * The meta object literal for the '<em><b>Addrountries</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__ADDROUNTRIES = eINSTANCE.getX_avatax_conf_Addrountries();

    /**
     * The meta object literal for the '<em><b>Behavioronerror</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__BEHAVIORONERROR = eINSTANCE.getX_avatax_conf_Behavioronerror();

    /**
     * The meta object literal for the '<em><b>Defaulttax</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__DEFAULTTAX = eINSTANCE.getX_avatax_conf_Defaulttax();

    /**
     * The meta object literal for the '<em><b>Addrvalidationplaces</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__ADDRVALIDATIONPLACES = eINSTANCE.getX_avatax_conf_Addrvalidationplaces();

    /**
     * The meta object literal for the '<em><b>Customervatid</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__CUSTOMERVATID = eINSTANCE.getX_avatax_conf_Customervatid();

    /**
     * The meta object literal for the '<em><b>Pricecontainstaxes</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__PRICECONTAINSTAXES = eINSTANCE.getX_avatax_conf_Pricecontainstaxes();

    /**
     * The meta object literal for the '<em><b>Oitaxesdisplayed</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__OITAXESDISPLAYED = eINSTANCE.getX_avatax_conf_Oitaxesdisplayed();

    /**
     * The meta object literal for the '<em><b>Logrequesttypes</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__LOGREQUESTTYPES = eINSTANCE.getX_avatax_conf_Logrequesttypes();

    /**
     * The meta object literal for the '<em><b>Authkey</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__AUTHKEY = eINSTANCE.getX_avatax_conf_Authkey();

    /**
     * The meta object literal for the '<em><b>Taxcodeidentifier</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__TAXCODEIDENTIFIER = eINSTANCE.getX_avatax_conf_Taxcodeidentifier();

    /**
     * The meta object literal for the '<em><b>Dapcountries</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__DAPCOUNTRIES = eINSTANCE.getX_avatax_conf_Dapcountries();

    /**
     * The meta object literal for the '<em><b>Ddpcountries</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__DDPCOUNTRIES = eINSTANCE.getX_avatax_conf_Ddpcountries();

    /**
     * The meta object literal for the '<em><b>Optcounter</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute XAVATAX_CONF__OPTCOUNTER = eINSTANCE.getX_avatax_conf_Optcounter();

    /**
     * The meta object literal for the '<em><b>Storeent For Xavatax conf</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference XAVATAX_CONF__STOREENT_FOR_XAVATAX_CONF = eINSTANCE.getX_avatax_conf_StoreentForX_avatax_conf();

    /**
     * The meta object literal for the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACStoreentImpl <em>AC Storeent</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACStoreentImpl
     * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACEntityPackageImpl#getACStoreent()
     * @generated
     */
    EClass AC_STOREENT = eINSTANCE.getACStoreent();

    /**
     * The meta object literal for the '<em><b>Xavatax conf For Storeent</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference AC_STOREENT__XAVATAX_CONF_FOR_STOREENT = eINSTANCE.getACStoreent_X_avatax_confForStoreent();

  }

} //ACEntityPackage
