package com.ac.avalara.order.bean;

import java.util.Vector;

import com.ac.avalara.utility.LandedCostIsExpress;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.base.objects.ServerJDBCHelperBean;
import com.ibm.commerce.beans.SmartDataBean;
import com.ibm.commerce.beans.SmartDataBeanImpl;

public class ACAvalaraShipModeDetailsDataBean extends SmartDataBeanImpl implements SmartDataBean {

	private Integer shipModeId;
	private ACAvalaraShipModeDetails details = null;

	private static final String GET_DETAILS_SHIPMODE = "select SHIPMODE_ID, MODE, TAX_CODE, IS_EXPRESS from X_AVATAX_SHPMDDTL where SHIPMODE_ID = ?";

	private static final ACLogger LOGGER = new ACLogger(ACAvalaraShipModeDetailsDataBean.class);

	@Override
	public void populate() throws Exception {
		String methodName = "populate()";
		try {
			ServerJDBCHelperBean jdbcHelper = new ServerJDBCHelperBean();
			
			Vector<Vector<?>> vRecords = new Vector<Vector<?>>();
			if (null != this.shipModeId) {
				vRecords = jdbcHelper.executeParameterizedQuery(GET_DETAILS_SHIPMODE, new Object[] { this.shipModeId });
			} else {
				// TODO notification about wrong parameters set
			}
			if (vRecords.size() == 1) {
				this.details = new ACAvalaraShipModeDetails();
				Vector record = vRecords.get(0);
				if (null != record.get(0)) {
					this.details.setShipModeId((Integer) record.get(0));
				}
				this.details.setMode(null != record.get(1) ? String.valueOf(record.get(1)) : null);
				this.details.setHtsCode(null != record.get(2) ? String.valueOf(record.get(2)) : null);
				this.details.setExpress(null != record.get(3) ? LandedCostIsExpress.valueOf(String.valueOf(record.get(3))) : LandedCostIsExpress.N);

			} else {
				// TODO no data notification
			}

		} catch (Exception e) {
			LOGGER.error(methodName, "Error occured while getting avatax tax details " + e.getMessage());
		}
	}
	
	public void setShipModeId(Integer shipModeId) {
		this.shipModeId = shipModeId;
	}

	public ACAvalaraShipModeDetails getDetails() {
		return details;
	}

}
