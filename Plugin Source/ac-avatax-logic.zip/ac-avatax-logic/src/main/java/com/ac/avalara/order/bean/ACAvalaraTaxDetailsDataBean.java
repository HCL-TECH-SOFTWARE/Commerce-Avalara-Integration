package com.ac.avalara.order.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.base.objects.ServerJDBCHelperBean;
import com.ibm.commerce.beans.SmartDataBean;
import com.ibm.commerce.beans.SmartDataBeanImpl;
import com.ibm.commerce.ras.ECMessageHelper;


public class ACAvalaraTaxDetailsDataBean extends SmartDataBeanImpl implements SmartDataBean {

	private Long orderId;
	private Long orderItemId;	
	private boolean isAllItemsDetails;
	
	private List<ACAvalaraTaxDetails> details = new ArrayList<ACAvalaraTaxDetails>(); 
	

	private static final String GET_DETAILS_ORDER = "select ORDERS_ID, ORDERITEMS_ID, TAXTYPE, TAXNAME, TAXABLE, RATE, TAX, NONTAXABLE, EXEMPTION, TYPE from X_AVATAX_DTL where ORDERS_ID = ? and ORDERITEMS_ID is null";
	private static final String GET_DETAILS_ITEM = "select ORDERS_ID, ORDERITEMS_ID, TAXTYPE, TAXNAME, TAXABLE, RATE, TAX, NONTAXABLE, EXEMPTION, TYPE from X_AVATAX_DTL where ORDERITEMS_ID = ?";
	private static final String GET_ALL_ORDER_ITEM_DETAILS = "select ORDERS_ID, ORDERITEMS_ID, TAXTYPE, TAXNAME, TAXABLE, RATE, TAX, NONTAXABLE, EXEMPTION, TYPE from X_AVATAX_DTL where ORDERS_ID = ?";
	
	private static final String CELANUP_ENTIRE_ORDER = "delete from X_AVATAX_DTL where ORDERS_ID = ? ";
	private static final String CELANUP_ORDER = "delete from X_AVATAX_DTL where ORDERS_ID = ? and ORDERITEMS_ID is null";
	private static final String CELANUP_ORDER_ITEM = "delete from X_AVATAX_DTL where ORDERITEMS_ID = ?";
	private static final String INSERT_ORDER_DETAILS = "insert into X_AVATAX_DTL (ORDERS_ID,TAXTYPE,TAXNAME,TAXABLE,RATE,TAX,NONTAXABLE,EXEMPTION, TYPE) VALUES (?,?,?,?,?,?,?,?,?)";
	private static final String INSERT_ORDER_ITEM_DETAILS = "insert into X_AVATAX_DTL (ORDERS_ID,ORDERITEMS_ID,TAXTYPE,TAXNAME,TAXABLE,RATE,TAX,NONTAXABLE,EXEMPTION, TYPE) VALUES (?,?,?,?,?,?,?,?,?,?)";
	
	
	private static final ACLogger LOGGER = new ACLogger(ACAvalaraTaxDetailsDataBean.class);
	
	@Override
	public void populate() throws Exception {
		String methodName = "populate()";
		try {
			ServerJDBCHelperBean jdbcHelper = new ServerJDBCHelperBean();
			
			Vector<Vector<?>> vRecords = new Vector<Vector<?>>();
			if (null != this.orderItemId) {
				vRecords = jdbcHelper.executeParameterizedQuery(GET_DETAILS_ITEM, new Object[]{this.orderItemId});
			} else if (null != this.orderId) {
				if(isAllItemsDetails) {
				    vRecords = jdbcHelper.executeParameterizedQuery(GET_ALL_ORDER_ITEM_DETAILS, new Object[]{this.orderId});		
				} else {
					vRecords = jdbcHelper.executeParameterizedQuery(GET_DETAILS_ORDER, new Object[]{this.orderId});	
				}				
			} else {
				LOGGER.error(methodName, "Wrong paratemers set orderId: {0}, orderItemId: {1}, isAllItemsDetails: {2}", new Object[]{String.valueOf(this.orderId), String.valueOf(this.orderItemId), String.valueOf(this.isAllItemsDetails)});
			}
			//select ORDER_ID, ORDERITEM_ID, TAXTYPE, TAXNAME, TAXABLE, RATE, TAX, NONTAXABLE, EXEMPTION from X_AVATAX_DTL where ORDERS_ID = ? and ORDERITEMS_ID is null
			for (Vector record: vRecords) {
				ACAvalaraTaxDetails detail = new ACAvalaraTaxDetails();
				if (null != record.get(0)) {
					detail.setOrderId((Long)record.get(0));					
				}
				if (null != record.get(1)) {
					detail.setOrderItemId((Long)record.get(1));
				}
				detail.setTaxtype(null != record.get(2) ? String.valueOf(record.get(2)) : null);
				detail.setTaxname(null != record.get(3) ? String.valueOf(record.get(3)) : null);
				detail.setTaxable(null != record.get(4) ? String.valueOf(record.get(4)) : null);
				detail.setRate(null != record.get(5) ? String.valueOf(record.get(5)) : null);
				detail.setTax(null != record.get(6) ? String.valueOf(record.get(6)) : null);
				detail.setNontaxable(null != record.get(7) ? String.valueOf(record.get(7)) : null);
				detail.setExcemption(null != record.get(8) ? String.valueOf(record.get(8)) : null);
				detail.setType(null != record.get(9) ? ACAvalaraTaxDetailsType.valueOf(String.valueOf(record.get(9))) : null);
				this.details.add(detail);
			}
		} catch (Exception e){
			LOGGER.error(methodName, "Error occured while getting avatax tax details " + e.getMessage());
		}
	}
	
	public void cleanupEntireOrder() throws Exception {
		String methodName = "cleanupEntireOrder()";
		try {
			ServerJDBCHelperBean jdbcHelper = new ServerJDBCHelperBean();
			
			if (null != this.orderId) {
				jdbcHelper.executeParameterizedUpdate(CELANUP_ENTIRE_ORDER, new Serializable[]{this.orderId});
			} else {
				LOGGER.error(methodName, "Wrong paratemers set orderId: {0}", new Object[]{String.valueOf(this.orderId), String.valueOf(this.orderItemId), String.valueOf(this.isAllItemsDetails)});
			}
		} catch (Exception e){
			LOGGER.error(methodName, "Error occured while updating avatax tax details information " + ECMessageHelper.getExceptionStackTrace(e));
		}
	}
	
	public void update() throws Exception {
		String methodName = "update()";
		try {
			ServerJDBCHelperBean jdbcHelper = new ServerJDBCHelperBean();
			
			if (null != this.orderItemId) {
				jdbcHelper.executeParameterizedUpdate(CELANUP_ORDER_ITEM, new Serializable[]{this.orderItemId});
				for (ACAvalaraTaxDetails detail : this.details) {
					jdbcHelper.executeParameterizedUpdate(INSERT_ORDER_ITEM_DETAILS, new Serializable[]{detail.getOrderId(), detail.getOrderItemId(),detail.getTaxtype(), detail.getTaxname(), detail.getTaxable(), detail.getRate(), detail.getTax(), detail.getNontaxable(), detail.getExcemption(), null != detail.getType() ? detail.getType().name() : null});
				}
			} else if (null != this.orderId) {
				jdbcHelper.executeParameterizedUpdate(CELANUP_ORDER, new Serializable[]{this.orderId});
				for (ACAvalaraTaxDetails detail : this.details) {
					jdbcHelper.executeParameterizedUpdate(INSERT_ORDER_DETAILS, new Serializable[]{detail.getOrderId(), detail.getTaxtype(), detail.getTaxname(), detail.getTaxable(), detail.getRate(), detail.getTax(), detail.getNontaxable(), detail.getExcemption(), null != detail.getType() ? detail.getType().name() : null});
				}				
			} else {
				LOGGER.error(methodName, "Wrong paratemers set orderId: {0}, orderItemId: {1}, isAllItemsDetails: {2}", new Object[]{String.valueOf(this.orderId), String.valueOf(this.orderItemId), String.valueOf(this.isAllItemsDetails)});
			}
		
		} catch (Exception e){
			LOGGER.error(methodName, "Error occured while updating avatax tax details information " + ECMessageHelper.getExceptionStackTrace(e));
		}
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Long getOrderItemId() {
		return orderItemId;
	}

	public void setOrderItemId(Long orderItemId) {
		this.orderItemId = orderItemId;
	}

	public List<ACAvalaraTaxDetails> getDetails() {
		return details;
	}

	public void setDetails(List<ACAvalaraTaxDetails> details) {
		this.details = details;
	}

	public boolean isAllItemsDetails() {
		return isAllItemsDetails;
	}

	public void setAllItemsDetails(boolean isAllItemsDetails) {
		this.isAllItemsDetails = isAllItemsDetails;
	}
	

	
	
	

}

