package com.ac.avalara.settings;

import java.math.BigDecimal;
import java.util.ResourceBundle;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.utility.ACAvalaraTaxUtils;
import com.ac.avatax.rest.logger.AvalaraLoggerSettings;
import com.ac.commerce.util.configuration.ACPropertyLoader;
import com.ac.commerce.util.configuration.ACPropertyLoaderFactory;
import com.ac.commerce.util.logging.ACLogger;

public class ACAvalaraSettingsUtils {

	private static ResourceBundle resourcebundle = ResourceBundle.getBundle(ACAvalaraConstants.AVALARA_TAX_PROPERTIES);
	private static final ACPropertyLoader PROPERTY_LOADER = ACPropertyLoaderFactory.getInstance();
	private static final ACLogger LOGGER = new ACLogger(ACAvalaraTaxUtils.class);
	
	private static AvalaraLoggerSettings loggerSettings = null;
	
	

	public synchronized static ACAvalaraSettings loadAvalaraGeneralSettings(ACAvalaraConfigurationDataBean bean){
		ACAvalaraSettings settings = new ACAvalaraSettings();
		try {
			settings.setAccountId(bean.getAccNum());
			settings.setCompanyCode(bean.getCompanyCode());
			settings.setAuthKey(bean.getAuthKey());			
			settings.setUrl(bean.getUrlToConnect());
			settings.setTimeOutForRequest(bean.getTimeout());
			settings.setAddressVerificationUrl(PROPERTY_LOADER.getString(ACAvalaraConstants.AVALARA_TAX_PROPERTIES, ACAvalaraConstants.API_ADDRESS_VALIDATION_URL));
			settings.setHeaderUserAgent(PROPERTY_LOADER.getString(ACAvalaraConstants.AVALARA_TAX_PROPERTIES, ACAvalaraConstants.API_HEADER_USER_AGENT));
			settings.setCalculationUrl(PROPERTY_LOADER.getString(ACAvalaraConstants.AVALARA_TAX_PROPERTIES, ACAvalaraConstants.API_CALCULATION_URL));
			settings.setRecordUrl(PROPERTY_LOADER.getString(ACAvalaraConstants.AVALARA_TAX_PROPERTIES, ACAvalaraConstants.API_RECORD_URL));
			settings.setStateTransitionsUrl(PROPERTY_LOADER.getString(ACAvalaraConstants.AVALARA_TAX_PROPERTIES, ACAvalaraConstants.API_STATE_TRANSITIONS_URL));
			settings.setTaxIncluded(bean.isPriceContainsTaxes());
			settings.setTaxCalculationMode(bean.getTaxCalculationMode());
			settings.setBehavioronError(bean.getBehavioronError());
			settings.setCustomerVatIdEnabled(bean.isCustomerVatId());
			settings.setTaxCodeIdentifier(bean.getTaxCodeIdentifier());
			settings.setHtsCodeIdentifier(bean.getHtsCodeIdentifier());
			settings.setUnitAmountIdentifier(bean.getUnitAmountIdentifier());			
			settings.setUnitNameIdentifier(bean.getUnitNameIdentifier());
			settings.setSupportedCountries(bean.getSupportedCountries());
			settings.setTaxCountries(bean.getTaxCountries());
			settings.setAddrCountries(bean.getAddrCountries());
			settings.setDapCountries(bean.getDapCountries());
			settings.setDdpCountries(bean.getDdpCountries());
			if (null == bean.getDefaultTax()) {
				settings.setDefaultTaxRate(new BigDecimal(ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.DEFAULT_TAX_RATE)));
			} else {
				settings.setDefaultTaxRate(bean.getDefaultTax());				
			}
			
		} catch (Exception e) {
			LOGGER.error("loadAvalaraGeneralSettings", "Error occured while loading avalara settings: " + e.getMessage());
		}
		
		return settings;
	}
	
	public synchronized static AvalaraLoggerSettings loadAvalaraLoggerSettings(ACAvalaraConfigurationDataBean bean){
		loggerSettings = new AvalaraLoggerSettings();
		loggerSettings.setDirectory(PROPERTY_LOADER.getString(ACAvalaraConstants.AVALARA_TAX_PROPERTIES, ACAvalaraConstants.LOG_DIRECTORY));
		loggerSettings.setFileName(PROPERTY_LOADER.getString(ACAvalaraConstants.AVALARA_TAX_PROPERTIES, ACAvalaraConstants.LOG_FILENAME));
		loggerSettings.setHoursToKeepLogs(bean.getTransLogKeepHours() == null ? 0 : bean.getTransLogKeepHours() );
		loggerSettings.setLogCalculateRequest(bean.isLogCalculateRequest());
		loggerSettings.setLogValidateAddressRequest(bean.isLogValidateRequest());
		loggerSettings.setLogPingRequest(bean.isLogPingRequest());
		loggerSettings.setLogCancelRequest(bean.isLogCancelRequest());
		loggerSettings.setLogEnabled(bean.getTransactionLogging());
		return loggerSettings;
	}
	
	public static String getConfProperty(String key){
		return PROPERTY_LOADER.getString(ACAvalaraConstants.AVALARA_TAX_PROPERTIES, key);
	}
}
