package com.ac.avalara.settings;

import java.math.BigDecimal;



public class ACAvalaraSettings {

	private String url;
	private String accountId;
	private String companyId;
	private String authKey;
	private Integer timeOutForRequest;
	private String zipCodePatterns;
	private String addressVerificationUrl;
	private String calculationUrl;
	private String headerUserAgent;
	private String recordUrl;
	private String stateTransitionsUrl;
	private Boolean taxIncluded;
	private String taxCalculationMode;
	private String behavioronError;
	private Boolean customerVatIdEnabled;
	private String taxCodeIdentifier;
	private String supportedCountries;
	private String taxCountries;
	private String addrCountries;
	private String dapCountries;
	private String ddpCountries;
	private String htsCodeIdentifier;
	private String unitAmountIdentifier;
	private String unitNameIdentifier;
	private BigDecimal defaultTaxRate;

	
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getAuthKey() {
		return authKey;
	}
	public void setAuthKey(String authKey) {
		this.authKey = authKey;
	}
	public Integer getTimeOutForRequest() {
		return timeOutForRequest;
	}
	public void setTimeOutForRequest(Integer timeOutForRequest) {
		this.timeOutForRequest = timeOutForRequest;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyCode(String companyId) {
		this.companyId = companyId;
	}
	public String getZipCodePatterns() {
		return zipCodePatterns;
	}
	public void setZipCodePatterns(String zipCodePatterns) {
		this.zipCodePatterns = zipCodePatterns;
	}
	public String getAddressVerificationUrl() {
		return addressVerificationUrl;
	}
	public void setAddressVerificationUrl(String addressVerificationUrl) {
		this.addressVerificationUrl = addressVerificationUrl;
	}
	public String getHeaderUserAgent() {
		return headerUserAgent;
	}
	public void setHeaderUserAgent(String headerUserAgent) {
		this.headerUserAgent = headerUserAgent;
	}
	public String getCalculationUrl() {
		return calculationUrl;
	}
	public void setCalculationUrl(String calculationUrl) {
		this.calculationUrl = calculationUrl;
	}
	public String getRecordUrl() {
		return recordUrl;
	}
	public void setRecordUrl(String recordUrl) {
		this.recordUrl = recordUrl;
	}
	public String getStateTransitionsUrl() {
		return stateTransitionsUrl;
	}
	public void setStateTransitionsUrl(String stateTransitionsUrl) {
		this.stateTransitionsUrl = stateTransitionsUrl;
	}
	public Boolean getTaxIncluded() {
		return taxIncluded;
	}
	public void setTaxIncluded(Boolean taxIncluded) {
		this.taxIncluded = taxIncluded;
	}
	public void setTaxCalculationMode(String taxCalculationMode) {
		this.taxCalculationMode = taxCalculationMode;
	}
	public boolean isTaxCalculationEnabled(){
		if (taxCalculationMode != null){
			return !taxCalculationMode.equalsIgnoreCase(ACAvalaraConstants.DISABLED_TAX_CALCULATION);
		}
		return false;
	}
	public boolean isTaxSubmissionEnabled(){
		if (taxCalculationMode != null){
			return taxCalculationMode.equalsIgnoreCase(ACAvalaraConstants.ENABLE_SUBMITTING_TAX);
		}
		return false;
	}
	public void setBehavioronError(String behavioronError) {
		this.behavioronError = behavioronError;
	}
	public boolean isErrorSetDefaultTax(){
		return behavioronError != null ? this.behavioronError.contains("SETDEFAULTTAX") : false;
	}
	public boolean isErrorSetZeroTax(){
		return behavioronError != null ? this.behavioronError.contains("ALLOWTAX0") : false;
	}
	public boolean isStopCheckout(){
		return behavioronError != null ? this.behavioronError.contains("DONTALLOW") : false;
	}
	public Boolean getCustomerVatIdEnabled() {
		return customerVatIdEnabled;
	}
	public void setCustomerVatIdEnabled(Boolean customerVatIdEnabled) {
		this.customerVatIdEnabled = customerVatIdEnabled;
	}
	public String getTaxCodeIdentifier() {
		return taxCodeIdentifier;
	}
	public void setTaxCodeIdentifier(String taxCodeIdentifier) {
		this.taxCodeIdentifier = taxCodeIdentifier;
	}
	public String getSupportedCountries() {
		return supportedCountries;
	}
	public void setSupportedCountries(String supportedCountries) {
		this.supportedCountries = supportedCountries;
	}


	public String getUserName() {
 
		return this.accountId;
	}
	public String getPassword() {

		return this.authKey;
	}
	public String getLicenseKey() {
		return this.authKey;
	}
	
	
	public String getTaxCountries() {
		return taxCountries;
	}
	public void setTaxCountries(String taxCountries) {
		this.taxCountries = taxCountries;
	}
	public String getAddrCountries() {
		return addrCountries;
	}
	public void setAddrCountries(String addrCountries) {
		this.addrCountries = addrCountries;
	}
	public String getDapCountries() {
		return dapCountries;
	}
	public void setDapCountries(String dapCountries) {
		this.dapCountries = dapCountries;
	}
	public String getDdpCountries() {
		return ddpCountries;
	}
	public void setDdpCountries(String ddpCountries) {
		this.ddpCountries = ddpCountries;
	}
	public void setHtsCodeIdentifier(String htsCodeIdentifier) {
		this.htsCodeIdentifier = htsCodeIdentifier;
		
	}
	
	public String getHtsCodeIdentifier() {
		return htsCodeIdentifier;
	}
	public String getUnitAmountIdentifier() {
		return this.unitAmountIdentifier;
	}
	public String getUnitNameIdentifier() {
	
		return this.unitNameIdentifier;
	}
	
	public void setUnitAmountIdentifier(String unitAmountIdentifier) {
		this.unitAmountIdentifier = unitAmountIdentifier;
	}
	
	public void setUnitNameIdentifier(String unitNameIdentifier) {
		this.unitNameIdentifier = unitNameIdentifier;
	}
	
	public void setDefaultTaxRate(BigDecimal defaultTaxRate) {
		this.defaultTaxRate = defaultTaxRate;
	}
	public BigDecimal getDefaultTaxRate() {
		return defaultTaxRate;
	}
	
}
