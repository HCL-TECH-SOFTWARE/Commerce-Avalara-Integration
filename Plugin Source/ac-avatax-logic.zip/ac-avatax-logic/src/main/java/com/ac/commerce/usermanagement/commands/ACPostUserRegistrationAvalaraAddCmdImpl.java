package com.ac.commerce.usermanagement.commands;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ac.commerce.util.CommandFactory;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.command.CommandContext;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.usermanagement.commands.PostUserRegistrationAddCmdImpl;

/**
 * This class extends PostUserRegistrationAddCmdImpl to implement Customer Tax Exemption logic during registration.
 *
 * @author Sahil Bansal, ASkosyr
 */
@SuppressWarnings("serial")
public class ACPostUserRegistrationAvalaraAddCmdImpl extends PostUserRegistrationAddCmdImpl {
	
    private final static String ESOL_USR_ADD_IMPL_CLASS = "com.ac.commerce.usermanagement.commands.ACPostUserRegistrationAddCmdImpl";
    private final static String AVALARA_USR_ADD_IMPL_CLASS = "com.ac.commerce.usermanagement.commands.ACAvalaraPostUserRegistrationAddCmdImpl";

    private static final ACLogger LOGGER = new ACLogger(ACPostUserRegistrationAvalaraAddCmdImpl.class);

    @Override
    public void performExecute() throws ECException {
        String methodName = "performExecute";
        LOGGER.entering(methodName);

        super.performExecute();
        
        addAvalaraUserIfCustomerVatIDEnabled();

        LOGGER.exiting(methodName);
    }
    
    private void addAvalaraUserIfCustomerVatIDEnabled() throws ECException {
        final String METHOD_NAME = "addAvalaraUserIfAvalaraIsTurnedOn";
        LOGGER.entering(METHOD_NAME);

        ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
    	bean.setCommandContext(getCommandContext());
    	try {
			bean.populate();
			ACAvalaraSettings settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);
	        if (settings.getCustomerVatIdEnabled()) {
	            CommandContext cc = getCommandContext();            
	            ACAvalaraUserAddUpdateTaskCmd task = CommandFactory.createTask(ACAvalaraUserAddUpdateTaskCmd.class, commandContext);
	            task.setSettings(settings);
	            task.execute();
	        }
		} catch (Exception e) {
			LOGGER.error(METHOD_NAME, "Exception occured while updating custom user's avalara information: " + e.getMessage());
		}

        LOGGER.exiting(METHOD_NAME);
    }

}
