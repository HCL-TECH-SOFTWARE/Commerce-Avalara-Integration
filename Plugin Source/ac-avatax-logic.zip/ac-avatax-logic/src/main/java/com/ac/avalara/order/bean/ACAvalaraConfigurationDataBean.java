package com.ac.avalara.order.bean;

import java.math.BigDecimal;
import java.util.Properties;
import java.util.Vector;

import com.ac.avalara.settings.ACAvalaraConstants;
import com.ac.commerce.util.configuration.ACPropertyLoader;
import com.ac.commerce.util.configuration.ACPropertyLoaderFactory;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.base.objects.ServerJDBCHelperBean;
import com.ibm.commerce.beans.SmartDataBean;
import com.ibm.commerce.beans.SmartDataBeanImpl;

public class ACAvalaraConfigurationDataBean extends SmartDataBeanImpl implements SmartDataBean {
	
	private static final ACLogger LOGGER = new ACLogger(ACAvalaraConfigurationDataBean.class);
	private static ACPropertyLoader propertyLoader = ACPropertyLoaderFactory.getInstance();
	private static Properties avalaraTaxProperties = propertyLoader.getProperties(ACAvalaraConstants.AVALARA_TAX_PROPERTIES);
	
	
	
		
	
	
	private static String GET_AVA_CONFIG = "select URLTOCONNECT,ACCNUM,COMPANYCODE,TAXCALCULATIONMODE,TRANSACTIONLOGGING,TRANSLOGKEEPHOURS,SUPPORTEDCOUNTRIES,TAXCOUNTRIES,ADDROUNTRIES,BEHAVIORONERROR,DEFAULTTAX,ADDRVALIDATIONPLACES,CUSTOMERVATID,PRICECONTAINSTAXES,LOGREQUESTTYPES,AUTHKEY,TAXCODEIDENTIFIER,DAPCOUNTRIES,DDPCOUNTRIES,ORDERITEMTAXESDISPLAYED from X_AVATAX_CONF where STOREENT_ID=?";
	private Integer storeentId;
	private String urlToConnect;
	private String accNum;
	private String companyCode;
	private Integer timeout;
	private String taxCalculationMode;
	private boolean transactionLogging;
	private Integer transLogKeepHours;
	private String supportedCountries;
	private String behavioronError;
	private BigDecimal defaultTax;
	private boolean addrValidationRegPage;
	private boolean addrValidationMyAcc;
	private boolean addrValidationQP;
	private boolean addrValidationCheckout;
	private boolean customerVatId;
	private boolean priceContainsTaxes;
	private boolean orderItemTaxesDisplayed;
	private String logRequestTypes;
	private String authKey;
	private String taxCodeIdentifier;
	private Integer optCounter;
	private String taxCountries;
	private String addrCountries;
	private String dapCountries;
	private String ddpCountries;
	private String htsCodeIdentifier;
	private String unitAmountIdentifier;
	private String unitNameIdentifier;
	
	@Override
	public void populate() throws Exception {
		String methodName = "populate()";
		try {
			ServerJDBCHelperBean jdbcHelper = new ServerJDBCHelperBean();
			
            Vector<Vector<?>> vRecords = jdbcHelper.executeParameterizedQuery(GET_AVA_CONFIG, new Object[]{getCommandContext().getStoreId()});
            if (vRecords != null && !vRecords.isEmpty()) {
                for (Vector<?> oRecord : vRecords) {
                	this.urlToConnect = (String) oRecord.get(0);
                	this.accNum = (String) oRecord.get(1);
                	this.companyCode = (String) oRecord.get(2);
                	this.timeout = Integer.valueOf(avalaraTaxProperties.getProperty(ACAvalaraConstants.API_TIMEOUT));
                	this.taxCalculationMode = (String) oRecord.get(3);
                	this.transactionLogging = (Integer) oRecord.get(4) == 1 ? true : false;
                	this.transLogKeepHours = (Integer) oRecord.get(5);
                	this.supportedCountries = (String) oRecord.get(6);
                	this.taxCountries = (String) oRecord.get(7);
                	this.addrCountries = (String) oRecord.get(8);
                	this.behavioronError = (String) oRecord.get(9);
                	this.defaultTax = (BigDecimal) oRecord.get(10);
                	String addrValidationPages = (String) oRecord.get(11);
                	if (addrValidationPages != null){
	                	this.addrValidationRegPage = addrValidationPages.contains("REGPAGE");
	                	this.addrValidationMyAcc = addrValidationPages.contains("MY_ACCOUNT");
	                	this.addrValidationQP = addrValidationPages.contains("QP");
	                	this.addrValidationCheckout = addrValidationPages.contains("CHECKOUT");
                	} else {
                		this.addrValidationRegPage = false;
	                	this.addrValidationMyAcc = false;
	                	this.addrValidationQP = false;
	                	this.addrValidationCheckout = false;
                	}
                	this.customerVatId = (Integer) oRecord.get(12) == 1 ? true : false;
                	this.priceContainsTaxes = (Integer) oRecord.get(13) == 1 ? true : false;
                	this.logRequestTypes = (String) oRecord.get(14);
                	this.authKey = (String) oRecord.get(15);
                	this.taxCodeIdentifier = (String) oRecord.get(16);
                	this.dapCountries = (String) oRecord.get(17);
                	this.ddpCountries = (String) oRecord.get(18);
                	this.orderItemTaxesDisplayed = 1 == (Integer) oRecord.get(19) ? true : false;
                }
            } else { 
            	this.urlToConnect = avalaraTaxProperties.getProperty(ACAvalaraConstants.API_URL);
            	this.accNum = avalaraTaxProperties.getProperty(ACAvalaraConstants.API_ACCOUNT);
            	this.companyCode = avalaraTaxProperties.getProperty(ACAvalaraConstants.API_COMPANYCODE);
            	this.authKey = avalaraTaxProperties.getProperty(ACAvalaraConstants.API_AUTH_KEY);
            	this.timeout = Integer.valueOf(avalaraTaxProperties.getProperty(ACAvalaraConstants.API_TIMEOUT));
            	this.taxCalculationMode = String.valueOf(avalaraTaxProperties.getProperty(ACAvalaraConstants.TAX_CALCULATION_MODE));
            	this.transactionLogging = avalaraTaxProperties.getProperty(ACAvalaraConstants.API_COMPANYCODE).equals("1") ? true : false;
            	this.transLogKeepHours = Integer.valueOf(avalaraTaxProperties.getProperty(ACAvalaraConstants.LOG_KEEP_HOURS));
            	this.supportedCountries = avalaraTaxProperties.getProperty(ACAvalaraConstants.ADDRESS_VALIDATION_COUNTRY_SUPPORT);
            	this.addrCountries = avalaraTaxProperties.getProperty(ACAvalaraConstants.ADDRESS_VALIDATION_COUNTRY_SUPPORT);
            	this.taxCountries = avalaraTaxProperties.getProperty(ACAvalaraConstants.ADDRESS_VALIDATION_COUNTRY_SUPPORT);
            	this.behavioronError = avalaraTaxProperties.getProperty(ACAvalaraConstants.BEHAVIOUR_ON_ERROR);
            	this.defaultTax = BigDecimal.valueOf(Double.valueOf(avalaraTaxProperties.getProperty(ACAvalaraConstants.DEFAULT_TAX_RATE)));
            	this.addrValidationRegPage = true;
            	this.addrValidationMyAcc = true;
            	this.addrValidationQP = true;
            	this.addrValidationCheckout = true;
            	this.customerVatId = Boolean.valueOf(avalaraTaxProperties.getProperty(ACAvalaraConstants.VAT_ID_CONFIGURATION_ENABLED));
            	this.priceContainsTaxes = Boolean.valueOf(avalaraTaxProperties.getProperty(ACAvalaraConstants.PRICES_INCLUDE_TAXES));
            	this.logRequestTypes = avalaraTaxProperties.getProperty(ACAvalaraConstants.LOG_REQUEST_TYPE);
            	this.taxCodeIdentifier = avalaraTaxProperties.getProperty(ACAvalaraConstants.TAX_CODE_IDENTIFIER);
            	this.dapCountries = avalaraTaxProperties.getProperty(ACAvalaraConstants.LANDED_COST_DAP_COUNTRY_SUPPORT);
            	this.ddpCountries = avalaraTaxProperties.getProperty(ACAvalaraConstants.LANDED_COST_DDP_COUNTRY_SUPPORT);
            	this.orderItemTaxesDisplayed = Boolean.valueOf(avalaraTaxProperties.getProperty(ACAvalaraConstants.ENABLE_TAX_DISPLAY_FOR_LINE_ITEM));
            }
            this.htsCodeIdentifier = avalaraTaxProperties.getProperty(ACAvalaraConstants.AVALARA_HTS_ATTRIBUTE_PREFIX);
            this.unitAmountIdentifier = avalaraTaxProperties.getProperty(ACAvalaraConstants.AVALARA_LANDED_COST_UNITAMOUNT_PREFIX);
            this.unitNameIdentifier = avalaraTaxProperties.getProperty(ACAvalaraConstants.AVALARA_LANDED_COST_UNITNAME_PREFIX);
		}catch (Exception e){			
			LOGGER.error(methodName, e.getMessage(), e);
		}
	}

	public Integer getStoreentId() {
		return storeentId;
	}

	public void setStoreentId(Integer storeentId) {
		this.storeentId = storeentId;
	}

	public String getUrlToConnect() {
		return urlToConnect;
	}

	public void setUrlToConnect(String urlToConnect) {
		this.urlToConnect = urlToConnect;
	}

	public String getAccNum() {
		return accNum;
	}

	public void setAccNum(String accNum) {
		this.accNum = accNum;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public Integer getTimeout() {
		return timeout;
	}

	public void setTimeout(Integer timeout) {
		this.timeout = timeout;
	}

	public String getTaxCalculationMode() {
		return taxCalculationMode;
	}

	public void setTaxCalculationMode(String taxCalculationMode) {
		this.taxCalculationMode = taxCalculationMode;
	}

	public boolean getTransactionLogging() {
		return transactionLogging;
	}

	public void setTransactionLogging(boolean transactionLogging) {
		this.transactionLogging = transactionLogging;
	}

	public Integer getTransLogKeepHours() {
		return transLogKeepHours;
	}

	public void setTransLogKeepHours(Integer transLogKeepHours) {
		this.transLogKeepHours = transLogKeepHours;
	}

	public String getSupportedCountries() {
		return supportedCountries;
	}

	public void setSupportedCountries(String supportedCountries) {
		this.supportedCountries = supportedCountries;
	}

	public String getBehavioronError() {
		return behavioronError;
	}

	public void setBehavioronError(String behavioronError) {
		this.behavioronError = behavioronError;
	}

	public BigDecimal getDefaultTax() {
		return defaultTax;
	}

	public void setDefaultTax(BigDecimal defaultTax) {
		this.defaultTax = defaultTax;
	}

	public boolean isAddrValidationRegPage() {
		return addrValidationRegPage;
	}

	public void setAddrValidationRegPage(boolean addrValidationRegPage) {
		this.addrValidationRegPage = addrValidationRegPage;
	}

	public boolean isAddrValidationMyAcc() {
		return addrValidationMyAcc;
	}

	public void setAddrValidationMyAcc(boolean addrValidationMyAcc) {
		this.addrValidationMyAcc = addrValidationMyAcc;
	}

	public boolean isAddrValidationQP() {
		return addrValidationQP;
	}

	public void setAddrValidationQP(boolean addrValidationQP) {
		this.addrValidationQP = addrValidationQP;
	}

	public boolean isAddrValidationCheckout() {
		return addrValidationCheckout;
	}

	public void setAddrValidationCheckout(boolean addrValidationCheckout) {
		this.addrValidationCheckout = addrValidationCheckout;
	}

	public boolean isCustomerVatId() {
		return customerVatId;
	}

	public void setCustomerVatId(boolean customerVatId) {
		this.customerVatId = customerVatId;
	}

	public boolean isPriceContainsTaxes() {
		return priceContainsTaxes;
	}

	public void setPriceContainsTaxes(boolean priceContainsTaxes) {
		this.priceContainsTaxes = priceContainsTaxes;
	}

	public String getLogRequestTypes() {
		return logRequestTypes;
	}

	public void setLogRequestTypes(String logRequestTypes) {
		this.logRequestTypes = logRequestTypes;
	}
	public boolean isLogPingRequest(){
		return logRequestTypes != null ? this.logRequestTypes.contains("PING") : false;
	}
	public boolean isLogValidateRequest(){
		return logRequestTypes != null ? this.logRequestTypes.contains("VALIDATE_ADDRESS") : false;
	}
	public boolean isLogCalculateRequest(){
		return logRequestTypes != null ? this.logRequestTypes.contains("CALCULATE_TAXES") : false;
	}
	
	public boolean isLogCancelRequest(){
		return this.logRequestTypes != null ? this.logRequestTypes.contains("CANCEL_TAXES") : false;
	}
	public String getAuthKey() {
		return authKey;
	}
	public void setAuthKey(String authKey) {
		this.authKey = authKey;
	}
	public String getTaxCodeIdentifier() {
		return taxCodeIdentifier;
	}
	public void setTaxCodeIdentifier(String taxCodeIdentifier) {
		this.taxCodeIdentifier = taxCodeIdentifier;
	}
	
	public String getTaxCountries() {
		return taxCountries;
	}
	public void setTaxCountries(String taxCountries) {
		this.taxCountries = taxCountries;
	}
	public String getAddrCountries() {
		return addrCountries;
	}
	public void setAddrCountries(String addrCountries) {
		this.addrCountries = addrCountries;
	}

	public String getDapCountries() {
		return dapCountries;
	}

	public void setDapCountries(String dapCountries) {
		this.dapCountries = dapCountries;
	}

	public String getDdpCountries() {
		return ddpCountries;
	}

	public void setDdpCountries(String ddpCountries) {
		this.ddpCountries = ddpCountries;
	}

	public boolean isOrderItemTaxesDisplayed() {
		return orderItemTaxesDisplayed;
	}

	public void setOrderItemTaxesDisplayed(boolean orderItemTaxesDisplayed) {
		this.orderItemTaxesDisplayed = orderItemTaxesDisplayed;
	}
	
	public String getHtsCodeIdentifier() {
		return htsCodeIdentifier;
	}

	public String getUnitAmountIdentifier() {
		return this.unitAmountIdentifier;
	}

	public String getUnitNameIdentifier() {
		return this.unitNameIdentifier;
	}
}
