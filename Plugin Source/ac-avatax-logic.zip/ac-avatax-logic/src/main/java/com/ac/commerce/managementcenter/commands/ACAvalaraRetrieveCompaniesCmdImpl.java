package com.ac.commerce.managementcenter.commands;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import net.avalara.avatax.rest.client.AvaTaxClient;
import net.avalara.avatax.rest.client.AvaTaxClientException;
import net.avalara.avatax.rest.client.FetchResult;
import net.avalara.avatax.rest.client.models.CompanyModel;

import com.ac.avalara.settings.ACAvalaraConstants;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.command.ControllerCommandImpl;
import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.exception.ECException;

@SuppressWarnings("serial")
public class ACAvalaraRetrieveCompaniesCmdImpl extends ControllerCommandImpl implements ACAvalaraRetrieveCompaniesCmd  {
    private static final ACLogger LOGGER = new ACLogger(ACAvalaraRetrieveCompaniesCmdImpl.class);
      
    @Override
    public final void performExecute() throws ECException {
    	String methodName = "performExecute";
        LOGGER.entering(methodName);
        TypedProperty rspProp = new TypedProperty();
       
    	try {
	        rspProp.put("companies",  fetchCompanies());
		} catch (AvaTaxClientException e) {
			LOGGER.error(methodName, e.getMessage(), e);
			rspProp.put("companies", new ArrayList<CompanyModel>());
		} catch (Exception e) {			
	        LOGGER.error(methodName, e.getMessage(), e);
	        rspProp.put("companies", new ArrayList<CompanyModel>());	        
		}
    	
        setResponseProperties(rspProp);
        LOGGER.exiting(methodName);    	
    }
    
    protected List<CompanyModel> fetchCompanies() throws Exception  {
    	String avalaraApiKey = this.getRequestProperties().getString("avalaraApiKey", "");
 		String avalaraLicenseKey = this.getRequestProperties().getString("avalaraLicenseKey", "");
 		String avalaraServiceURL = this.getRequestProperties().getString("avalaraServiceURL", "");
 		
 		if(StringUtils.isEmpty(avalaraApiKey) || StringUtils.isEmpty(avalaraLicenseKey) ||  StringUtils.isEmpty(avalaraServiceURL)) { 			
 			return new ArrayList<CompanyModel>();
 		}
 		
 		AvaTaxClient client = new AvaTaxClient(ACAvalaraConstants.CLNT_APP_NAME, ACAvalaraConstants.CLNT_APP_VERSION, "localhost", avalaraServiceURL).withSecurity(avalaraApiKey, avalaraLicenseKey);
        FetchResult<CompanyModel> companies = client.queryCompanies("", "", 0, 0, "companyCode ASC");
        return companies.getValue();    	
    }
}
