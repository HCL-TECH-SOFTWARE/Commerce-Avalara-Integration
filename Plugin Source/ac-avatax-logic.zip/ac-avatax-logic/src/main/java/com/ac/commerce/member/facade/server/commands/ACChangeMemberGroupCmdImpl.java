package com.ac.commerce.member.facade.server.commands;

import java.util.Map;
import java.util.Set;

import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.foundation.common.exception.AbstractApplicationException;
import com.ibm.commerce.member.facade.server.commands.ChangeMemberGroupCmd;
import com.ibm.commerce.member.facade.server.commands.ChangeMemberGroupCmdImpl;

public class ACChangeMemberGroupCmdImpl extends ChangeMemberGroupCmdImpl implements ChangeMemberGroupCmd {

	private static final ACLogger LOGGER = new ACLogger(ACChangeMemberGroupBasePartCmdImpl.class);
	
	@Override
	protected void save(Map persistentObjects)
			throws AbstractApplicationException {
		String METHODNAME = "save(Map persistentObjects)";
		LOGGER.entering(METHODNAME);
		
		super.save(persistentObjects);
		
		LOGGER.exiting(METHODNAME);
	}

	@Override
	protected void validate(Map nounsAndActions, Map persistentObjects)
			throws AbstractApplicationException {
		String METHODNAME = "save(Map persistentObjects)";
		LOGGER.entering(METHODNAME);
		
		super.validate(nounsAndActions, persistentObjects);
		
		LOGGER.exiting(METHODNAME);
	}

	@Override
	protected Map read(Set nouns) throws AbstractApplicationException {
		String METHODNAME = "read(Set nouns)";
		LOGGER.entering(METHODNAME);
		
		Map res = super.read(nouns);
		
		LOGGER.exiting(METHODNAME);
		return res;
	}

	
	
}
