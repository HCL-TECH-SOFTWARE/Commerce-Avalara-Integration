package com.ac.commerce.order.commands;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.order.bean.ACAvalaraTaxDetails;
import com.ac.avalara.order.bean.ACAvalaraTaxDetailsDataBean;
import com.ac.avalara.order.bean.ACAvalaraTaxDetailsType;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.exception.ECSystemException;
import com.ibm.commerce.order.commands.GetOrderTotalAmountCmd;
import com.ibm.commerce.order.commands.GetOrderTotalAmountCmdImpl;
import com.ibm.commerce.order.objects.OrderAccessBean;
import com.ibm.commerce.ras.ECMessage;
import com.ibm.commerce.ras.ECTrace;
import com.ibm.commerce.ras.ECTraceIdentifiers;

public class ACGetOrderTotalAmountCmdImpl extends GetOrderTotalAmountCmdImpl implements GetOrderTotalAmountCmd {
private static final String CLASS_NAME = ACGetOrderTotalAmountCmdImpl.class.getName(); 
	private BigDecimal idTotalAmount;
	private OrderAccessBean iabOrder;

	public ACGetOrderTotalAmountCmdImpl() {
		iabOrder = null;

		idTotalAmount = new BigDecimal(0);
	}

	@Override
	public void performExecute() throws ECException {
		String methodName = "performExecute";
		if (ECTrace.traceEnabled(3L))
			ECTrace.entry(3L, CLASS_NAME, "performExecute");

		try {
			if (getOrder() != null) {
				if (ECTrace.traceEnabled(ECTraceIdentifiers.COMPONENT_ORDER)) {
					ECTrace.trace(ECTraceIdentifiers.COMPONENT_ORDER, CLASS_NAME, methodName, (new StringBuilder("Product total = ")).append(getOrder().getTotalProductPriceInEntityType()).toString());
					ECTrace.trace(ECTraceIdentifiers.COMPONENT_ORDER, CLASS_NAME, methodName, (new StringBuilder("Total tax = ")).append(getOrder().getTotalTaxInEntityType()).toString());
					ECTrace.trace(ECTraceIdentifiers.COMPONENT_ORDER, CLASS_NAME, methodName, (new StringBuilder("Shipping total = ")).append(getOrder().getTotalShippingChargeInEntityType()).toString());
					ECTrace.trace(ECTraceIdentifiers.COMPONENT_ORDER, CLASS_NAME, methodName, (new StringBuilder("Shipping tax total = ")).append(getOrder().getTotalShippingTaxInEntityType()).toString());
					ECTrace.trace(ECTraceIdentifiers.COMPONENT_ORDER, CLASS_NAME, methodName, (new StringBuilder("Adjustment total = ")).append(getOrder().getTotalAdjustmentInEntityType()).toString());

				}
				ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
				bean.setCommandContext(commandContext);
				bean.populate();
				ACAvalaraSettings settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);

				idTotalAmount = getOrder().getTotalProductPriceInEntityType();
				if (!settings.getTaxIncluded()) {
					idTotalAmount = idTotalAmount.add(getOrder().getTotalTaxInEntityType());
					idTotalAmount = idTotalAmount.add(getOrder().getTotalShippingTaxInEntityType());
					
					ACAvalaraTaxDetailsDataBean orderTaxDetailsDataBean = new ACAvalaraTaxDetailsDataBean();
					List<ACAvalaraTaxDetails> details = new ArrayList<ACAvalaraTaxDetails>();
					
					orderTaxDetailsDataBean.setOrderId(getOrder().getOrderIdInEntityType());
					orderTaxDetailsDataBean.setCommandContext(getCommandContext());
					orderTaxDetailsDataBean.populate();
					
					for (ACAvalaraTaxDetails detail : orderTaxDetailsDataBean.getDetails()) {
						if (ACAvalaraTaxDetailsType.CD.equals(detail.getType()) || ACAvalaraTaxDetailsType.CF.equals(detail.getType())) {
							if (ECTrace.traceEnabled(ECTraceIdentifiers.COMPONENT_ORDER)) {
								ECTrace.trace(ECTraceIdentifiers.COMPONENT_ORDER, CLASS_NAME, methodName, (new StringBuilder(ACAvalaraTaxDetailsType.CD.equals(detail.getType()) ? "Customs duties = " : "Customs fees = ")).append(detail.getTax()).toString());

							}							
							idTotalAmount = idTotalAmount.add(new BigDecimal(detail.getTax()));					
						} 
					}					
					
					
				}
				idTotalAmount = idTotalAmount.add(getOrder().getTotalShippingChargeInEntityType());
				idTotalAmount = idTotalAmount.add(getOrder().getTotalAdjustmentInEntityType());

				ECTrace.trace(ECTraceIdentifiers.COMPONENT_ORDER, CLASS_NAME, methodName, (new StringBuilder("idTotalAmount = ")).append(idTotalAmount).toString());
			}
		} catch (CreateException e) {
			throw new ECSystemException(ECMessage._ERR_CREATE_EXCEPTION, "com.ibm.commerce.order.commands.GetOrderTotalAmountCmdImpl", "performExecute", new Object[] { e.toString() }, e);
		} catch (FinderException e) {
			throw new ECSystemException(ECMessage._ERR_FINDER_EXCEPTION, "com.ibm.commerce.order.commands.GetOrderTotalAmountCmdImpl", "performExecute", new Object[] { e.toString() }, e);
		} catch (NamingException e) {
			throw new ECSystemException(ECMessage._ERR_NAMING_EXCEPTION, "com.ibm.commerce.order.commands.GetOrderTotalAmountCmdImpl", "performExecute", new Object[] { e.toString() }, e);
		} catch (RemoteException e) {
			throw new ECSystemException(ECMessage._ERR_REMOTE_EXCEPTION, "com.ibm.commerce.order.commands.GetOrderTotalAmountCmdImpl", "performExecute", new Object[] { e.toString() }, e);
		} catch (Exception e) {
			throw new ECApplicationException(e);
		}

		if (ECTrace.traceEnabled(3L))
			if (ECTrace.traceEnabled(3L))
				ECTrace.exit(3L, "com.ibm.commerce.order.commands.GetOrderTotalAmountCmdImpl", "performExecute");
		ECTrace.exit(3L, "com.ibm.commerce.order.commands.GetOrderTotalAmountCmdImpl", "performExecute");

	}

	public void reset() {
		super.reset();
		iabOrder = null;
		idTotalAmount = new BigDecimal(0);
	}

	public OrderAccessBean getOrder() {
		return iabOrder;
	}

	public BigDecimal getTotalAmount() {
		return idTotalAmount;
	}

	public void setOrder(OrderAccessBean aabOrder) {
		iabOrder = aabOrder;
	}

}
