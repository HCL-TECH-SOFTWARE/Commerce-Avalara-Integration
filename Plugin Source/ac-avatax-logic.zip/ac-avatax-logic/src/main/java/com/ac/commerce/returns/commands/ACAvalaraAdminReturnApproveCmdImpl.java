package com.ac.commerce.returns.commands;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ac.commerce.order.commands.ACAvalaraCommitTransactionTaskCmd;
import com.ac.commerce.util.CommandFactory;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.returns.commands.AdminReturnApproveCmd;
import com.ibm.commerce.returns.commands.AdminReturnApproveCmdImpl;

public class ACAvalaraAdminReturnApproveCmdImpl extends AdminReturnApproveCmdImpl implements AdminReturnApproveCmd {
	private final ACLogger LOGGER = new ACLogger(ACAvalaraAdminReturnApproveCmdImpl.class);
	@Override
	public void performExecute() throws ECException {
		String methodName = "performExecute";
		super.performExecute();
		
		
		ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
		bean.setCommandContext(commandContext);
		try {
			bean.populate();
		} catch (Exception e) {

			
			LOGGER.error(methodName, "Error occured while loading avatax configuration:" + e.getMessage());
		}
		ACAvalaraSettings settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);

		if (settings.isTaxSubmissionEnabled()) {
			try {
				if ("APP".equals(getRMAAB().getStatus())) {
					ACAvalaraCommitTransactionTaskCmd task = CommandFactory.createTask(ACAvalaraCommitTransactionTaskCmd.class, commandContext);
					task.setOrderId(getRMAAB().getRmaIdInEntityType());
					task.execute();
				}
			} catch (Exception e) {
				throw new ECApplicationException(e);
			}
		}		
	}

}
