package com.ac.commerce.returns.commands;

import java.util.Vector;

import com.ibm.commerce.command.TaskCommand;

public interface ACAvalaraReturnTaxTaskCmd extends TaskCommand {
    String NAME = ACAvalaraReturnTaxTaskCmd.class.getName();
    String defaultCommandClassName = ACAvalaraReturnTaxTaskCmdImpl.class.getName();

	void setRmaID(String string);
	void setRmaItems(Vector vRMAItems);
	void setOrderId(String orderId);
}
