package com.ac.commerce.usermanagement.commands;

import com.ac.avalara.settings.ACAvalaraSettings;
import com.ibm.commerce.command.TaskCommand;

public interface ACAvalaraUserAddUpdateTaskCmd extends TaskCommand {
    String NAME = ACAvalaraUserAddUpdateTaskCmd.class.getName();
    String defaultCommandClassName = ACAvalaraUserAddUpdateTaskCmdImpl.class.getName();

	void setSettings(ACAvalaraSettings settings);
}
