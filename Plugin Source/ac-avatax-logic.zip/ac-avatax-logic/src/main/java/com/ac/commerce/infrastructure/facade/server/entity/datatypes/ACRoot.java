/**
 */
package com.ac.commerce.infrastructure.facade.server.entity.datatypes;

import com.ibm.commerce.infrastructure.facade.server.entity.datatypes.InfrastructureRoot;

import java.util.List;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>AC Root</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACRoot#getX_avatax_conf <em>Xavatax conf</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACRoot#getACStoreent <em>AC Storeent</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getACRoot()
 * @model
 * @generated
 */
public interface ACRoot extends InfrastructureRoot
{
  /**
   * Returns the value of the '<em><b>Xavatax conf</b></em>' containment reference list.
   * The list contents are of type {@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Xavatax conf</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Xavatax conf</em>' containment reference list.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getACRoot_X_avatax_conf()
   * @model type="com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf" containment="true"
   * @generated
   */
  List getX_avatax_conf();

  /**
   * Returns the value of the '<em><b>AC Storeent</b></em>' containment reference list.
   * The list contents are of type {@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACStoreent}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>AC Storeent</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>AC Storeent</em>' containment reference list.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getACRoot_ACStoreent()
   * @model type="com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACStoreent" containment="true"
   * @generated
   */
  List getACStoreent();

} // ACRoot
