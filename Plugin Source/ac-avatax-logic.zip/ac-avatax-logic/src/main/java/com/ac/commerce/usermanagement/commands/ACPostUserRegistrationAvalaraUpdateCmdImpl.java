package com.ac.commerce.usermanagement.commands;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ac.commerce.util.CommandFactory;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.usermanagement.commands.PostUserRegistrationUpdateCmdImpl;

/**
 * This class extends PostUserRegistrationUpdateCmdImpl to implement Customer Tax Exemption logic during profile update.
 * 
 * @author ASkosyr
 */
@SuppressWarnings("serial")
public class ACPostUserRegistrationAvalaraUpdateCmdImpl extends PostUserRegistrationUpdateCmdImpl {
    private static final ACLogger LOGGER = new ACLogger(ACPostUserRegistrationAvalaraUpdateCmdImpl.class);

    @Override
    public void performExecute() throws ECException {
        String methodName = "performExecute";
        LOGGER.entering(methodName);

        super.performExecute();

        updateUserInfoIfCustomerVatIdEnabled();

        LOGGER.exiting(methodName);
    }
    
    private void updateUserInfoIfCustomerVatIdEnabled() throws ECException {
        final String METHOD_NAME = "updateAvalaraTaxExemptionIfAvalaraIsTurnedOn";
        LOGGER.entering(METHOD_NAME);

        ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
    	bean.setCommandContext(getCommandContext());
    	try {
			bean.populate();
			ACAvalaraSettings settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);
	        if (settings.getCustomerVatIdEnabled()) {
	            ACAvalaraUserAddUpdateTaskCmd task = CommandFactory.createTask(ACAvalaraUserAddUpdateTaskCmd.class, getCommandContext());
	            task.setSettings(settings);
	            task.execute();
	        }
		} catch (Exception e) {
			LOGGER.error(METHOD_NAME, "Exception occured while updating custom user's avalara information: " + e.getMessage());
		}

        LOGGER.exiting(METHOD_NAME);
    }

}
