/**
 */
package com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl;

import com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage;
import com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACStoreent;
import com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf;

import java.math.BigDecimal;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.sdo.impl.EDataObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Xavatax conf</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getStoreent_id <em>Storeent id</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getUrltoconnect <em>Urltoconnect</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getAccnum <em>Accnum</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getCompanycode <em>Companycode</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getTaxcalculationmode <em>Taxcalculationmode</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getTransactionlogging <em>Transactionlogging</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getTranslogkeephours <em>Translogkeephours</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getSupportedcountries <em>Supportedcountries</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getTaxcountries <em>Taxcountries</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getAddrountries <em>Addrountries</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getBehavioronerror <em>Behavioronerror</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getDefaulttax <em>Defaulttax</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getAddrvalidationplaces <em>Addrvalidationplaces</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getCustomervatid <em>Customervatid</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getPricecontainstaxes <em>Pricecontainstaxes</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getOitaxesdisplayed <em>Oitaxesdisplayed</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getLogrequesttypes <em>Logrequesttypes</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getAuthkey <em>Authkey</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getTaxcodeidentifier <em>Taxcodeidentifier</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getDapcountries <em>Dapcountries</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getDdpcountries <em>Ddpcountries</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getOptcounter <em>Optcounter</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.X_avatax_confImpl#getStoreentForX_avatax_conf <em>Storeent For Xavatax conf</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class X_avatax_confImpl extends EDataObjectImpl implements X_avatax_conf
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final long serialVersionUID = 1L;

  /**
   * The default value of the '{@link #getStoreent_id() <em>Storeent id</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getStoreent_id()
   * @generated
   * @ordered
   */
  protected static final int STOREENT_ID_EDEFAULT = 0;

  /**
   * The cached value of the '{@link #getStoreent_id() <em>Storeent id</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getStoreent_id()
   * @generated
   * @ordered
   */
  protected int storeent_id = STOREENT_ID_EDEFAULT;

  /**
   * The default value of the '{@link #getUrltoconnect() <em>Urltoconnect</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUrltoconnect()
   * @generated
   * @ordered
   */
  protected static final String URLTOCONNECT_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getUrltoconnect() <em>Urltoconnect</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUrltoconnect()
   * @generated
   * @ordered
   */
  protected String urltoconnect = URLTOCONNECT_EDEFAULT;

  /**
   * The default value of the '{@link #getAccnum() <em>Accnum</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAccnum()
   * @generated
   * @ordered
   */
  protected static final String ACCNUM_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getAccnum() <em>Accnum</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAccnum()
   * @generated
   * @ordered
   */
  protected String accnum = ACCNUM_EDEFAULT;

  /**
   * The default value of the '{@link #getCompanycode() <em>Companycode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCompanycode()
   * @generated
   * @ordered
   */
  protected static final String COMPANYCODE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getCompanycode() <em>Companycode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCompanycode()
   * @generated
   * @ordered
   */
  protected String companycode = COMPANYCODE_EDEFAULT;

  /**
   * The default value of the '{@link #getTaxcalculationmode() <em>Taxcalculationmode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTaxcalculationmode()
   * @generated
   * @ordered
   */
  protected static final String TAXCALCULATIONMODE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getTaxcalculationmode() <em>Taxcalculationmode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTaxcalculationmode()
   * @generated
   * @ordered
   */
  protected String taxcalculationmode = TAXCALCULATIONMODE_EDEFAULT;

  /**
   * The default value of the '{@link #getTransactionlogging() <em>Transactionlogging</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTransactionlogging()
   * @generated
   * @ordered
   */
  protected static final short TRANSACTIONLOGGING_EDEFAULT = 0;

  /**
   * The cached value of the '{@link #getTransactionlogging() <em>Transactionlogging</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTransactionlogging()
   * @generated
   * @ordered
   */
  protected short transactionlogging = TRANSACTIONLOGGING_EDEFAULT;

  /**
   * The default value of the '{@link #getTranslogkeephours() <em>Translogkeephours</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTranslogkeephours()
   * @generated
   * @ordered
   */
  protected static final Integer TRANSLOGKEEPHOURS_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getTranslogkeephours() <em>Translogkeephours</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTranslogkeephours()
   * @generated
   * @ordered
   */
  protected Integer translogkeephours = TRANSLOGKEEPHOURS_EDEFAULT;

  /**
   * The default value of the '{@link #getSupportedcountries() <em>Supportedcountries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSupportedcountries()
   * @generated
   * @ordered
   */
  protected static final String SUPPORTEDCOUNTRIES_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getSupportedcountries() <em>Supportedcountries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSupportedcountries()
   * @generated
   * @ordered
   */
  protected String supportedcountries = SUPPORTEDCOUNTRIES_EDEFAULT;

  /**
   * The default value of the '{@link #getTaxcountries() <em>Taxcountries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTaxcountries()
   * @generated
   * @ordered
   */
  protected static final String TAXCOUNTRIES_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getTaxcountries() <em>Taxcountries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTaxcountries()
   * @generated
   * @ordered
   */
  protected String taxcountries = TAXCOUNTRIES_EDEFAULT;

  /**
   * The default value of the '{@link #getAddrountries() <em>Addrountries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAddrountries()
   * @generated
   * @ordered
   */
  protected static final String ADDROUNTRIES_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getAddrountries() <em>Addrountries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAddrountries()
   * @generated
   * @ordered
   */
  protected String addrountries = ADDROUNTRIES_EDEFAULT;

  /**
   * The default value of the '{@link #getBehavioronerror() <em>Behavioronerror</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBehavioronerror()
   * @generated
   * @ordered
   */
  protected static final String BEHAVIORONERROR_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getBehavioronerror() <em>Behavioronerror</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBehavioronerror()
   * @generated
   * @ordered
   */
  protected String behavioronerror = BEHAVIORONERROR_EDEFAULT;

  /**
   * The default value of the '{@link #getDefaulttax() <em>Defaulttax</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDefaulttax()
   * @generated
   * @ordered
   */
  protected static final BigDecimal DEFAULTTAX_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDefaulttax() <em>Defaulttax</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDefaulttax()
   * @generated
   * @ordered
   */
  protected BigDecimal defaulttax = DEFAULTTAX_EDEFAULT;

  /**
   * The default value of the '{@link #getAddrvalidationplaces() <em>Addrvalidationplaces</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAddrvalidationplaces()
   * @generated
   * @ordered
   */
  protected static final String ADDRVALIDATIONPLACES_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getAddrvalidationplaces() <em>Addrvalidationplaces</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAddrvalidationplaces()
   * @generated
   * @ordered
   */
  protected String addrvalidationplaces = ADDRVALIDATIONPLACES_EDEFAULT;

  /**
   * The default value of the '{@link #getCustomervatid() <em>Customervatid</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCustomervatid()
   * @generated
   * @ordered
   */
  protected static final short CUSTOMERVATID_EDEFAULT = 0;

  /**
   * The cached value of the '{@link #getCustomervatid() <em>Customervatid</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCustomervatid()
   * @generated
   * @ordered
   */
  protected short customervatid = CUSTOMERVATID_EDEFAULT;

  /**
   * The default value of the '{@link #getPricecontainstaxes() <em>Pricecontainstaxes</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPricecontainstaxes()
   * @generated
   * @ordered
   */
  protected static final short PRICECONTAINSTAXES_EDEFAULT = 0;

  /**
   * The cached value of the '{@link #getPricecontainstaxes() <em>Pricecontainstaxes</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPricecontainstaxes()
   * @generated
   * @ordered
   */
  protected short pricecontainstaxes = PRICECONTAINSTAXES_EDEFAULT;

  /**
   * The default value of the '{@link #getOitaxesdisplayed() <em>Oitaxesdisplayed</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOitaxesdisplayed()
   * @generated
   * @ordered
   */
  protected static final short OITAXESDISPLAYED_EDEFAULT = 0;

  /**
   * The cached value of the '{@link #getOitaxesdisplayed() <em>Oitaxesdisplayed</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOitaxesdisplayed()
   * @generated
   * @ordered
   */
  protected short oitaxesdisplayed = OITAXESDISPLAYED_EDEFAULT;

  /**
   * The default value of the '{@link #getLogrequesttypes() <em>Logrequesttypes</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLogrequesttypes()
   * @generated
   * @ordered
   */
  protected static final String LOGREQUESTTYPES_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getLogrequesttypes() <em>Logrequesttypes</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLogrequesttypes()
   * @generated
   * @ordered
   */
  protected String logrequesttypes = LOGREQUESTTYPES_EDEFAULT;

  /**
   * The default value of the '{@link #getAuthkey() <em>Authkey</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAuthkey()
   * @generated
   * @ordered
   */
  protected static final String AUTHKEY_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getAuthkey() <em>Authkey</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAuthkey()
   * @generated
   * @ordered
   */
  protected String authkey = AUTHKEY_EDEFAULT;

  /**
   * The default value of the '{@link #getTaxcodeidentifier() <em>Taxcodeidentifier</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTaxcodeidentifier()
   * @generated
   * @ordered
   */
  protected static final String TAXCODEIDENTIFIER_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getTaxcodeidentifier() <em>Taxcodeidentifier</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTaxcodeidentifier()
   * @generated
   * @ordered
   */
  protected String taxcodeidentifier = TAXCODEIDENTIFIER_EDEFAULT;

  /**
   * The default value of the '{@link #getDapcountries() <em>Dapcountries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDapcountries()
   * @generated
   * @ordered
   */
  protected static final String DAPCOUNTRIES_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDapcountries() <em>Dapcountries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDapcountries()
   * @generated
   * @ordered
   */
  protected String dapcountries = DAPCOUNTRIES_EDEFAULT;

  /**
   * The default value of the '{@link #getDdpcountries() <em>Ddpcountries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDdpcountries()
   * @generated
   * @ordered
   */
  protected static final String DDPCOUNTRIES_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDdpcountries() <em>Ddpcountries</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDdpcountries()
   * @generated
   * @ordered
   */
  protected String ddpcountries = DDPCOUNTRIES_EDEFAULT;

  /**
   * The default value of the '{@link #getOptcounter() <em>Optcounter</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOptcounter()
   * @generated
   * @ordered
   */
  protected static final short OPTCOUNTER_EDEFAULT = 0;

  /**
   * The cached value of the '{@link #getOptcounter() <em>Optcounter</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOptcounter()
   * @generated
   * @ordered
   */
  protected short optcounter = OPTCOUNTER_EDEFAULT;

  /**
   * The cached value of the '{@link #getStoreentForX_avatax_conf() <em>Storeent For Xavatax conf</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getStoreentForX_avatax_conf()
   * @generated
   * @ordered
   */
  protected ACStoreent storeentForX_avatax_conf;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final int EOFFSET_CORRECTION_STOREENT_FOR_XAVATAX_CONF_OPPOSITE = ACEntityPackage.Literals.AC_STOREENT.getFeatureID(ACEntityPackage.Literals.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT) - ACEntityPackage.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected X_avatax_confImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass()
  {
    return ACEntityPackage.Literals.XAVATAX_CONF;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getStoreent_id()
  {
    return storeent_id;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setStoreent_id(int newStoreent_id)
  {
    int oldStoreent_id = storeent_id;
    storeent_id = newStoreent_id;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__STOREENT_ID, oldStoreent_id, storeent_id));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getUrltoconnect()
  {
    return urltoconnect;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setUrltoconnect(String newUrltoconnect)
  {
    String oldUrltoconnect = urltoconnect;
    urltoconnect = newUrltoconnect;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__URLTOCONNECT, oldUrltoconnect, urltoconnect));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getAccnum()
  {
    return accnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAccnum(String newAccnum)
  {
    String oldAccnum = accnum;
    accnum = newAccnum;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__ACCNUM, oldAccnum, accnum));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getCompanycode()
  {
    return companycode;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setCompanycode(String newCompanycode)
  {
    String oldCompanycode = companycode;
    companycode = newCompanycode;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__COMPANYCODE, oldCompanycode, companycode));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getTaxcalculationmode()
  {
    return taxcalculationmode;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTaxcalculationmode(String newTaxcalculationmode)
  {
    String oldTaxcalculationmode = taxcalculationmode;
    taxcalculationmode = newTaxcalculationmode;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__TAXCALCULATIONMODE, oldTaxcalculationmode, taxcalculationmode));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public short getTransactionlogging()
  {
    return transactionlogging;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTransactionlogging(short newTransactionlogging)
  {
    short oldTransactionlogging = transactionlogging;
    transactionlogging = newTransactionlogging;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__TRANSACTIONLOGGING, oldTransactionlogging, transactionlogging));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Integer getTranslogkeephours()
  {
    return translogkeephours;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTranslogkeephours(Integer newTranslogkeephours)
  {
    Integer oldTranslogkeephours = translogkeephours;
    translogkeephours = newTranslogkeephours;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__TRANSLOGKEEPHOURS, oldTranslogkeephours, translogkeephours));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getSupportedcountries()
  {
    return supportedcountries;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setSupportedcountries(String newSupportedcountries)
  {
    String oldSupportedcountries = supportedcountries;
    supportedcountries = newSupportedcountries;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__SUPPORTEDCOUNTRIES, oldSupportedcountries, supportedcountries));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getTaxcountries()
  {
    return taxcountries;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTaxcountries(String newTaxcountries)
  {
    String oldTaxcountries = taxcountries;
    taxcountries = newTaxcountries;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__TAXCOUNTRIES, oldTaxcountries, taxcountries));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getAddrountries()
  {
    return addrountries;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAddrountries(String newAddrountries)
  {
    String oldAddrountries = addrountries;
    addrountries = newAddrountries;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__ADDROUNTRIES, oldAddrountries, addrountries));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getBehavioronerror()
  {
    return behavioronerror;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBehavioronerror(String newBehavioronerror)
  {
    String oldBehavioronerror = behavioronerror;
    behavioronerror = newBehavioronerror;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__BEHAVIORONERROR, oldBehavioronerror, behavioronerror));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BigDecimal getDefaulttax()
  {
    return defaulttax;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDefaulttax(BigDecimal newDefaulttax)
  {
    BigDecimal oldDefaulttax = defaulttax;
    defaulttax = newDefaulttax;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__DEFAULTTAX, oldDefaulttax, defaulttax));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getAddrvalidationplaces()
  {
    return addrvalidationplaces;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAddrvalidationplaces(String newAddrvalidationplaces)
  {
    String oldAddrvalidationplaces = addrvalidationplaces;
    addrvalidationplaces = newAddrvalidationplaces;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__ADDRVALIDATIONPLACES, oldAddrvalidationplaces, addrvalidationplaces));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public short getCustomervatid()
  {
    return customervatid;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setCustomervatid(short newCustomervatid)
  {
    short oldCustomervatid = customervatid;
    customervatid = newCustomervatid;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__CUSTOMERVATID, oldCustomervatid, customervatid));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public short getPricecontainstaxes()
  {
    return pricecontainstaxes;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPricecontainstaxes(short newPricecontainstaxes)
  {
    short oldPricecontainstaxes = pricecontainstaxes;
    pricecontainstaxes = newPricecontainstaxes;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__PRICECONTAINSTAXES, oldPricecontainstaxes, pricecontainstaxes));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public short getOitaxesdisplayed()
  {
    return oitaxesdisplayed;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOitaxesdisplayed(short newOitaxesdisplayed)
  {
    short oldOitaxesdisplayed = oitaxesdisplayed;
    oitaxesdisplayed = newOitaxesdisplayed;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__OITAXESDISPLAYED, oldOitaxesdisplayed, oitaxesdisplayed));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getLogrequesttypes()
  {
    return logrequesttypes;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLogrequesttypes(String newLogrequesttypes)
  {
    String oldLogrequesttypes = logrequesttypes;
    logrequesttypes = newLogrequesttypes;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__LOGREQUESTTYPES, oldLogrequesttypes, logrequesttypes));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getAuthkey()
  {
    return authkey;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAuthkey(String newAuthkey)
  {
    String oldAuthkey = authkey;
    authkey = newAuthkey;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__AUTHKEY, oldAuthkey, authkey));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getTaxcodeidentifier()
  {
    return taxcodeidentifier;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTaxcodeidentifier(String newTaxcodeidentifier)
  {
    String oldTaxcodeidentifier = taxcodeidentifier;
    taxcodeidentifier = newTaxcodeidentifier;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__TAXCODEIDENTIFIER, oldTaxcodeidentifier, taxcodeidentifier));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDapcountries()
  {
    return dapcountries;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDapcountries(String newDapcountries)
  {
    String oldDapcountries = dapcountries;
    dapcountries = newDapcountries;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__DAPCOUNTRIES, oldDapcountries, dapcountries));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDdpcountries()
  {
    return ddpcountries;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDdpcountries(String newDdpcountries)
  {
    String oldDdpcountries = ddpcountries;
    ddpcountries = newDdpcountries;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__DDPCOUNTRIES, oldDdpcountries, ddpcountries));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public short getOptcounter()
  {
    return optcounter;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOptcounter(short newOptcounter)
  {
    short oldOptcounter = optcounter;
    optcounter = newOptcounter;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__OPTCOUNTER, oldOptcounter, optcounter));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ACStoreent getStoreentForX_avatax_conf()
  {
    return storeentForX_avatax_conf;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetStoreentForX_avatax_conf(ACStoreent newStoreentForX_avatax_conf, NotificationChain msgs)
  {
    ACStoreent oldStoreentForX_avatax_conf = storeentForX_avatax_conf;
    storeentForX_avatax_conf = newStoreentForX_avatax_conf;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__STOREENT_FOR_XAVATAX_CONF, oldStoreentForX_avatax_conf, newStoreentForX_avatax_conf);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setStoreentForX_avatax_conf(ACStoreent newStoreentForX_avatax_conf)
  {
    if (newStoreentForX_avatax_conf != storeentForX_avatax_conf)
    {
      NotificationChain msgs = null;
      if (storeentForX_avatax_conf != null)
        msgs = ((InternalEObject)storeentForX_avatax_conf).eInverseRemove(this, ACEntityPackage.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT + EOFFSET_CORRECTION_STOREENT_FOR_XAVATAX_CONF_OPPOSITE, ACStoreent.class, msgs);
      if (newStoreentForX_avatax_conf != null)
        msgs = ((InternalEObject)newStoreentForX_avatax_conf).eInverseAdd(this, ACEntityPackage.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT + EOFFSET_CORRECTION_STOREENT_FOR_XAVATAX_CONF_OPPOSITE, ACStoreent.class, msgs);
      msgs = basicSetStoreentForX_avatax_conf(newStoreentForX_avatax_conf, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.XAVATAX_CONF__STOREENT_FOR_XAVATAX_CONF, newStoreentForX_avatax_conf, newStoreentForX_avatax_conf));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ACEntityPackage.XAVATAX_CONF__STOREENT_FOR_XAVATAX_CONF:
        if (storeentForX_avatax_conf != null)
          msgs = ((InternalEObject)storeentForX_avatax_conf).eInverseRemove(this, ACEntityPackage.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT + EOFFSET_CORRECTION_STOREENT_FOR_XAVATAX_CONF_OPPOSITE, ACStoreent.class, msgs);
        return basicSetStoreentForX_avatax_conf((ACStoreent)otherEnd, msgs);
    }
    return super.eInverseAdd(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ACEntityPackage.XAVATAX_CONF__STOREENT_FOR_XAVATAX_CONF:
        return basicSetStoreentForX_avatax_conf(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ACEntityPackage.XAVATAX_CONF__STOREENT_ID:
        return new Integer(getStoreent_id());
      case ACEntityPackage.XAVATAX_CONF__URLTOCONNECT:
        return getUrltoconnect();
      case ACEntityPackage.XAVATAX_CONF__ACCNUM:
        return getAccnum();
      case ACEntityPackage.XAVATAX_CONF__COMPANYCODE:
        return getCompanycode();
      case ACEntityPackage.XAVATAX_CONF__TAXCALCULATIONMODE:
        return getTaxcalculationmode();
      case ACEntityPackage.XAVATAX_CONF__TRANSACTIONLOGGING:
        return new Short(getTransactionlogging());
      case ACEntityPackage.XAVATAX_CONF__TRANSLOGKEEPHOURS:
        return getTranslogkeephours();
      case ACEntityPackage.XAVATAX_CONF__SUPPORTEDCOUNTRIES:
        return getSupportedcountries();
      case ACEntityPackage.XAVATAX_CONF__TAXCOUNTRIES:
        return getTaxcountries();
      case ACEntityPackage.XAVATAX_CONF__ADDROUNTRIES:
        return getAddrountries();
      case ACEntityPackage.XAVATAX_CONF__BEHAVIORONERROR:
        return getBehavioronerror();
      case ACEntityPackage.XAVATAX_CONF__DEFAULTTAX:
        return getDefaulttax();
      case ACEntityPackage.XAVATAX_CONF__ADDRVALIDATIONPLACES:
        return getAddrvalidationplaces();
      case ACEntityPackage.XAVATAX_CONF__CUSTOMERVATID:
        return new Short(getCustomervatid());
      case ACEntityPackage.XAVATAX_CONF__PRICECONTAINSTAXES:
        return new Short(getPricecontainstaxes());
      case ACEntityPackage.XAVATAX_CONF__OITAXESDISPLAYED:
        return new Short(getOitaxesdisplayed());
      case ACEntityPackage.XAVATAX_CONF__LOGREQUESTTYPES:
        return getLogrequesttypes();
      case ACEntityPackage.XAVATAX_CONF__AUTHKEY:
        return getAuthkey();
      case ACEntityPackage.XAVATAX_CONF__TAXCODEIDENTIFIER:
        return getTaxcodeidentifier();
      case ACEntityPackage.XAVATAX_CONF__DAPCOUNTRIES:
        return getDapcountries();
      case ACEntityPackage.XAVATAX_CONF__DDPCOUNTRIES:
        return getDdpcountries();
      case ACEntityPackage.XAVATAX_CONF__OPTCOUNTER:
        return new Short(getOptcounter());
      case ACEntityPackage.XAVATAX_CONF__STOREENT_FOR_XAVATAX_CONF:
        return getStoreentForX_avatax_conf();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ACEntityPackage.XAVATAX_CONF__STOREENT_ID:
        setStoreent_id(((Integer)newValue).intValue());
        return;
      case ACEntityPackage.XAVATAX_CONF__URLTOCONNECT:
        setUrltoconnect((String)newValue);
        return;
      case ACEntityPackage.XAVATAX_CONF__ACCNUM:
        setAccnum((String)newValue);
        return;
      case ACEntityPackage.XAVATAX_CONF__COMPANYCODE:
        setCompanycode((String)newValue);
        return;
      case ACEntityPackage.XAVATAX_CONF__TAXCALCULATIONMODE:
        setTaxcalculationmode((String)newValue);
        return;
      case ACEntityPackage.XAVATAX_CONF__TRANSACTIONLOGGING:
        setTransactionlogging(((Short)newValue).shortValue());
        return;
      case ACEntityPackage.XAVATAX_CONF__TRANSLOGKEEPHOURS:
        setTranslogkeephours((Integer)newValue);
        return;
      case ACEntityPackage.XAVATAX_CONF__SUPPORTEDCOUNTRIES:
        setSupportedcountries((String)newValue);
        return;
      case ACEntityPackage.XAVATAX_CONF__TAXCOUNTRIES:
        setTaxcountries((String)newValue);
        return;
      case ACEntityPackage.XAVATAX_CONF__ADDROUNTRIES:
        setAddrountries((String)newValue);
        return;
      case ACEntityPackage.XAVATAX_CONF__BEHAVIORONERROR:
        setBehavioronerror((String)newValue);
        return;
      case ACEntityPackage.XAVATAX_CONF__DEFAULTTAX:
        setDefaulttax((BigDecimal)newValue);
        return;
      case ACEntityPackage.XAVATAX_CONF__ADDRVALIDATIONPLACES:
        setAddrvalidationplaces((String)newValue);
        return;
      case ACEntityPackage.XAVATAX_CONF__CUSTOMERVATID:
        setCustomervatid(((Short)newValue).shortValue());
        return;
      case ACEntityPackage.XAVATAX_CONF__PRICECONTAINSTAXES:
        setPricecontainstaxes(((Short)newValue).shortValue());
        return;
      case ACEntityPackage.XAVATAX_CONF__OITAXESDISPLAYED:
        setOitaxesdisplayed(((Short)newValue).shortValue());
        return;
      case ACEntityPackage.XAVATAX_CONF__LOGREQUESTTYPES:
        setLogrequesttypes((String)newValue);
        return;
      case ACEntityPackage.XAVATAX_CONF__AUTHKEY:
        setAuthkey((String)newValue);
        return;
      case ACEntityPackage.XAVATAX_CONF__TAXCODEIDENTIFIER:
        setTaxcodeidentifier((String)newValue);
        return;
      case ACEntityPackage.XAVATAX_CONF__DAPCOUNTRIES:
        setDapcountries((String)newValue);
        return;
      case ACEntityPackage.XAVATAX_CONF__DDPCOUNTRIES:
        setDdpcountries((String)newValue);
        return;
      case ACEntityPackage.XAVATAX_CONF__OPTCOUNTER:
        setOptcounter(((Short)newValue).shortValue());
        return;
      case ACEntityPackage.XAVATAX_CONF__STOREENT_FOR_XAVATAX_CONF:
        setStoreentForX_avatax_conf((ACStoreent)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ACEntityPackage.XAVATAX_CONF__STOREENT_ID:
        setStoreent_id(STOREENT_ID_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__URLTOCONNECT:
        setUrltoconnect(URLTOCONNECT_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__ACCNUM:
        setAccnum(ACCNUM_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__COMPANYCODE:
        setCompanycode(COMPANYCODE_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__TAXCALCULATIONMODE:
        setTaxcalculationmode(TAXCALCULATIONMODE_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__TRANSACTIONLOGGING:
        setTransactionlogging(TRANSACTIONLOGGING_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__TRANSLOGKEEPHOURS:
        setTranslogkeephours(TRANSLOGKEEPHOURS_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__SUPPORTEDCOUNTRIES:
        setSupportedcountries(SUPPORTEDCOUNTRIES_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__TAXCOUNTRIES:
        setTaxcountries(TAXCOUNTRIES_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__ADDROUNTRIES:
        setAddrountries(ADDROUNTRIES_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__BEHAVIORONERROR:
        setBehavioronerror(BEHAVIORONERROR_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__DEFAULTTAX:
        setDefaulttax(DEFAULTTAX_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__ADDRVALIDATIONPLACES:
        setAddrvalidationplaces(ADDRVALIDATIONPLACES_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__CUSTOMERVATID:
        setCustomervatid(CUSTOMERVATID_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__PRICECONTAINSTAXES:
        setPricecontainstaxes(PRICECONTAINSTAXES_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__OITAXESDISPLAYED:
        setOitaxesdisplayed(OITAXESDISPLAYED_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__LOGREQUESTTYPES:
        setLogrequesttypes(LOGREQUESTTYPES_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__AUTHKEY:
        setAuthkey(AUTHKEY_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__TAXCODEIDENTIFIER:
        setTaxcodeidentifier(TAXCODEIDENTIFIER_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__DAPCOUNTRIES:
        setDapcountries(DAPCOUNTRIES_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__DDPCOUNTRIES:
        setDdpcountries(DDPCOUNTRIES_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__OPTCOUNTER:
        setOptcounter(OPTCOUNTER_EDEFAULT);
        return;
      case ACEntityPackage.XAVATAX_CONF__STOREENT_FOR_XAVATAX_CONF:
        setStoreentForX_avatax_conf((ACStoreent)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ACEntityPackage.XAVATAX_CONF__STOREENT_ID:
        return storeent_id != STOREENT_ID_EDEFAULT;
      case ACEntityPackage.XAVATAX_CONF__URLTOCONNECT:
        return URLTOCONNECT_EDEFAULT == null ? urltoconnect != null : !URLTOCONNECT_EDEFAULT.equals(urltoconnect);
      case ACEntityPackage.XAVATAX_CONF__ACCNUM:
        return ACCNUM_EDEFAULT == null ? accnum != null : !ACCNUM_EDEFAULT.equals(accnum);
      case ACEntityPackage.XAVATAX_CONF__COMPANYCODE:
        return COMPANYCODE_EDEFAULT == null ? companycode != null : !COMPANYCODE_EDEFAULT.equals(companycode);
      case ACEntityPackage.XAVATAX_CONF__TAXCALCULATIONMODE:
        return TAXCALCULATIONMODE_EDEFAULT == null ? taxcalculationmode != null : !TAXCALCULATIONMODE_EDEFAULT.equals(taxcalculationmode);
      case ACEntityPackage.XAVATAX_CONF__TRANSACTIONLOGGING:
        return transactionlogging != TRANSACTIONLOGGING_EDEFAULT;
      case ACEntityPackage.XAVATAX_CONF__TRANSLOGKEEPHOURS:
        return TRANSLOGKEEPHOURS_EDEFAULT == null ? translogkeephours != null : !TRANSLOGKEEPHOURS_EDEFAULT.equals(translogkeephours);
      case ACEntityPackage.XAVATAX_CONF__SUPPORTEDCOUNTRIES:
        return SUPPORTEDCOUNTRIES_EDEFAULT == null ? supportedcountries != null : !SUPPORTEDCOUNTRIES_EDEFAULT.equals(supportedcountries);
      case ACEntityPackage.XAVATAX_CONF__TAXCOUNTRIES:
        return TAXCOUNTRIES_EDEFAULT == null ? taxcountries != null : !TAXCOUNTRIES_EDEFAULT.equals(taxcountries);
      case ACEntityPackage.XAVATAX_CONF__ADDROUNTRIES:
        return ADDROUNTRIES_EDEFAULT == null ? addrountries != null : !ADDROUNTRIES_EDEFAULT.equals(addrountries);
      case ACEntityPackage.XAVATAX_CONF__BEHAVIORONERROR:
        return BEHAVIORONERROR_EDEFAULT == null ? behavioronerror != null : !BEHAVIORONERROR_EDEFAULT.equals(behavioronerror);
      case ACEntityPackage.XAVATAX_CONF__DEFAULTTAX:
        return DEFAULTTAX_EDEFAULT == null ? defaulttax != null : !DEFAULTTAX_EDEFAULT.equals(defaulttax);
      case ACEntityPackage.XAVATAX_CONF__ADDRVALIDATIONPLACES:
        return ADDRVALIDATIONPLACES_EDEFAULT == null ? addrvalidationplaces != null : !ADDRVALIDATIONPLACES_EDEFAULT.equals(addrvalidationplaces);
      case ACEntityPackage.XAVATAX_CONF__CUSTOMERVATID:
        return customervatid != CUSTOMERVATID_EDEFAULT;
      case ACEntityPackage.XAVATAX_CONF__PRICECONTAINSTAXES:
        return pricecontainstaxes != PRICECONTAINSTAXES_EDEFAULT;
      case ACEntityPackage.XAVATAX_CONF__OITAXESDISPLAYED:
        return oitaxesdisplayed != OITAXESDISPLAYED_EDEFAULT;
      case ACEntityPackage.XAVATAX_CONF__LOGREQUESTTYPES:
        return LOGREQUESTTYPES_EDEFAULT == null ? logrequesttypes != null : !LOGREQUESTTYPES_EDEFAULT.equals(logrequesttypes);
      case ACEntityPackage.XAVATAX_CONF__AUTHKEY:
        return AUTHKEY_EDEFAULT == null ? authkey != null : !AUTHKEY_EDEFAULT.equals(authkey);
      case ACEntityPackage.XAVATAX_CONF__TAXCODEIDENTIFIER:
        return TAXCODEIDENTIFIER_EDEFAULT == null ? taxcodeidentifier != null : !TAXCODEIDENTIFIER_EDEFAULT.equals(taxcodeidentifier);
      case ACEntityPackage.XAVATAX_CONF__DAPCOUNTRIES:
        return DAPCOUNTRIES_EDEFAULT == null ? dapcountries != null : !DAPCOUNTRIES_EDEFAULT.equals(dapcountries);
      case ACEntityPackage.XAVATAX_CONF__DDPCOUNTRIES:
        return DDPCOUNTRIES_EDEFAULT == null ? ddpcountries != null : !DDPCOUNTRIES_EDEFAULT.equals(ddpcountries);
      case ACEntityPackage.XAVATAX_CONF__OPTCOUNTER:
        return optcounter != OPTCOUNTER_EDEFAULT;
      case ACEntityPackage.XAVATAX_CONF__STOREENT_FOR_XAVATAX_CONF:
        return storeentForX_avatax_conf != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (storeent_id: ");
    result.append(storeent_id);
    result.append(", urltoconnect: ");
    result.append(urltoconnect);
    result.append(", accnum: ");
    result.append(accnum);
    result.append(", companycode: ");
    result.append(companycode);
    result.append(", taxcalculationmode: ");
    result.append(taxcalculationmode);
    result.append(", transactionlogging: ");
    result.append(transactionlogging);
    result.append(", translogkeephours: ");
    result.append(translogkeephours);
    result.append(", supportedcountries: ");
    result.append(supportedcountries);
    result.append(", taxcountries: ");
    result.append(taxcountries);
    result.append(", addrountries: ");
    result.append(addrountries);
    result.append(", behavioronerror: ");
    result.append(behavioronerror);
    result.append(", defaulttax: ");
    result.append(defaulttax);
    result.append(", addrvalidationplaces: ");
    result.append(addrvalidationplaces);
    result.append(", customervatid: ");
    result.append(customervatid);
    result.append(", pricecontainstaxes: ");
    result.append(pricecontainstaxes);
    result.append(", oitaxesdisplayed: ");
    result.append(oitaxesdisplayed);
    result.append(", logrequesttypes: ");
    result.append(logrequesttypes);
    result.append(", authkey: ");
    result.append(authkey);
    result.append(", taxcodeidentifier: ");
    result.append(taxcodeidentifier);
    result.append(", dapcountries: ");
    result.append(dapcountries);
    result.append(", ddpcountries: ");
    result.append(ddpcountries);
    result.append(", optcounter: ");
    result.append(optcounter);
    result.append(')');
    return result.toString();
  }

} //X_avatax_confImpl
