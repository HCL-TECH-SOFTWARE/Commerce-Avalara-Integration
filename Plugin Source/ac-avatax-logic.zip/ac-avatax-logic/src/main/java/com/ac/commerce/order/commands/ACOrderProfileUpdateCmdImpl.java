package com.ac.commerce.order.commands;

import com.ac.avalara.order.bean.ACAvalaraUsersDataBean;
import com.ac.avalara.settings.ACAvalaraConstants;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.order.commands.OrderProfileUpdateCmd;
import com.ibm.commerce.order.commands.OrderProfileUpdateCmdImpl;

public class ACOrderProfileUpdateCmdImpl extends OrderProfileUpdateCmdImpl implements OrderProfileUpdateCmd {


	private static final ACLogger LOGGER = new ACLogger(ACOrderProfileUpdateCmdImpl.class);

	@Override
	public void performExecute() throws ECException {
		super.performExecute();
		// we are taking VAT from shipping address only.
		String shippingVatID = null;
		try {
			if (requestProperties.containsKey("DataArea/Person/CheckoutProfile/UserData/UserDataField@name")) {
				String[] keys = requestProperties.getArray("DataArea/Person/CheckoutProfile/UserData/UserDataField@name");
				String[] values = requestProperties.getArray("DataArea/Person/CheckoutProfile/UserData/UserDataField", new String[keys.length]);
				if (keys != null) {
					for (int i = 0; i < keys.length; i++) {
						String key = keys[i];
						if (("shipping" + ACAvalaraConstants.CUSTOMER_VAT_ID).equals(key)) {
							shippingVatID = values[i];
						}
					}
				}

				saveCustomerVatId(getShippingAddress(), shippingVatID);

			}
		} catch (Exception e) {
			LOGGER.error("performExecute", "Exception occured while saving customer VAT ID for QCP:" + e.getMessage());
		}
	}

	private void saveCustomerVatId(Long addressId, String customerVatId) {
		String METHOD_NAME = "saveCustomerVatId(Map parameters, Map res)";
		ACAvalaraUsersDataBean bean = new ACAvalaraUsersDataBean();
		bean.setAddressId(addressId.toString());
		bean.setCustomerVatId(customerVatId);
		try {
			bean.update();
		} catch (Exception e) {
			LOGGER.error(METHOD_NAME, "Exception occured while saving customer Vat ID for QCP " + e.getMessage());
		}
	}
}
