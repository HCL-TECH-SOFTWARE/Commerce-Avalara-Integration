package com.ac.commerce.order.commands;

import com.ibm.commerce.command.TaskCommand;

public interface ACAvalaraCancelTaxTaskCmd extends TaskCommand {
    String NAME = ACAvalaraCancelTaxTaskCmd.class.getName();
    String defaultCommandClassName = ACAvalaraCancelTaxTaskCmdImpl.class.getName();

    void setOrderId(Long orderId);
}
