/**
 */
package com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl;

import com.ac.commerce.infrastructure.facade.server.entity.datatypes.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ACEntityFactoryImpl extends EFactoryImpl implements ACEntityFactory
{
  /**
   * Creates the default factory implementation.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static ACEntityFactory init()
  {
    try
    {
      ACEntityFactory theACEntityFactory = (ACEntityFactory)EPackage.Registry.INSTANCE.getEFactory(ACEntityPackage.eNS_URI);
      if (theACEntityFactory != null)
      {
        return theACEntityFactory;
      }
    }
    catch (Exception exception)
    {
      EcorePlugin.INSTANCE.log(exception);
    }
    return new ACEntityFactoryImpl();
  }

  /**
   * Creates an instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ACEntityFactoryImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EObject create(EClass eClass)
  {
    switch (eClass.getClassifierID())
    {
      case ACEntityPackage.AC_ROOT: return (EObject)createACRoot();
      case ACEntityPackage.XAVATAX_CONF: return (EObject)createX_avatax_conf();
      case ACEntityPackage.AC_STOREENT: return (EObject)createACStoreent();
      default:
        throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ACRoot createACRoot()
  {
    ACRootImpl acRoot = new ACRootImpl();
    return acRoot;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public X_avatax_conf createX_avatax_conf()
  {
    X_avatax_confImpl x_avatax_conf = new X_avatax_confImpl();
    return x_avatax_conf;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ACStoreent createACStoreent()
  {
    ACStoreentImpl acStoreent = new ACStoreentImpl();
    return acStoreent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ACEntityPackage getACEntityPackage()
  {
    return (ACEntityPackage)getEPackage();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @deprecated
   * @generated
   */
  public static ACEntityPackage getPackage()
  {
    return ACEntityPackage.eINSTANCE;
  }

} //ACEntityFactoryImpl
