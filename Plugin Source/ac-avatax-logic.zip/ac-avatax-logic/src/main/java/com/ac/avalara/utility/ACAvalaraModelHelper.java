package com.ac.avalara.utility;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import net.avalara.avatax.rest.client.enums.DocumentType;
import net.avalara.avatax.rest.client.enums.TaxOverrideType;
import net.avalara.avatax.rest.client.models.AddressLocationInfo;
import net.avalara.avatax.rest.client.models.AddressesModel;
import net.avalara.avatax.rest.client.models.AvaTaxMessage;
import net.avalara.avatax.rest.client.models.CreateTransactionModel;
import net.avalara.avatax.rest.client.models.LineItemModel;
import net.avalara.avatax.rest.client.models.TaxOverrideModel;
import net.avalara.avatax.rest.client.models.TransactionModel;

import org.apache.commons.lang3.StringUtils;

import com.ac.avalara.order.bean.ACAvalaraShipModeDetails;
import com.ac.avalara.order.bean.ACAvalaraShipModeDetailsDataBean;
import com.ac.avalara.order.bean.ACAvalaraTaxDetails;
import com.ac.avalara.order.bean.ACAvalaraTaxDetailsDataBean;
import com.ac.avalara.order.bean.ACAvalaraTaxDetailsType;
import com.ac.avalara.order.bean.ACAvalaraUsersDataBean;
import com.ac.avalara.settings.ACAvalaraConstants;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ac.avatax.exception.AvalaraException;
import com.ac.avatax.rest.logger.AvalaraLogger;
import com.ac.commerce.objects.helpers.AddressAccessBeans;
import com.ac.commerce.objects.helpers.CatalogEntryDescriptionAccessBeans;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.catalog.objects.CatalogEntryDescriptionAccessBean;
import com.ibm.commerce.command.CommandContext;
import com.ibm.commerce.common.beans.StoreDataBean;
import com.ibm.commerce.common.objects.StoreAddressAccessBean;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECSystemException;
import com.ibm.commerce.fulfillment.objects.CalculationCodeAccessBean;
import com.ibm.commerce.fulfillment.objects.FulfillmentCenterDescriptionAccessBean;
import com.ibm.commerce.order.beans.OrderItemDataBean;
import com.ibm.commerce.order.calculation.Item;
import com.ibm.commerce.order.objects.OrderAdjustmentAccessBean;
import com.ibm.commerce.order.objects.OrderItemAccessBean;
import com.ibm.commerce.ordermanagement.objects.RMAItemAccessBean;
import com.ibm.commerce.ras.ECMessage;
import com.ibm.commerce.ras.ECMessageHelper;
import com.ibm.commerce.user.objects.AddressAccessBean;

public class ACAvalaraModelHelper {

	private static final String CLASSNAME = ACAvalaraModelHelper.class.getName();
	private static final AvalaraLogger AVA_LOGGER = new AvalaraLogger();
	private static final ACLogger LOGGER = new ACLogger(ACAvalaraModelHelper.class);

	public static CreateTransactionModel getCreateTransactionModel(DocumentType documentType, String orderId, String currency, String companyId, String customerCode, AddressLocationInfo shipFromAddress,
			AddressLocationInfo shipToAddressLandedCost, List<LineItemModel> lines, String customerUsageType, String dapCountries, String ddpCountries, LandedCostType landedCostType, ACAvalaraShipModeDetails shipModeDetails)
			throws Exception {

		String methodName = "getCreateTransactionModel";
		LOGGER.entering(methodName);

		CreateTransactionModel retval = new CreateTransactionModel();

		AddressesModel addressModel = new AddressesModel();
		addressModel.setShipFrom(shipFromAddress);

		if (!LandedCostType.NONE.equals(landedCostType) && null != shipToAddressLandedCost) {
			// for LandedCost only single shipTo address allowed
			addressModel.setShipTo(shipToAddressLandedCost);

			HashMap<String, String> params = new HashMap<String, String>();
			if (null != shipModeDetails) {
				params.put("AvaTax.LandedCost.ShippingMode", String.valueOf(shipModeDetails.getMode()));
				params.put("AvaTax.LandedCost.Express", String.valueOf(shipModeDetails.isExpress()).toLowerCase());
			} else {
				LOGGER.warn(methodName, "There is no additional shipping mode details for orderId {0}", new Object[] { orderId });
			}

			if (LandedCostType.DAP.equals(landedCostType)) {
				params.put("AvaTax.LandedCost.Incoterms", LandedCostType.DAP.name());
			} else if (LandedCostType.DDP.equals(landedCostType)) {
				params.put("AvaTax.LandedCost.Incoterms", LandedCostType.DDP.name());
				landedCostType = LandedCostType.DDP;
				retval.setIsSellerImporterOfRecord(true);
			}

			retval.setParameters(params);

		}
		//Adding shipFrom and shipTo address t0 lines
		//retval.setAddresses(addressModel);
		retval.setCode(orderId);
		retval.setCompanyCode(companyId);
		retval.setCurrencyCode(currency);
		retval.setCustomerCode(customerCode);
		retval.setCustomerUsageType(customerUsageType);

		retval.setDate(new Date());

		ArrayList<LineItemModel> linesArrayList = new ArrayList<LineItemModel>();
		linesArrayList.addAll(lines);
		retval.setLines(linesArrayList);
		retval.setPurchaseOrderNo(orderId);
		retval.setType(documentType);

		LOGGER.exiting(methodName);
		return retval;
	}

	/**
	 * getLineItemInfo method get the item level details includes orderitem and
	 * shipping charge details.
	 * 
	 * @param orderItemBeans
	 * @param langId
	 * @throws ECApplicationException
	 * 
	 * @return List<AvalaraCalculationLine>
	 */
	@SuppressWarnings("null")
	public static List<LineItemModel> getLineItemInfo(OrderItemAccessBean[] orderItemBeans, ACAvalaraSettings settings, CommandContext cmdContext, boolean isReturn) throws ECApplicationException {
		String methodName = "getLineItemInfo";
		LOGGER.entering(methodName);

		List<LineItemModel> retval = new LinkedList<LineItemModel>();
		try {
			for (OrderItemAccessBean orderItemBean : orderItemBeans) {
				OrderItemDataBean orderItemDataBean = new OrderItemDataBean();
				orderItemDataBean.setInitKey_orderItemId(orderItemBean.getOrderItemId());
//				orderItemDataBean.instantiateEntity();
				// Adding order items to invoice line array

				//Adding Shipping Address to line
				
				AddressLocationInfo fromAddress = getShipFromAddress(orderItemBean.getFulfillmentCenterId(), orderItemBean.getStoreId(), cmdContext);
				
				AddressLocationInfo toAddress = getTaxAddressInfo(orderItemBean.getAddressId(), orderItemBean.getOrderItemId(), cmdContext);
				AddressesModel addressModel = null;
				if (toAddress.getCountry() != null ) {

					String toCountry = toAddress.getCountry();
					String dapCountries = settings.getDapCountries();
					String ddpCountries = settings.getDdpCountries();

					if ((null == dapCountries || !dapCountries.contains(toCountry)) && (null == ddpCountries || !ddpCountries.contains(toCountry))) {
						addressModel = new AddressesModel();
						addressModel.setShipTo(toAddress);
					}
				}
				
				if(null != fromAddress.getCountry()){
					addressModel.setShipFrom(fromAddress);
				}

				LineItemModel line = getOrderItemDetails(orderItemBean, orderItemDataBean, settings, cmdContext, isReturn);
				if (null != addressModel) {
					line.setAddresses(addressModel);
				}
				retval.add(line);

				if (getAdjustedShippingChargeForOrderItem(orderItemDataBean).compareTo(BigDecimal.ZERO) > 0) {
					// Adding Freight(shipping) charge to invoice line array
					ACAvalaraShipModeDetailsDataBean shipModeDetailsBean = new ACAvalaraShipModeDetailsDataBean();
					shipModeDetailsBean.setCommandContext(cmdContext);
					shipModeDetailsBean.setShipModeId(orderItemBeans[0].getShippingModeIdInEntityType());
					shipModeDetailsBean.populate();
					ACAvalaraShipModeDetails details = shipModeDetailsBean.getDetails();

					line = getShippingChargeItemDetails(orderItemDataBean, settings, details);
					if (null != addressModel) {
						line.setAddresses(addressModel);
					}
					retval.add(line);
				}
			}
		} catch (Exception ecexception) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(ecexception));
			throw new ECApplicationException(ECMessage._ERR_GENERIC, CLASSNAME, methodName, new Object[] { ecexception.getMessage() });
		}

		LOGGER.exiting(methodName);
		return retval;
	}
	
	private static BigDecimal getAdjustedShippingChargeForOrderItem(OrderItemAccessBean orderItemDataBean) throws RemoteException, CreateException, FinderException, NamingException, SQLException  {
		if(null == orderItemDataBean) {
			return BigDecimal.ZERO;
		}
		return orderItemDataBean.getShippingChargeInEntityType().add(orderItemDataBean.getTotalAdjustmentByCalculationUsageId(-7));
	}

	public static LineItemModel getOrderItemDetails(OrderItemAccessBean item, OrderItemDataBean orderItemDataBean, ACAvalaraSettings setting, CommandContext cmdContext, boolean isReturn) throws ECApplicationException, ECSystemException {
		String methodName = "getOrderItemDetails";
		LOGGER.entering(CLASSNAME, methodName);

		// add all the orderitems as lineItems
		LineItemModel retval = new LineItemModel();
		try {
			CatalogEntryDescriptionAccessBean catalogEntryDescriptionBean = CatalogEntryDescriptionAccessBeans.bean(item.getCatalogEntryId(), cmdContext.getLanguageId().toString());

			// retval.setLineCode(item.getOrderItemId());
			retval.setItemCode(item.getCatalogEntryId());
			BigDecimal quantity = new BigDecimal(item.getQuantity());
			BigDecimal price = new BigDecimal(item.getPrice());
			BigDecimal priceTotal = price.multiply(quantity).add(orderItemDataBean.getDiscountAdjustmentTotal());

			retval.setNumber(item.getOrderItemId());
			retval.setQuantity(quantity);
			retval.setDescription(catalogEntryDescriptionBean.getShortDescription());

			retval.setAmount(isReturn ? priceTotal.negate() : priceTotal);
			retval.setTaxIncluded(setting.getTaxIncluded());

			AddressLocationInfo toAddress = getTaxAddressInfo(item.getAddressId(), item.getOrderItemId(), cmdContext);

			if (toAddress.getCountry() != null) {

				String toCountry = toAddress.getCountry();
				String dapCountries = setting.getDapCountries();
				String ddpCountries = setting.getDdpCountries();

				if (StringUtils.isNotEmpty(setting.getTaxCodeIdentifier())) {
					retval.setTaxCode(ACAvalaraUtils.getAttributeValue(item.getCatalogEntryId(), setting.getTaxCodeIdentifier()));
				}

				try {
					ACAvalaraUsersDataBean usersDataBean = new ACAvalaraUsersDataBean();
					usersDataBean.setAddressId(item.getAddressId());
					usersDataBean.setCommandContext(cmdContext);
					usersDataBean.populate();

					LOGGER.fine(methodName, "segment tax code for a group " + usersDataBean.getCustomerVatId() + " equals to:" + usersDataBean.getCustomerVatId());
					if (usersDataBean.getCustomerVatId() != null && !usersDataBean.getCustomerVatId().isEmpty()) {
						retval.setBusinessIdentificationNo(usersDataBean.getCustomerVatId());
					}

					if ((null != dapCountries && dapCountries.contains(toCountry)) || (null != ddpCountries && ddpCountries.contains(toCountry))) {
						HashMap<String, String> params = new HashMap<String, String>();

						String unitAmount = ACAvalaraUtils.getAttributeValue(item.getCatalogEntryId(), setting.getUnitAmountIdentifier() + toCountry);
						if (StringUtils.isNotEmpty(unitAmount)) {
							params.put("AvaTax.LandedCost.UnitAmount", unitAmount);
						} else {
							LOGGER.info(methodName, "Not able to find UnitAmount for OrderItemId: ? ", new Object[] { item.getOrderItemId() });
						}

						String unitName = ACAvalaraUtils.getAttributeValue(item.getCatalogEntryId(), setting.getUnitNameIdentifier() + toCountry);
						if (StringUtils.isNotEmpty(unitName)) {
							params.put("AvaTax.LandedCost.UnitName", unitName);
						} else {
							LOGGER.info(methodName, "Not able to find UnitName for OrderItemId: ? ", new Object[] { item.getOrderItemId() });
						}

						String htsCode = ACAvalaraUtils.getAttributeValue(item.getCatalogEntryId(), setting.getHtsCodeIdentifier() + toCountry);
						if (StringUtils.isNotEmpty(htsCode)) {
							params.put("AvaTax.LandedCost.HTSCode", htsCode);
						} else {
							LOGGER.info(methodName, "Not able to find HTS code for OrderItemId: ? ", new Object[] { item.getOrderItemId() });
						}
						retval.setParameters(params);

					}

				} catch (Exception e) {
					LOGGER.error(methodName, "Error occured while getting customer vat ID for that address");

				}

			}
		} catch (CreateException ex) {
			throw new ECApplicationException(ECMessage._ERR_CREATE_EXCEPTION, CLASSNAME, methodName, new Object[] { ex.getMessage() });
		} catch (NamingException ex) {
			throw new ECApplicationException(ECMessage._ERR_NAMING_EXCEPTION, CLASSNAME, methodName, new Object[] { ex.getMessage() });
		} catch (RemoteException ex) {
			throw new ECApplicationException(ECMessage._ERR_REMOTE_EXCEPTION, CLASSNAME, methodName, new Object[] { ex.getMessage() });
		} catch (FinderException ex) {
			throw new ECApplicationException(ECMessage._ERR_FINDER_EXCEPTION, CLASSNAME, methodName, new Object[] { ex.getMessage() });
		}

		LOGGER.exiting(methodName);
		return retval;
	}

	public static TaxOverrideModel getReturnTaxOverrideDocLevel(Long orderId, CommandContext commandContext, Date taxDate) throws Exception {
		TaxOverrideModel retval = null;
		ACAvalaraTaxDetailsDataBean detailsDataBean = new ACAvalaraTaxDetailsDataBean();
		detailsDataBean.setOrderId(orderId);
		detailsDataBean.setAllItemsDetails(true);
		detailsDataBean.setCommandContext(commandContext);
		detailsDataBean.populate();

		boolean taxOverrideByLine = false;
		for (ACAvalaraTaxDetails detail : detailsDataBean.getDetails()) {
			// not able to use tax override on both document and line level so
			// we need to check if there was default tax calculated.
			if ("FAIL-DEFAULT".equals(detail.getTaxtype())) {
				taxOverrideByLine = true;
				break;
			}
		}
		if (!taxOverrideByLine) {
			retval = new TaxOverrideModel();
			retval.setType(TaxOverrideType.TaxDate);
			retval.setTaxDate(taxDate);
			retval.setReason("Return to customer");
		}
		return retval;
	}

	public static CreateTransactionModel getReturnModel(DocumentType documentType, List<LineItemModel> lines, String customerUsageType, AddressesModel addressModel, String transactionCode, String companyCode,
			TaxOverrideModel taxOverrideModel, String currency, String customerCode, ArrayList<LineItemModel> linesArrayList, String referenceCode) {

		String methodName = "getReturnModel";
		LOGGER.entering(methodName);
		CreateTransactionModel retval = new CreateTransactionModel();

		retval.setAddresses(addressModel);
		retval.setCode(transactionCode);
		retval.setDate(new Date());
		retval.setCompanyCode(companyCode);
		if (null != taxOverrideModel) {
			retval.setTaxOverride(taxOverrideModel);
		}

		retval.setCurrencyCode(currency);
		retval.setCustomerCode(customerCode);
		retval.setCustomerUsageType(customerUsageType);

		retval.setLines(linesArrayList);
		// Reference Code used to reference the original document for a return invoice
		retval.setReferenceCode(referenceCode);

		retval.setType(documentType);


		LOGGER.exiting(methodName);
		return retval;

	}
	
	public static LineItemModel getLineItemInfoForInsurance(Long orderId) throws ECApplicationException {
		
		LineItemModel retval = null;
		OrderAdjustmentAccessBean orderAdjustmentBean = new OrderAdjustmentAccessBean();
		try {
			Enumeration adjustments = orderAdjustmentBean.findByOrderAndUsage(orderId, -6);
			while (adjustments.hasMoreElements()) {
				orderAdjustmentBean = (OrderAdjustmentAccessBean) adjustments.nextElement();
				CalculationCodeAccessBean codeBean = new CalculationCodeAccessBean();
				codeBean.setInitKey_calculationCodeId(orderAdjustmentBean.getCalculationCodeId());
//				codeBean.instantiateEntity();
				if ("AvalaraInsurance".equals(codeBean.getCode())) {
					retval = new LineItemModel();
					retval.setNumber("INS-" + orderId);
					retval.setDescription("Insurance");
					retval.setTaxCode("FR070100");
					retval.setAmount(orderAdjustmentBean.getAmountInEntityType());
					retval.setQuantity(new BigDecimal(1));
				}
			}
		} catch (Exception e) {
			throw new ECApplicationException(e);
		}
		return retval;
	}	
	

	public static List<LineItemModel> getLineItemInfoForGetTax(Item[] items, ACAvalaraSettings settings, CommandContext cmdContext) throws ECApplicationException {
		OrderItemAccessBean[] orderItemBeans = ACAvalaraUtils.getOrderItemBeans(items);
		return getLineItemInfoForGetTax (orderItemBeans, settings, cmdContext);
	}	
	
	public static List<LineItemModel> getLineItemInfoForGetTax(OrderItemAccessBean[] orderItemBeans, ACAvalaraSettings settings, CommandContext cmdContext) throws ECApplicationException {
		return getLineItemInfo(orderItemBeans, settings, cmdContext, false);
	}

	public static List<LineItemModel> getLineItemInfoForReturnTax(Vector<RMAItemAccessBean> rmaItems, ACAvalaraSettings settings, CommandContext cmdContext) throws ECApplicationException {
		return getLineItemInfoForReturn(rmaItems, settings, cmdContext, true);
	}

	public static List<LineItemModel> getLineItemInfoForReturn(Vector<RMAItemAccessBean> rmaItems, ACAvalaraSettings settings, CommandContext cmdContext, boolean isReturn) throws ECApplicationException {
		String methodName = "getLineItemInfo";
		LOGGER.entering(methodName);

		List<LineItemModel> lines = new LinkedList<LineItemModel>();
		try {
			for (RMAItemAccessBean rmaItem : rmaItems) {
				if (null == rmaItem.getOrderItemsId()) {
					LOGGER.trace(methodName, "Skipping rmaItem because it is not related to orderItem");
					continue;
				}

				OrderItemDataBean orderItemDataBean = new OrderItemDataBean();
				orderItemDataBean.setInitKey_orderItemId(rmaItem.getOrderItemsId());
//				orderItemDataBean.instantiateEntity();

				AddressLocationInfo toAddress = getTaxAddressInfo(orderItemDataBean.getAddressId(), rmaItem.getOrderItemsId(), cmdContext);
				AddressesModel addressModel = null;
				if (toAddress.getCountry() != null) {

					String toCountry = toAddress.getCountry();
					String dapCountries = settings.getDapCountries();
					String ddpCountries = settings.getDdpCountries();

					if ((null == dapCountries || !dapCountries.contains(toCountry)) && (null == ddpCountries || !ddpCountries.contains(toCountry))) {
						addressModel = new AddressesModel();
						addressModel.setShipTo(toAddress);
					}
				}

				// Adding order items to invoice line array
				LineItemModel line = getOrderItemDetails(orderItemDataBean, orderItemDataBean, settings, cmdContext, true);
				BigDecimal quantity = BigDecimal.valueOf(rmaItem.getQuantityInEntityType());
				line.setQuantity(quantity);
				BigDecimal lineAmount = rmaItem.getCreditAmountInEntityType().add(rmaItem.getAdjustmentCreditInEntityType()).add(rmaItem.getAdjustmentInEntityType()).negate();
				line.setAmount(lineAmount);
				line.setAddresses(addressModel);
				line.setTaxIncluded(settings.getTaxIncluded());

				ACAvalaraTaxDetailsDataBean detailsDataBean = new ACAvalaraTaxDetailsDataBean();
				detailsDataBean.setOrderId(orderItemDataBean.getOrderIdInEntityType());
				detailsDataBean.setOrderItemId(orderItemDataBean.getOrderItemIdInEntityType());
				detailsDataBean.setCommandContext(cmdContext);
				detailsDataBean.populate();
				for (ACAvalaraTaxDetails detail : detailsDataBean.getDetails()) {
					if ("FAIL-DEFAULT".equals(detail.getTaxtype()) && detail.getType().equals(ACAvalaraTaxDetailsType.LN)) {
						TaxOverrideModel taxOverride = new TaxOverrideModel();
						taxOverride.setTaxAmount(new BigDecimal(detail.getTax()).negate());
						taxOverride.setType(TaxOverrideType.TaxAmount);
						taxOverride.setReason("Service failure");
						line.setTaxOverride(taxOverride);
					}
				}

				lines.add(line);

			}
		} catch (Exception ecexception) {
			throw new ECApplicationException(ECMessage._ERR_GENERIC, CLASSNAME, methodName, new Object[] { ecexception.getMessage() });
		}

		LOGGER.exiting(methodName);
		return lines;
	}

	public static LineItemModel getShippingChargeItemDetails(OrderItemAccessBean item, ACAvalaraSettings settings, ACAvalaraShipModeDetails details) throws ECApplicationException {
		String methodName = "getShippingChargeItemDetails";
		LOGGER.entering(methodName);

		// Method add Shipping charge as line item to request. Method is called
		// if ShippingCharge for orderitem > 0.
		LineItemModel retval = new LineItemModel();
		try {
			/*
			 * Setting lineCode as "FreightItem"+orderitemId(for eg
			 * FreightItem1000). This is done since LineNo should be unique in
			 * Avalara System and is a required parameter.
			 */
			retval.setNumber("FR" + item.getOrderItemId());
			retval.setItemCode("FR" + item.getOrderItemId());
			retval.setQuantity(BigDecimal.ONE);
			retval.setAmount(getAdjustedShippingChargeForOrderItem(item));
			retval.setDescription("FREIGHT CHARGE");
			// TODO avatax will it be ok to have default FR for shipping HTS
			// code?
			retval.setTaxCode(null != details ? String.valueOf(details.getHtsCode()) : "FR");
			retval.setTaxIncluded(settings.getTaxIncluded());

		} catch (CreateException ex) {
			throw new ECApplicationException(ECMessage._ERR_CREATE_EXCEPTION, CLASSNAME, methodName, new Object[] { ex.getMessage() });
		} catch (NamingException ex) {
			throw new ECApplicationException(ECMessage._ERR_NAMING_EXCEPTION, CLASSNAME, methodName, new Object[] { ex.getMessage() });
		} catch (RemoteException ex) {
			throw new ECApplicationException(ECMessage._ERR_REMOTE_EXCEPTION, CLASSNAME, methodName, new Object[] { ex.getMessage() });
		} catch (FinderException ex) {
			throw new ECApplicationException(ECMessage._ERR_FINDER_EXCEPTION, CLASSNAME, methodName, new Object[] { ex.getMessage() });
		} catch (SQLException ex) {
			throw new ECApplicationException(ECMessage._ERR_SQL_EXCEPTION, CLASSNAME, methodName, new Object[] { ex.getMessage() });
		}

		LOGGER.exiting(methodName);
		return retval;
	}

	/**
	 * This method will return address info in case when there is only one item
	 * in order or all items has the same address, because LandedCost AP
	 * functionality doesn't support multiple shipment
	 * 
	 * */
	
	public static AddressLocationInfo getShipToAddressForLandedCost(Item[] items, String dapCountries, String ddpCountries, CommandContext commandContext) throws AvalaraException {
		OrderItemAccessBean[] orderItemBeans = ACAvalaraUtils.getOrderItemBeans(items);
		return getShipToAddressForLandedCost(orderItemBeans, dapCountries, ddpCountries, commandContext);
	}
	
	public static AddressLocationInfo getShipToAddressForLandedCost(OrderItemAccessBean[] orderItemBeans, String dapCountries, String ddpCountries, CommandContext commandContext) throws AvalaraException {
		String methodName = "getShipToAddressForLandedCost";
		LOGGER.entering(methodName);
		AddressLocationInfo retval = null;
		AddressAccessBean toAddress = null;

		try {
			if (orderItemBeans.length > 1) {
				List<AddressAccessBean> addresses = new ArrayList<AddressAccessBean>();
				Set<String> addressIds = new HashSet<String>();

				for (OrderItemAccessBean orderItem : orderItemBeans) {
					if (!addressIds.contains(orderItem.getAddressId())) {
						addressIds.add(orderItem.getAddressId());
						AddressAccessBean address = new AddressAccessBean();
						address.setInitKey_addressId(orderItem.getAddressId());
//						address.instantiateEntity();
						addresses.add(address);
					}
				}

				if (1 == addressIds.size()) {
					toAddress = addresses.get(0);
				} else {
					throw new AvalaraException("_ERR_LANDED_COST_MULTIPLE_DESTINATION");
				}

			} else {
				toAddress = new AddressAccessBean();
				toAddress.setInitKey_addressId(orderItemBeans[0].getAddressId());
//				toAddress.instantiateEntity();
			}

			if (null != toAddress) {
				retval = new AddressLocationInfo();
				retval.setLine1(toAddress.getAddress1());
				if (null != toAddress.getAddress2()) {
					retval.setLine2(toAddress.getAddress2());
				}
				retval.setCity(toAddress.getCity());
				String regionCode = ACAvalaraUtils.getRegionCode(toAddress.getState());
				retval.setRegion(regionCode);
				String countryCode = ACAvalaraUtils.getCountryCode(toAddress.getCountry());
				retval.setCountry(countryCode);
				retval.setPostalCode(toAddress.getZipCode());
			}

		} catch (AvalaraException e) {
			LOGGER.error(methodName, e.getMessage(), e);
			throw e;
		} catch (Exception e) {
			LOGGER.error(methodName, e.getMessage(), e);
			throw new AvalaraException("Unable to get destination address");
		}

		LOGGER.exiting(methodName);
		return retval;
	}

	public static AddressLocationInfo getDefaultAddressFromPropertiesBundle() {
		final String methodName = "getPropertyBundleAddress";
		AddressLocationInfo retval = new AddressLocationInfo();
		LOGGER.entering(methodName);
		if (StringUtils.isNotEmpty(ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.DEFAULT_ADDRESS_LINE1))) {
			retval.setLine1(ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.DEFAULT_ADDRESS_LINE1));
			retval.setLine2(ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.DEFAULT_ADDRESS_LINE2));
			retval.setCity(ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.DEFAULT_ADDRESS_CITY));
			retval.setRegion(ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.DEFAULT_ADDRESS_STATE));
			retval.setCountry(ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.DEFAULT_ADDRESS_COUNTRY));
			retval.setPostalCode(ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.DEFAULT_ADDRESS_ZIP_CODE));
		}

		LOGGER.exiting(methodName, retval);
		return retval;
	}

	/**
	 * getShipFromAddress method get the ship from address. It checks for flag
	 * in avatax.properties. If flag =1, then look to STADDRESS table for
	 * FFMCENTER address,If Flag=0, then take default address from config file.
	 * 
	 * @param OrderItemAccessBean
	 * @param storeId
	 * @param commandContext
	 * 
	 * @return BaseAddress
	 */
	
	public static AddressLocationInfo getShipFromAddress(Integer ffmId, Integer storeId, CommandContext commandContext) {
		return getShipFromAddress(String.valueOf(ffmId), String.valueOf(storeId), commandContext);
	}	
	
	public static AddressLocationInfo getShipFromAddress(String ffmId, String storeId, CommandContext commandContext) {
		final String methodName = "getShipFromAddress";
		LOGGER.entering(methodName, new Object[] { ffmId, storeId, commandContext });
		AddressLocationInfo retval = new AddressLocationInfo();

		String flag = ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.MULTIPLE_FULFILLMENT_CENTER);

		// If flag =1, then look to STADDRESS table for FFMCENTER address,If
		// Flag=0, then take default address from config file.
		if (flag.equals("1")) {
			String ffmcId = ffmId;
			// If flag =1, then look to STADDRESS table for FFMCENTER address,If
			// Flag=0, then take default address from config file.
			try {
				if (StringUtils.isEmpty(ffmcId)) {
					StoreDataBean storedatabean = new StoreDataBean();
					storedatabean.setInitKey_storeEntityId(storeId);
//					storedatabean.instantiateEntity();
					ffmcId = storedatabean.getFulfillmentCenterId();
				}
				if (StringUtils.isNotEmpty(ffmcId)) {
					FulfillmentCenterDescriptionAccessBean ffmCenterDescAccessBean = new FulfillmentCenterDescriptionAccessBean();
					ffmCenterDescAccessBean.setInitKey_fulfillmentCenterId(ffmcId);
					ffmCenterDescAccessBean.setInitKey_languageId(commandContext.getLanguageId().toString());
//					ffmCenterDescAccessBean.instantiateEntity();
					String ffmAddressId = ffmCenterDescAccessBean.getStoreAddressId();
					if (StringUtils.isNotEmpty(ffmAddressId)) {
						StoreAddressAccessBean storeAddressBean = new StoreAddressAccessBean();
						storeAddressBean.setInitKey_storeAddressId(ffmAddressId);
//						storeAddressBean.instantiateEntity();
						retval.setLine1(storeAddressBean.getAddress1());
						if (storeAddressBean.getAddress2() != null) {
							retval.setLine2(storeAddressBean.getAddress2());
						}
						retval.setCity(storeAddressBean.getCity());
						String regionCode = storeAddressBean.getState();
						String countryCode = storeAddressBean.getCountry();
						try {
							regionCode = ACAvalaraUtils.getRegionCode(storeAddressBean.getState());
						} catch (Exception e) {
							LOGGER.error(methodName, "Unable to get region code");
						}


						try {
							countryCode = ACAvalaraUtils.getCountryCode(storeAddressBean.getCountry());
						} catch (Exception e) {
							LOGGER.error(methodName, "Unable to get country code");
						}
						
						retval.setRegion(regionCode);
						retval.setCountry(countryCode);
						retval.setPostalCode(storeAddressBean.getZipCode());
					}
				}
			} catch (ECSystemException e) {
				LOGGER.error(methodName, "ECSystemException in getShipFromAddress", e);
			}
			LOGGER.exiting(methodName, retval);
			return retval;
		} else {
			return getDefaultAddressFromPropertiesBundle();
		}
	}
	
	public static AddressLocationInfo getTaxAddressInfo(String addressId, String orderItemId, CommandContext commandContext) throws ECApplicationException {
		String methodName = "getTaxAddressInfo";
		LOGGER.entering(CLASSNAME, methodName);
		AddressLocationInfo retval = new AddressLocationInfo();
		try {
			if (StringUtils.isEmpty(addressId)) {
				throw new ECApplicationException(ECMessage._ERR_GENERIC, CLASSNAME, methodName, new Object[] { "There is no address in orderItem " + orderItemId });
			}

			LOGGER.trace(methodName, "fetching Ship from address for an orderId");
			LOGGER.trace(methodName, "Shipping AddressId forOrderItemId: {0}, the order {1}", orderItemId, addressId);

			AddressAccessBean addressBean = AddressAccessBeans.bean(addressId);
			retval.setLine1(addressBean.getAddress1());
			if (addressBean.getAddress2() != null) {
				retval.setLine2(addressBean.getAddress2());
			}
			retval.setCity(addressBean.getCity());
			String regionCode = ACAvalaraUtils.getRegionCode(addressBean.getState());
			retval.setRegion(regionCode);
			String countryCode = ACAvalaraUtils.getCountryCode(addressBean.getCountry());
			retval.setCountry(countryCode);
			retval.setPostalCode(addressBean.getZipCode());

		} catch (Exception ecexception) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(ecexception));
			throw new ECApplicationException(ECMessage._ERR_GENERIC, CLASSNAME, methodName, new Object[] { ecexception.getMessage() });
		}

		LOGGER.exiting(methodName);
		return retval;
	}
	
	
	public static boolean isErrorsInResponse(TransactionModel response) {
		if (null != response.getMessages()) {
			for (AvaTaxMessage message : response.getMessages()) {
				if ("Error".equals(message.getSeverity())) {
					return true;
				}
			}
		}
		return false;
	}	
	

}
