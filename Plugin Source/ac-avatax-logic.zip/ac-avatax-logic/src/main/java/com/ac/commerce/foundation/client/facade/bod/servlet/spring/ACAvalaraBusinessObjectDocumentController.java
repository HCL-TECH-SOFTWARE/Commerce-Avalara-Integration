package com.ac.commerce.foundation.client.facade.bod.servlet.spring;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import com.ibm.commerce.foundation.client.facade.bod.servlet.spring.BusinessObjectDocumentController;

public class ACAvalaraBusinessObjectDocumentController extends BusinessObjectDocumentController {

	protected Map buildRequestMap(HttpServletRequest request, HttpServletResponse response) {
		Map retval = null;
		retval = super.buildRequestMap(request, response);
		
		stackEntry(retval, "x_taxcountries");
		stackEntry(retval, "x_addrountries");
		stackEntry(retval, "x_dapcountries");
		stackEntry(retval, "x_ddpcountries");

		return retval;
	}

	private void stackEntry(Map map, String key) {

		String[] value = (String[]) map.get(key);
		if (null != value) {
			String stackedValue = StringUtils.join(value, ",");
			map.put(key, new String[] { stackedValue });
		}

	}

}
