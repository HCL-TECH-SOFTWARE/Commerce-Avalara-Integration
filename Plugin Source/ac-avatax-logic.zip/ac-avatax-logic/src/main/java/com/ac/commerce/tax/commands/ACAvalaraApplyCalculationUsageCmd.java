package com.ac.commerce.tax.commands;

import com.ibm.commerce.order.calculation.ApplyCalculationUsageCmd;

public interface ACAvalaraApplyCalculationUsageCmd extends ApplyCalculationUsageCmd {
    
    String defaultCommandClassName = ACAvalaraApplyCalculationUsageCmdImpl.class.getName();
}
