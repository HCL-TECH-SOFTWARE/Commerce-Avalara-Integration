package com.ac.commerce.order.commands;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ac.avalara.utility.ACAvalaraTaxUtils;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.command.TaskCommandImpl;
import com.ibm.commerce.exception.ECException;

@SuppressWarnings("serial")
public class ACAvalaraCancelTaxTaskCmdImpl extends TaskCommandImpl implements ACAvalaraCancelTaxTaskCmd {

    private static final ACLogger LOGGER = new ACLogger(ACAvalaraCancelTaxTaskCmdImpl.class);
    private Long orderId;

    @Override
    public void performExecute() throws ECException {
        String methodName = "performExecute";
        LOGGER.entering(methodName);

        super.performExecute();

		ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
		bean.setCommandContext(commandContext);
		try {
			bean.populate();
		} catch (Exception e) {
			LOGGER.error(methodName, "Error occured while loading avatax configuration:" + e.getMessage());
		}
		ACAvalaraSettings settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);        
        
		if (settings.isTaxSubmissionEnabled()) {
	        try {
	            ACAvalaraTaxUtils.cancelTax(orderId.toString(), "Order has been cancelled by CSR", commandContext);
	        } catch (Exception e) {
	            LOGGER.error(methodName, "Exception occured while calling avalara to cancel tax", e);
	        }
		}
        LOGGER.exiting(methodName);
    }

    @Override
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }
}
