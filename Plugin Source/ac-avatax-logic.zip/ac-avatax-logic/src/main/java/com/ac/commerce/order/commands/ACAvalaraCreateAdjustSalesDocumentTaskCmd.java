package com.ac.commerce.order.commands;

import com.ibm.commerce.command.TaskCommand;
import com.ibm.commerce.order.calculation.Item;

public interface ACAvalaraCreateAdjustSalesDocumentTaskCmd extends TaskCommand {
    String NAME = ACAvalaraCreateAdjustSalesDocumentTaskCmd.class.getName();
    String defaultCommandClassName = ACAvalaraCreateAdjustSalesDocumentTaskCmdImpl.class.getName();    

	void setItems(Item[] items);
}
