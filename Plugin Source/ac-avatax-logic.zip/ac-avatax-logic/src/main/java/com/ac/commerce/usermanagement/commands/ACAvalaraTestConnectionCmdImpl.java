package com.ac.commerce.usermanagement.commands;

import javax.servlet.http.HttpServletResponse;

import net.avalara.avatax.rest.client.AvaTaxClient;
import net.avalara.avatax.rest.client.enums.TextCase;
import net.avalara.avatax.rest.client.models.AddressResolutionModel;
import net.avalara.avatax.rest.client.models.AddressValidationInfo;
import net.avalara.avatax.rest.client.models.AvaTaxMessage;

import org.apache.commons.httpclient.HttpStatus;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.settings.ACAvalaraConstants;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ac.avalara.utility.ACAvalaraUtils;
import com.ac.avatax.rest.logger.AvalaraLogger;
import com.ac.avatax.rest.logger.AvalaraLoggerSettings;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.command.ControllerCommandImpl;
import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.exception.ECException;

/**
 * This class tests the connection to the AvaTax service and verifies the AvaTax
 * API Key. This is an important element to allow for successful troubleshooting
 * of the AvaTax service. This is done by performing a known good request (with
 * static values) to the address validation service.
 * 
 * @author askosyr
 */
@SuppressWarnings("serial")
public class ACAvalaraTestConnectionCmdImpl extends ControllerCommandImpl implements ACAvalaraTestConnectionCmd {

	private static final ACLogger LOGGER = new ACLogger(ACAvalaraTestConnectionCmdImpl.class);
	private static final AvalaraLogger AVA_LOGGER =  new AvalaraLogger();
	
	@Override
	public final void performExecute() throws ECException {
		String methodName = "performExecute";
		LOGGER.entering(methodName);
		TypedProperty rspProp = new TypedProperty();

		try {
			ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
			bean.setCommandContext(getCommandContext());
			bean.populate();

			ACAvalaraSettings settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);
			AvalaraLoggerSettings loggerSettings = ACAvalaraSettingsUtils.loadAvalaraLoggerSettings(bean);
			loggerSettings.setLogValidateAddressRequest(loggerSettings.isLogPingRequest());
			AVA_LOGGER.init(loggerSettings);
			
			AddressValidationInfo address = new AddressValidationInfo();

			// setting user input address from typedProperty to address object
			address.setLine1(ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.PING_ADDRESS1));

			address.setCity(ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.PING_CITY));
			address.setRegion(ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.PING_STATE));
			address.setCountry(ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.PING_COUNTRY));
			address.setPostalCode(ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.PING_ZIP_CODE));
			address.setTextCase(TextCase.Mixed);


			AvaTaxClient client = ACAvalaraUtils.getAvaTaxClient(settings);			
			
			if (loggerSettings.isLogEnabled() && loggerSettings.isLogPingRequest()){				
				AVA_LOGGER.log("Requesting URL: " + settings.getUrl());
				AVA_LOGGER.log("Request parameter: " + address);
			}				
			AddressResolutionModel response = client.resolveAddressPost(address);
			if (loggerSettings.isLogEnabled() && loggerSettings.isLogPingRequest()){					
				AVA_LOGGER.log("Response: " + response);
			}			

			if (isErrorsInResponse(response)) {
				// TODO detailed error display
				rspProp.put("error", response.getMessages().get(0).getSummary());
				rspProp.put("resultCode", HttpStatus.SC_NOT_FOUND);
			} else {
				rspProp.put("validAddress", response.getValidatedAddresses().get(0));
				rspProp.put("resultCode", HttpStatus.SC_OK);
			}

			LOGGER.info(methodName, "normalized addresses: {0}", response);

		} catch (Exception e) {
			LOGGER.error(methodName, e.getMessage(), e);
			rspProp.put("Exception", e.getMessage());
		}
		HttpServletResponse response = (HttpServletResponse) this.commandContext.getResponse();
		if(null != response) {
			response.setHeader("Access-Control-Allow-Origin", "*");
			response.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
			response.setHeader("Access-Control-Allow-Headers", "Content-Type");			
		}
		

		setResponseProperties(rspProp);
		// tracing method exit
		LOGGER.exiting(methodName);
	}

	private boolean isErrorsInResponse(AddressResolutionModel response) {
		String methodName = "isErrorsInResponse";
		LOGGER.entering(methodName);
		if (null != response.getMessages()) {
			for (AvaTaxMessage message : response.getMessages()) {
				if ("Error".equals(message.getSeverity())) {
					return true;
				}
			}
		}
		LOGGER.exiting(methodName);
		return false;
	}

}
