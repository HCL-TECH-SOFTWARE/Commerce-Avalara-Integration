/**
 */
package com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl;

import com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage;
import com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACRoot;
import com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACStoreent;
import com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf;

import com.ibm.commerce.infrastructure.facade.server.entity.datatypes.impl.InfrastructureRootImpl;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>AC Root</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACRootImpl#getX_avatax_conf <em>Xavatax conf</em>}</li>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACRootImpl#getACStoreent <em>AC Storeent</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ACRootImpl extends InfrastructureRootImpl implements ACRoot
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final long serialVersionUID = 1L;

  /**
   * The cached value of the '{@link #getX_avatax_conf() <em>Xavatax conf</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getX_avatax_conf()
   * @generated
   * @ordered
   */
  protected EList x_avatax_conf;

  /**
   * The cached value of the '{@link #getACStoreent() <em>AC Storeent</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getACStoreent()
   * @generated
   * @ordered
   */
  protected EList acStoreent;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final int EOFFSET_CORRECTION = ACEntityPackage.Literals.AC_ROOT.getFeatureID(ACEntityPackage.Literals.AC_ROOT__XAVATAX_CONF) - ACEntityPackage.AC_ROOT__XAVATAX_CONF;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ACRootImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass()
  {
    return ACEntityPackage.Literals.AC_ROOT;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getX_avatax_conf()
  {
    if (x_avatax_conf == null)
    {
      x_avatax_conf = new EObjectContainmentEList(X_avatax_conf.class, this, ACEntityPackage.AC_ROOT__XAVATAX_CONF + EOFFSET_CORRECTION);
    }
    return x_avatax_conf;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getACStoreent()
  {
    if (acStoreent == null)
    {
      acStoreent = new EObjectContainmentEList(ACStoreent.class, this, ACEntityPackage.AC_ROOT__AC_STOREENT + EOFFSET_CORRECTION);
    }
    return acStoreent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID - EOFFSET_CORRECTION)
    {
      case ACEntityPackage.AC_ROOT__XAVATAX_CONF:
        return ((InternalEList)getX_avatax_conf()).basicRemove(otherEnd, msgs);
      case ACEntityPackage.AC_ROOT__AC_STOREENT:
        return ((InternalEList)getACStoreent()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID - EOFFSET_CORRECTION)
    {
      case ACEntityPackage.AC_ROOT__XAVATAX_CONF:
        return getX_avatax_conf();
      case ACEntityPackage.AC_ROOT__AC_STOREENT:
        return getACStoreent();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID - EOFFSET_CORRECTION)
    {
      case ACEntityPackage.AC_ROOT__XAVATAX_CONF:
        getX_avatax_conf().clear();
        getX_avatax_conf().addAll((Collection)newValue);
        return;
      case ACEntityPackage.AC_ROOT__AC_STOREENT:
        getACStoreent().clear();
        getACStoreent().addAll((Collection)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(int featureID)
  {
    switch (featureID - EOFFSET_CORRECTION)
    {
      case ACEntityPackage.AC_ROOT__XAVATAX_CONF:
        getX_avatax_conf().clear();
        return;
      case ACEntityPackage.AC_ROOT__AC_STOREENT:
        getACStoreent().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(int featureID)
  {
    switch (featureID - EOFFSET_CORRECTION)
    {
      case ACEntityPackage.AC_ROOT__XAVATAX_CONF:
        return x_avatax_conf != null && !x_avatax_conf.isEmpty();
      case ACEntityPackage.AC_ROOT__AC_STOREENT:
        return acStoreent != null && !acStoreent.isEmpty();
    }
    return super.eIsSet(featureID);
  }


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int eDerivedStructuralFeatureID(int baseFeatureID, Class baseClass)
  {
    if (baseClass == ACRoot.class)
    {
      switch (baseFeatureID - EOFFSET_CORRECTION)
      {
        case ACEntityPackage.AC_ROOT__XAVATAX_CONF: return ACEntityPackage.AC_ROOT__XAVATAX_CONF + EOFFSET_CORRECTION;
        case ACEntityPackage.AC_ROOT__AC_STOREENT: return ACEntityPackage.AC_ROOT__AC_STOREENT + EOFFSET_CORRECTION;
        default: return -1;
      }
    }
    return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
  }
  
  /**
   * AVAIP-1036: Out-of-the-box classes (e.g. OnlineStorePageDefinitionsGraphComposer) execute method getStoreent() directly, which is empty, 
   * when custom ACStoreent object is used.
   * 
   * Important note: Data Service Layer generation tool may override this method. Please make sure to restore the overriden method.
   */
  @Override
  public List getStoreent() {
	  List storeent = super.getStoreent();
	  if (storeent != null && !storeent.isEmpty()) {
		  return storeent;
	  }
	  return getACStoreent(); 
  }

} //ACRootImpl