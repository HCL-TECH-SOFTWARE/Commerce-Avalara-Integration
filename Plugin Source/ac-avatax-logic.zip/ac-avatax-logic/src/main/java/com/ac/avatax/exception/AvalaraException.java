package com.ac.avatax.exception;

public class AvalaraException extends Exception {

	public AvalaraException() {
		super();
	}

	public AvalaraException(String message, Throwable cause) {
		super(message, cause);
	}

	public AvalaraException(String message) {
		super(message);
	}

	public AvalaraException(Throwable cause) {
		super(cause);
	}

}
