/**
 */
package com.ac.commerce.infrastructure.facade.server.entity.datatypes.util;

import com.ac.commerce.infrastructure.facade.server.entity.datatypes.*;

import com.ibm.commerce.infrastructure.facade.server.entity.datatypes.InfrastructureRoot;
import com.ibm.commerce.infrastructure.facade.server.entity.datatypes.Storeent;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage
 * @generated
 */
public class ACEntityAdapterFactory extends AdapterFactoryImpl
{
  /**
   * The cached model package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected static ACEntityPackage modelPackage;

  /**
   * Creates an instance of the adapter factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ACEntityAdapterFactory()
  {
    if (modelPackage == null)
    {
      modelPackage = ACEntityPackage.eINSTANCE;
    }
  }

  /**
   * Returns whether this factory is applicable for the type of the object.
   * <!-- begin-user-doc -->
   * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
   * <!-- end-user-doc -->
   * @return whether this factory is applicable for the type of the object.
   * @generated
   */
  public boolean isFactoryForType(Object object)
  {
    if (object == modelPackage)
    {
      return true;
    }
    if (object instanceof EObject)
    {
      return ((EObject)object).eClass().getEPackage() == modelPackage;
    }
    return false;
  }

  /**
   * The switch that delegates to the <code>createXXX</code> methods.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ACEntitySwitch modelSwitch =
    new ACEntitySwitch()
    {
      public Object caseACRoot(ACRoot object)
      {
        return createACRootAdapter();
      }
      public Object caseX_avatax_conf(X_avatax_conf object)
      {
        return createX_avatax_confAdapter();
      }
      public Object caseACStoreent(ACStoreent object)
      {
        return createACStoreentAdapter();
      }
      public Object caseInfrastructureRoot(InfrastructureRoot object)
      {
        return createInfrastructureRootAdapter();
      }
      public Object caseStoreent(Storeent object)
      {
        return createStoreentAdapter();
      }
      public Object defaultCase(EObject object)
      {
        return createEObjectAdapter();
      }
    };

  /**
   * Creates an adapter for the <code>target</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param target the object to adapt.
   * @return the adapter for the <code>target</code>.
   * @generated
   */
  public Adapter createAdapter(Notifier target)
  {
    return (Adapter)modelSwitch.doSwitch((EObject)target);
  }


  /**
   * Creates a new adapter for an object of class '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACRoot <em>AC Root</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACRoot
   * @generated
   */
  public Adapter createACRootAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf <em>Xavatax conf</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf
   * @generated
   */
  public Adapter createX_avatax_confAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACStoreent <em>AC Storeent</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACStoreent
   * @generated
   */
  public Adapter createACStoreentAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.commerce.infrastructure.facade.server.entity.datatypes.InfrastructureRoot <em>Infrastructure Root</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.commerce.infrastructure.facade.server.entity.datatypes.InfrastructureRoot
   * @generated
   */
  public Adapter createInfrastructureRootAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link com.ibm.commerce.infrastructure.facade.server.entity.datatypes.Storeent <em>Storeent</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see com.ibm.commerce.infrastructure.facade.server.entity.datatypes.Storeent
   * @generated
   */
  public Adapter createStoreentAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for the default case.
   * <!-- begin-user-doc -->
   * This default implementation returns null.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @generated
   */
  public Adapter createEObjectAdapter()
  {
    return null;
  }

} //ACEntityAdapterFactory
