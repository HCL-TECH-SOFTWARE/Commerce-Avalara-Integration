package com.ac.commerce.usermanagement.commands;

import com.ibm.commerce.command.ControllerCommand;

public interface ACAvalaraAddressVerificationCmd extends ControllerCommand {

    String defaultCommandClassName = ACAvalaraAddressVerificationCmdImpl.class.getName();
}
