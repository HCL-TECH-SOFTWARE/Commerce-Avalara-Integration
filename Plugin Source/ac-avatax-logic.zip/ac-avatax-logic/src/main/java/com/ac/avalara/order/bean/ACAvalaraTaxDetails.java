package com.ac.avalara.order.bean;


public class ACAvalaraTaxDetails {
	
	private Long orderId;
	private Long orderItemId;
	private String taxtype;
	private String taxname;
	private String taxable;
	private String rate;
	private String tax;
	private String nontaxable;
	private String excemption;
	private ACAvalaraTaxDetailsType type;
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public Long getOrderItemId() {
		return orderItemId;
	}
	public void setOrderItemId(Long orderItemId) {
		this.orderItemId = orderItemId;
	}
	public String getTaxtype() {
		return taxtype;
	}
	public void setTaxtype(String taxtype) {
		this.taxtype = taxtype;
	}
	public String getTaxname() {
		return taxname;
	}
	public void setTaxname(String taxname) {
		this.taxname = taxname;
	}
	public String getTaxable() {
		return taxable;
	}
	public void setTaxable(String taxable) {
		this.taxable = taxable;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}
	public String getTax() {
		return tax;
	}
	public void setTax(String tax) {
		this.tax = tax;
	}
	public String getNontaxable() {
		return nontaxable;
	}
	public void setNontaxable(String nontaxable) {
		this.nontaxable = nontaxable;
	}
	public String getExcemption() {
		return excemption;
	}
	public void setExcemption(String excemption) {
		this.excemption = excemption;
	}
	public ACAvalaraTaxDetailsType getType() {
		return type;
	}
	public void setType(ACAvalaraTaxDetailsType type) {
		this.type = type;
	}
	
	

	
	
}
