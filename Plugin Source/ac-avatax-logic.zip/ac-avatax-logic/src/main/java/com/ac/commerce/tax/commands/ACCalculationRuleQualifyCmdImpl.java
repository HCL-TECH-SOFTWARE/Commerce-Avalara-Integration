package com.ac.commerce.tax.commands;

import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.fulfillment.objects.CalculationRuleAccessBean;
import com.ibm.commerce.order.calculation.CalculationCmdImpl;
import com.ibm.commerce.order.calculation.Item;

public class ACCalculationRuleQualifyCmdImpl extends CalculationCmdImpl implements ACCalculationRuleQualifyCmd {

	private static final String CLASS_NAME = ACCalculationRuleQualifyCmdImpl.class.getName();
	private final ACLogger LOGGER = new ACLogger(ACCalculationRuleQualifyCmdImpl.class);

	private Item[] items;
	private Item[] qualifiedItems;
	private CalculationRuleAccessBean calRule;

	@Override
	public Item[] getQualifiedItems() {
		return this.qualifiedItems;
	}

	@Override
	public void setItems(Item[] paramArrayOfItem) {
		this.items = paramArrayOfItem;

	}

	@Override
	public void setRule(CalculationRuleAccessBean paramCalculationRuleAccessBean) {
		this.calRule = paramCalculationRuleAccessBean;
	}

	@Override
	public void performExecute() throws ECException {
		super.performExecute();
		this.qualifiedItems = new Item[this.items.length];
		for (int i = 0; i < this.items.length; i++) {
			this.qualifiedItems[i] = this.items[i];
		}
	}
}
