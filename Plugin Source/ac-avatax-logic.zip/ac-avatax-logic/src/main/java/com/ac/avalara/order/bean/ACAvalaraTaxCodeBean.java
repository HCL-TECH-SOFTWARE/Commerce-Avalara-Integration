package com.ac.avalara.order.bean;

import java.util.Vector;

import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.base.objects.ServerJDBCHelperBean;
import com.ibm.commerce.beans.SmartDataBean;
import com.ibm.commerce.beans.SmartDataBeanImpl;


public class ACAvalaraTaxCodeBean extends SmartDataBeanImpl implements
		SmartDataBean {

	private String segmentId;
	private String taxCode;
	private static final ACLogger LOGGER = new ACLogger(ACAvalaraTaxCodeBean.class);
	
	@Override
	public void populate() throws Exception {
		String methodName = "populate()";
		try {
			if (segmentId != null){
				ServerJDBCHelperBean jdbcHelper = new ServerJDBCHelperBean();
				
	            Vector<Vector<?>> vRecords = jdbcHelper.executeQuery(String.format("select * from X_AVATAX_MBRGRP where MBRGRP_ID=%d", Long.valueOf(segmentId)));
	            if (vRecords != null && !vRecords.isEmpty()) {
	                for (Vector<?> oRecord : vRecords) {
	                	this.taxCode = (String) oRecord.get(1);
	                }
	            } else {
	            	this.taxCode = "";
	            }
			} else {
				this.taxCode = "";
			}
		}catch (Exception e){
			LOGGER.error(methodName, "Error occured while getting custom avatax users information " + e.getMessage());
		}
	}
	
	public void update() throws Exception {
		String methodName = "populate()";
		try {
			if (segmentId != null){
				ServerJDBCHelperBean jdbcHelper = new ServerJDBCHelperBean();
				Vector<Vector<?>> vRecords = jdbcHelper.executeQuery("select * from X_AVATAX_MBRGRP where MBRGRP_ID=" + segmentId);
	            if (vRecords != null && !vRecords.isEmpty()) {
	            	jdbcHelper.executeUpdate(String.format("update X_AVATAX_MBRGRP set TAX_CODE='%s' where MBRGRP_ID= %d", taxCode, Long.valueOf(segmentId)));
	            } else if (taxCode != null){
	            	jdbcHelper.executeUpdate(String.format("insert into X_AVATAX_MBRGRP(MBRGRP_ID, TAX_CODE) VALUES(%d, '%s')", Long.valueOf(segmentId), taxCode));
	            }
			}
		}catch (Exception e){
			LOGGER.error(methodName, "Error occured while updating custom avatax users information " + e.getMessage());
		}
	}

	public String getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(String segmentId) {
		this.segmentId = segmentId;
	}

	public String getTaxCode() {
		return taxCode;
	}

	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}

}
