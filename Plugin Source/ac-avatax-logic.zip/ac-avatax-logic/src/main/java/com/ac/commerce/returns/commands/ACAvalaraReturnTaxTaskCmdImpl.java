package com.ac.commerce.returns.commands;

import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.lang3.StringUtils;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ac.avalara.utility.ACAvalaraTaxUtils;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.command.TaskCommandImpl;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.order.objects.OrderItemAccessBean;
import com.ibm.commerce.ordermanagement.objects.RMAItemAccessBean;
import com.ibm.commerce.ras.ECMessage;

@SuppressWarnings("serial")
public class ACAvalaraReturnTaxTaskCmdImpl extends TaskCommandImpl implements ACAvalaraReturnTaxTaskCmd {

	private static final ACLogger LOGGER = new ACLogger(ACAvalaraReturnTaxTaskCmdImpl.class);
	private static final String CLASS_NAME = ACAvalaraReturnTaxTaskCmdImpl.class.getName();
	private String rmaId;
	private String orderId;
	private Vector<RMAItemAccessBean> rmaItems;
	private ACAvalaraSettings settings;

	@Override
	public void performExecute() throws ECException {
		String methodName = "performExecute";
		LOGGER.entering(methodName);

		super.performExecute();
		try {
			LOGGER.trace(methodName, "ENABLE_AVATAX_TAX_CALCULATION: {0}", settings.isTaxSubmissionEnabled());
			if (settings.isTaxSubmissionEnabled()) {
				ACAvalaraTaxUtils.calculateAndSubmitReturnTax(rmaItems, commandContext, rmaId, orderId);
			} else if (settings.isTaxCalculationEnabled()) {
				ACAvalaraTaxUtils.calculateOnlyReturnTax(rmaItems, commandContext, rmaId, orderId);
			}
		} catch (Exception e) {
			LOGGER.error(methodName, "ECException occured while calling SIAvalaraReturnTaxCmdImpl", e);
		}
		LOGGER.exiting(methodName);
	}

	@Override
	public void setRmaID(String rmaId) {
		this.rmaId = rmaId;
	}

	@Override
	public void setRmaItems(Vector vRMAItems) {
		this.rmaItems = vRMAItems;
	}

	@Override
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	@Override
	public void validateParameters() throws ECException {
		String methodName = "validateParameters";
		super.validateParameters();

		try {
			ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
			bean.setCommandContext(commandContext);
			try {
				bean.populate();
			} catch (Exception e) {

				LOGGER.error(methodName, "Error occured while loading avatax configuration:" + e.getMessage());
			}
			this.settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);

			if (settings.isTaxSubmissionEnabled()) {
				Set<String> ordersId = new HashSet<String>();
				for (RMAItemAccessBean rmaItem : this.rmaItems) {
					if (!StringUtils.isEmpty(rmaItem.getOrderItemsId())) {
						OrderItemAccessBean orderItemAB = new OrderItemAccessBean();
						orderItemAB.setInitKey_orderItemId(rmaItem.getOrderItemsId());
						ordersId.add(orderItemAB.getOrderId());
					}
				}
				
				if (ordersId.size() > 1) {
					LOGGER.error(methodName, "Avalara can return one order at time only. Please create one return per order");
					throw new ECApplicationException(ECMessage._ERR_BAD_MISSING_CMD_PARAMETER, CLASS_NAME, methodName, new Object[]{"ORDER_ID. Avalara plugin supports only one order_id per return. Please create one return per order"});					
				}
			}

		} catch (Exception e) {
			LOGGER.error(methodName, "Error occured while loading avatax configuration:" + e.getMessage());
			throw new ECApplicationException(ECMessage._ERR_GENERIC, CLASS_NAME, methodName, new Object[]{"Unable to validate parameters"});
		}

		LOGGER.exiting(methodName);
	}

}
