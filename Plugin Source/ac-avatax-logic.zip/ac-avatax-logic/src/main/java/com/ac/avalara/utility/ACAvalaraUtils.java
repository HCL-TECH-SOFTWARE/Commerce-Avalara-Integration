package com.ac.avalara.utility;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import net.avalara.avatax.rest.client.AvaTaxClient;

import org.apache.commons.lang3.StringUtils;

import com.ac.avalara.order.bean.ACAvalaraTaxCodeBean;
import com.ac.avalara.settings.ACAvalaraConstants;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avatax.exception.AvalaraException;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.base.objects.ServerJDBCHelperBean;
import com.ibm.commerce.command.CommandContext;
import com.ibm.commerce.order.calculation.Item;
import com.ibm.commerce.order.objects.OrderItemAccessBean;
import com.ibm.commerce.taxation.objects.CountryAccessBean;
import com.ibm.commerce.taxation.objects.StateProvinceAccessBean;
import com.ibm.commerce.user.objects.AddressAccessBean;
import com.ibm.commerce.user.objects.MemberGroupMemberAccessBean;

public class ACAvalaraUtils {

	private static final ACLogger LOGGER = new ACLogger(ACAvalaraUtils.class);
	private static final String SQL_GET_ATTRIBUTEVALUE = "SELECT VD.STRINGVALUE FROM ATTR A, ATTRVAL V, ATTRVALDESC VD, CATENTRYATTR CA, CATENTREL CATREL WHERE A.ATTR_ID=V.ATTR_ID AND V.ATTRVAL_ID=VD.ATTRVAL_ID AND CA.ATTR_ID=A.ATTR_ID AND V.ATTRVAL_ID=CA.ATTRVAL_ID AND CA.CATENTRY_ID=CATREL.CATENTRY_ID_PARENT and  a.identifier = ? and CATREL.CATENTRY_ID_CHILD = ? with ur";	

	
	
	public static String getAttributeValue(String childCatentryId, String attrIdentifier) {
		final String methodName = "getTaxCode";
		LOGGER.entering(methodName, childCatentryId);

		// Get the taxcode. It uses the SQLTAXCODE parameter Avatax.properties
		// to fetch.
		String taxCode = "";
		try {
			ServerJDBCHelperBean jdbcHelper = new ServerJDBCHelperBean();
			LOGGER.trace(methodName, "getAttributeValueSQL: {0}", SQL_GET_ATTRIBUTEVALUE);
			List<String> parameters = new ArrayList<String>();
			parameters.add(attrIdentifier);
			parameters.add(childCatentryId);
			LOGGER.trace(methodName, "parameters: {0}", parameters);

			List resultSetVector = jdbcHelper.executeParameterizedQuery(SQL_GET_ATTRIBUTEVALUE, parameters.toArray());

			if (null != resultSetVector && resultSetVector.size() > 0) {
				Iterator itr = resultSetVector.iterator();
				while (itr.hasNext()) {
					List innerVector = (List) itr.next();
					if (null != innerVector.get(0)) {
						taxCode = innerVector.get(0).toString();
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(methodName, "Exception in getTaxCode", e);
		}

		LOGGER.exiting(methodName, taxCode);
		return taxCode;
	}	
    
	public static String getCustomerUsageType(CommandContext commandContext) throws Exception {
		String retval = null;
		String methodName = "getCustomerUsageType(CommandContext commandContext)";
		LOGGER.entering(methodName);
		Enumeration<MemberGroupMemberAccessBean> maabEnum = new MemberGroupMemberAccessBean().findByMember(commandContext.getUserId());
		while (maabEnum.hasMoreElements()) {
			MemberGroupMemberAccessBean current = maabEnum.nextElement();
			ACAvalaraTaxCodeBean avataxCodeBean = new ACAvalaraTaxCodeBean();
			avataxCodeBean.setSegmentId(current.getMbrGrpId());
			avataxCodeBean.populate();
			if (avataxCodeBean.getTaxCode() != null) {
				retval = avataxCodeBean.getTaxCode();
				LOGGER.trace(methodName, "Found customerUsageType value: " + avataxCodeBean.getTaxCode());
				break;
			}
		}
		LOGGER.exiting(methodName);

		return retval;
	}

	

	public static AvaTaxClient getAvaTaxClient(ACAvalaraSettings settings) {
		AvaTaxClient retval = new AvaTaxClient(ACAvalaraConstants.CLNT_APP_NAME, ACAvalaraConstants.CLNT_APP_VERSION, "localhost", settings.getUrl());
		retval.withSecurity(settings.getAccountId(), settings.getLicenseKey());
		return retval;
	}

	public static OrderItemAccessBean[] getOrderItemBeans(Item[] items) {
		OrderItemAccessBean[] retval = new OrderItemAccessBean[items.length];
		for(int i = 0; i< items.length; i++) {
			retval[i] = items[i].getOrderItem();
		}
		
		return retval;
	}
	
	public static Item[] getItemBeans(OrderItemAccessBean[] orderItems) throws Exception {		
		Item[] items = new Item[orderItems.length];		
		for(int i = 0; i < items.length; i++) {
			items[i] = new Item(orderItems[i]);
		}
		return items;
	}
	
	public static boolean isNoAddressesInItems(Item[] items) throws Exception {
		OrderItemAccessBean[] orderItemBeans = getOrderItemBeans(items);
		return isNoAddressesInItems(orderItemBeans);
	}	
	
	public static boolean isNoAddressesInItems(OrderItemAccessBean[] orderItemBeans) throws Exception {
		for (OrderItemAccessBean orderItem : orderItemBeans) {
			if (StringUtils.isEmpty(orderItem.getAddressId())) {
				return true;
			}
		}
		return false;
	}	
	
	//this is workaround for ship to store option where state and country are not codes but names. avalara accept only codes
	public static String getCountryCode(String country) throws Exception {
		String retval = country;
		String methodName = "getCountryCode";
		LOGGER.entering(methodName);
		if (country.length() > 2) {
			CountryAccessBean countryBean = new CountryAccessBean();
			Enumeration countries = countryBean.findByLanguageIdAndCountryName(-1, country);
			if(countries.hasMoreElements()) {
				retval = ((CountryAccessBean)countries.nextElement()).getCountryAbbr();
			}
		}		
		
		LOGGER.exiting(methodName);
		return retval;
	}

	//this is workaround for ship to store option where state and country are not codes but names. avalara accept only codes
	public static String getRegionCode(String state) throws Exception {
		String retval = state;		
		String methodName = "getRegionCode";
		LOGGER.entering(methodName);

		if (state.length() > 3) {
			StateProvinceAccessBean stateBean = new StateProvinceAccessBean();
			Enumeration states = stateBean.findByLanguageIdAndStateName(-1, state);
			if(states.hasMoreElements()) {
				retval = ((StateProvinceAccessBean)states.nextElement()).getStateAbbr();
			}
		}
		
		LOGGER.exiting(methodName);
		return retval;
	}
	
	
	public static boolean isShippingToCountriesWithEnbaledLandedCost(Item[] items, String dapCountries, String ddpCountries, CommandContext commandContext) throws AvalaraException {
		OrderItemAccessBean[] orderItemBeans = getOrderItemBeans(items);
		return isShippingToCountriesWithEnbaledLandedCost(orderItemBeans, dapCountries, ddpCountries, commandContext);
	}	

	public static boolean isShippingToCountriesWithEnbaledLandedCost(OrderItemAccessBean[] orderItemBeans, String dapCountries, String ddpCountries, CommandContext commandContext) throws AvalaraException {
		String methodName = "isShippingToCountriesWithEnbaledLandedCost";
		LOGGER.entering(methodName);
		boolean retval = false;

		if (StringUtils.isNotEmpty(dapCountries) || StringUtils.isNotEmpty(ddpCountries)) {
			try {
				for (OrderItemAccessBean orderItem : orderItemBeans) {

					AddressAccessBean address = new AddressAccessBean();
					address.setInitKey_addressId(orderItem.getAddressId());
//					address.instantiateEntity();
					String country = address.getCountry();
					if ((StringUtils.isNotEmpty(dapCountries) && dapCountries.contains(country)) || (StringUtils.isNotEmpty(ddpCountries) && ddpCountries.contains(country))) {
						retval = true;
						break;
					}
				}
			} catch (Exception e) {
				LOGGER.error(methodName, e.getMessage(), e);
				throw new AvalaraException("Unable to check if order will be shipped to country with enabled Landed Cost");
			}

		}

		LOGGER.exiting(methodName);
		return retval;
	}
    
}
