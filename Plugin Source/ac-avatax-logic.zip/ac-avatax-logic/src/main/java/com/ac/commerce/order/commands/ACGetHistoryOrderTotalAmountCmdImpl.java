package com.ac.commerce.order.commands;

import java.math.BigDecimal;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.order.commands.GetHistoryOrderTotalAmountCmd;
import com.ibm.commerce.order.commands.GetHistoryOrderTotalAmountCmdImpl;
import com.ibm.commerce.order.history.HistoryOrder;
import com.ibm.commerce.ras.ECTrace;

public class ACGetHistoryOrderTotalAmountCmdImpl extends
		GetHistoryOrderTotalAmountCmdImpl implements
		GetHistoryOrderTotalAmountCmd {
	private HistoryOrder ianOrder;
	private BigDecimal idTotalAmount;

	public ACGetHistoryOrderTotalAmountCmdImpl() {
		ianOrder = null;
		idTotalAmount = new BigDecimal(0);
	}

	public void performExecute() throws ECException {
		String strMethod = "performExecute";
		if (ECTrace.traceEnabled(3L))
			ECTrace.entry(
					3L,
					"com.ibm.commerce.order.commands.GetHistoryOrderTotalAmountCmdImpl",
					"performExecute");

		if (getHistoryOrder() != null) {
			if (ECTrace.traceEnabled(3L)) {
				ECTrace.trace(
						3L,
						"com.ibm.commerce.order.commands.GetHistoryOrderTotalAmountCmdImpl",
						"performExecute",
						(new StringBuilder("Product total = ")).append(
								getHistoryOrder().getTotalProductPrice())
								.toString());

				ECTrace.trace(
						3L,
						"com.ibm.commerce.order.commands.GetHistoryOrderTotalAmountCmdImpl",
						"performExecute", (new StringBuilder("Total tax = "))
								.append(getHistoryOrder().getTotalTax())
								.toString());

				ECTrace.trace(
						3L,
						"com.ibm.commerce.order.commands.GetHistoryOrderTotalAmountCmdImpl",
						"performExecute",
						(new StringBuilder("Shipping total = ")).append(
								getHistoryOrder().getTotalShippingCharge())
								.toString());

				ECTrace.trace(
						3L,
						"com.ibm.commerce.order.commands.GetHistoryOrderTotalAmountCmdImpl",
						"performExecute",
						(new StringBuilder("Shipping tax total = ")).append(
								getHistoryOrder().getTotalShippingTax())
								.toString());

				ECTrace.trace(
						3L,
						"com.ibm.commerce.order.commands.GetHistoryOrderTotalAmountCmdImpl",
						"performExecute",
						(new StringBuilder("Adjustment total = ")).append(
								getHistoryOrder().getTotalAdjustment())
								.toString());

			}
			ACAvalaraSettings settings = null;
			try {
				ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
				bean.setCommandContext(commandContext);
				bean.populate();
				settings = ACAvalaraSettingsUtils
						.loadAvalaraGeneralSettings(bean);
			} catch (Exception e) {
				e.printStackTrace();
			}

			idTotalAmount = getHistoryOrder().getTotalProductPrice();
			if (settings != null && !settings.getTaxIncluded()) {
				idTotalAmount = idTotalAmount.add(getHistoryOrder()
						.getTotalTax());
				idTotalAmount = idTotalAmount.add(getHistoryOrder()
						.getTotalShippingTax());
			}
			idTotalAmount = idTotalAmount.add(getHistoryOrder()
					.getTotalShippingCharge());
			idTotalAmount = idTotalAmount.add(getHistoryOrder()
					.getTotalAdjustment());

			ECTrace.trace(
					3L,
					"com.ibm.commerce.order.commands.GetHistoryOrderTotalAmountCmdImpl",
					"performExecute", (new StringBuilder("idTotalAmount = "))
							.append(idTotalAmount).toString());

		}
		if (ECTrace.traceEnabled(3L))
			ECTrace.exit(
					3L,
					"com.ibm.commerce.order.commands.GetHistoryOrderTotalAmountCmdImpl",
					"performExecute");
	}

	public void reset() {
		super.reset();
		ianOrder = null;
		idTotalAmount = new BigDecimal(0);
	}

	public HistoryOrder getHistoryOrder() {
		return ianOrder;
	}

	public BigDecimal getTotalAmount() {
		return idTotalAmount;
	}

	public void setHistoryOrder(HistoryOrder anOrder) {
		ianOrder = anOrder;
	}
}
