package com.ac.commerce.order.commands;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ac.avalara.utility.ACAvalaraTaxUtils;
import com.ac.avatax.exception.AvalaraException;
import com.ac.avatax.rest.logger.AvalaraLogger;
import com.ac.avatax.rest.logger.AvalaraLoggerSettings;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.command.TaskCommandImpl;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.ras.ECMessage;
import com.ibm.commerce.ras.ECMessageHelper;
import com.ibm.commerce.ras.ECMessageSeverity;
import com.ibm.commerce.ras.ECMessageType;

@SuppressWarnings("serial")
public class ACAvalaraCommitTransactionTaskCmdImpl extends TaskCommandImpl implements ACAvalaraCommitTransactionTaskCmd {

	private static final String CLASS_NAME = ACAvalaraCommitTransactionTaskCmdImpl.class.getName();
	private static final ACLogger LOGGER = new ACLogger(ACAvalaraCommitTransactionTaskCmdImpl.class);
	private static final AvalaraLogger AVA_LOGGER = new AvalaraLogger();

	private Long orderId;
	static final String errorBundle = "avalaraStoreErrorMessages";
	public static final ECMessage _ERR_LANDED_COST_MULTIPLE_DESTINATION = new ECMessage(ECMessageSeverity.ERROR, ECMessageType.USER, "_ERR_LANDED_COST_MULTIPLE_DESTINATION", errorBundle);

	@Override
	public void performExecute() throws ECException {
		String methodName = "performExecute";
		LOGGER.entering(methodName);

		super.performExecute();

		ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
		bean.setCommandContext(commandContext);
		try {
			bean.populate();
		} catch (Exception e) {
			LOGGER.error(methodName, "Error occured while loading avatax configuration:" + e.getMessage());
		}
		ACAvalaraSettings settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);
		AvalaraLoggerSettings loggerSettings = ACAvalaraSettingsUtils.loadAvalaraLoggerSettings(bean);
		if (settings.isTaxSubmissionEnabled()) {
			try {
				ACAvalaraTaxUtils.commitTransaction(String.valueOf(orderId), commandContext, settings, loggerSettings);
			} catch (AvalaraException e) {
				LOGGER.error(methodName, "Unable to commit transaction with code: " + String.valueOf(orderId) + " because of: " + ECMessageHelper.getExceptionStackTrace(e));
				throw new ECApplicationException(ECMessage._ERR_GENERIC, CLASS_NAME, methodName, new Object[] { e.getMessage() }, true);
			}
		}

		LOGGER.exiting(methodName);
	}

	@Override
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
}
