package com.ac.commerce.returns.commands;

import com.ac.commerce.order.commands.ACAvalaraCancelTaxTaskCmd;
import com.ac.commerce.util.CommandFactory;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.ordermanagement.objects.RMAAccessBean;
import com.ibm.commerce.ras.ECMessage;
import com.ibm.commerce.returns.commands.ExtendReturnCancelCmd;
import com.ibm.commerce.returns.commands.ExtendReturnCancelCmdImpl;

public class ACExtendReturnCancelCmdImpl extends ExtendReturnCancelCmdImpl implements ExtendReturnCancelCmd {
	private static final String CLASS_NAME = ACExtendReturnCancelCmdImpl.class.getName();
	private final ACLogger LOGGER = new ACLogger(ACExtendReturnCancelCmdImpl.class);
	private RMAAccessBean rma;
	private Long rmaId = null;

	public void performExecute() throws ECException {
		String methodName = "performExecute";
		LOGGER.entering(methodName);
		super.performExecute();

        ACAvalaraCancelTaxTaskCmd task = CommandFactory.createTask(ACAvalaraCancelTaxTaskCmd.class, commandContext);
        task.setOrderId(this.rmaId);
        task.execute();		
		
		
		LOGGER.exiting(methodName);
	}

	public void reset() {
	}

	public void setRequestProperties(TypedProperty aRequestProperties) throws ECApplicationException {
	}

	public void setResponseProperties(TypedProperty aResponseProperties) {
	}

	public void setRMAAB(RMAAccessBean anRMAAB) {
		this.rma = anRMAAB;
	}

	public void validateParameters() throws ECException {
		String methodName = "validateParameters";
		LOGGER.entering(methodName);
		super.validateParameters();

		if (null == this.rma) {
			// Input field "{0}" contains invalid value "{1}" for command "{2}".
			throw new ECApplicationException(ECMessage._ERR_BAD_CMD_PARAMETER, CLASS_NAME, methodName, new Object[] { "rmaAccessBean", "null", CLASS_NAME });
		}



		try {
			this.rmaId = this.rma.getRmaIdInEntityType();
		} catch (Exception e) {
			LOGGER.error(methodName, "Unable to get rmaId");
			throw new ECApplicationException(ECMessage._ERR_BAD_CMD_PARAMETER, CLASS_NAME, methodName, new Object[] { "rmaId", "null", CLASS_NAME });
		}

		LOGGER.exiting(methodName);
	}

}
