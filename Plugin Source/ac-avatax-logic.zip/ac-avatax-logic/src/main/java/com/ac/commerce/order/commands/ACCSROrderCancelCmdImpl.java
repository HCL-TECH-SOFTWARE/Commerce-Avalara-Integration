package com.ac.commerce.order.commands;

import com.ac.commerce.util.CommandFactory;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.tools.optools.order.commands.CSROrderCancelCmdImpl;

@SuppressWarnings("serial")
public class ACCSROrderCancelCmdImpl extends CSROrderCancelCmdImpl {
    private static final ACLogger LOGGER = new ACLogger(ACCSROrderCancelCmdImpl.class);

    @Override
    public void performExecute() throws ECException {
        String methodName = "performExecute";
        LOGGER.entering(methodName);

        super.performExecute();

        ACAvalaraCancelTaxTaskCmd task = CommandFactory.createTask(ACAvalaraCancelTaxTaskCmd.class, commandContext);
        task.setOrderId(commandContext.getRequestProperties().getLong("orderId", null));
        task.execute();

        LOGGER.exiting(methodName);
    }
}
