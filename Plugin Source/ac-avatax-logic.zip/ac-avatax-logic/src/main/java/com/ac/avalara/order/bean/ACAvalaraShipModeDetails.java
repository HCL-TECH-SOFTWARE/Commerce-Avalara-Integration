package com.ac.avalara.order.bean;

import com.ac.avalara.utility.LandedCostIsExpress;

public class ACAvalaraShipModeDetails {

	private Integer shipModeId;
	private String mode;
	private String htsCode;
	private LandedCostIsExpress isExpress;

	public String getHtsCode() {
		return htsCode;
	}

	public String getMode() {
		return mode;
	}

	public Integer getShipModeId() {
		return shipModeId;
	}

	public void setHtsCode(String htsCode) {
		this.htsCode = htsCode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public void setShipModeId(Integer shipModeId) {
		this.shipModeId = shipModeId;
	}

	public boolean isExpress() { 
		return LandedCostIsExpress.Y.equals(this.isExpress);
	}
	
	public LandedCostIsExpress getIsExpressEnum() { 
		return this.isExpress;
	}	
	
	public void setExpress(LandedCostIsExpress isExpress) {
		this.isExpress = isExpress;
	}

}
