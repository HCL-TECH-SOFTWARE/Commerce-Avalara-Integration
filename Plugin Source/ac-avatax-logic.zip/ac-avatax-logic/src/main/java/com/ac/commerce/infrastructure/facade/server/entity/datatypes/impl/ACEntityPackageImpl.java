/**
 */
package com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl;

import com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityFactory;
import com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage;
import com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACRoot;
import com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACStoreent;
import com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf;

import com.ibm.commerce.infrastructure.facade.server.entity.datatypes.InfrastructureEntityPackage;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ACEntityPackageImpl extends EPackageImpl implements ACEntityPackage
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass acRootEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass x_avatax_confEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass acStoreentEClass = null;

  /**
   * Creates an instance of the model <b>Package</b>, registered with
   * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
   * package URI value.
   * <p>Note: the correct way to create the package is via the static
   * factory method {@link #init init()}, which also performs
   * initialization of the package, or returns the registered package,
   * if one already exists.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.emf.ecore.EPackage.Registry
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#eNS_URI
   * @see #init()
   * @generated
   */
  private ACEntityPackageImpl()
  {
    super(eNS_URI, ACEntityFactory.eINSTANCE);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static boolean isInited = false;

  /**
   * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
   * 
   * <p>This method is used to initialize {@link ACEntityPackage#eINSTANCE} when that field is accessed.
   * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #eNS_URI
   * @see #createPackageContents()
   * @see #initializePackageContents()
   * @generated
   */
  public static ACEntityPackage init()
  {
    if (isInited) return (ACEntityPackage)EPackage.Registry.INSTANCE.getEPackage(ACEntityPackage.eNS_URI);

    // Obtain or create and register package
    ACEntityPackageImpl theACEntityPackage = (ACEntityPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof ACEntityPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new ACEntityPackageImpl());

    isInited = true;

    // Initialize simple dependencies
    InfrastructureEntityPackage.eINSTANCE.eClass();

    // Create package meta-data objects
    theACEntityPackage.createPackageContents();

    // Initialize created meta-data
    theACEntityPackage.initializePackageContents();

    // Mark meta-data to indicate it can't be changed
    theACEntityPackage.freeze();

  
    // Update the registry and return the package
    EPackage.Registry.INSTANCE.put(ACEntityPackage.eNS_URI, theACEntityPackage);
    return theACEntityPackage;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getACRoot()
  {
    return acRootEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getACRoot_X_avatax_conf()
  {
    return (EReference)acRootEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getACRoot_ACStoreent()
  {
    return (EReference)acRootEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getX_avatax_conf()
  {
    return x_avatax_confEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Storeent_id()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Urltoconnect()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Accnum()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Companycode()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Taxcalculationmode()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Transactionlogging()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Translogkeephours()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Supportedcountries()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Taxcountries()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Addrountries()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Behavioronerror()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(10);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Defaulttax()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(11);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Addrvalidationplaces()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(12);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Customervatid()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(13);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Pricecontainstaxes()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(14);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Oitaxesdisplayed()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(15);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Logrequesttypes()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(16);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Authkey()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(17);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Taxcodeidentifier()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(18);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Dapcountries()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(19);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Ddpcountries()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(20);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getX_avatax_conf_Optcounter()
  {
    return (EAttribute)x_avatax_confEClass.getEStructuralFeatures().get(21);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getX_avatax_conf_StoreentForX_avatax_conf()
  {
    return (EReference)x_avatax_confEClass.getEStructuralFeatures().get(22);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getACStoreent()
  {
    return acStoreentEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getACStoreent_X_avatax_confForStoreent()
  {
    return (EReference)acStoreentEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ACEntityFactory getACEntityFactory()
  {
    return (ACEntityFactory)getEFactoryInstance();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isCreated = false;

  /**
   * Creates the meta-model objects for the package.  This method is
   * guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void createPackageContents()
  {
    if (isCreated) return;
    isCreated = true;

    // Create classes and their features
    acRootEClass = createEClass(AC_ROOT);
    createEReference(acRootEClass, AC_ROOT__XAVATAX_CONF);
    createEReference(acRootEClass, AC_ROOT__AC_STOREENT);

    x_avatax_confEClass = createEClass(XAVATAX_CONF);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__STOREENT_ID);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__URLTOCONNECT);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__ACCNUM);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__COMPANYCODE);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__TAXCALCULATIONMODE);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__TRANSACTIONLOGGING);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__TRANSLOGKEEPHOURS);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__SUPPORTEDCOUNTRIES);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__TAXCOUNTRIES);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__ADDROUNTRIES);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__BEHAVIORONERROR);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__DEFAULTTAX);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__ADDRVALIDATIONPLACES);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__CUSTOMERVATID);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__PRICECONTAINSTAXES);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__OITAXESDISPLAYED);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__LOGREQUESTTYPES);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__AUTHKEY);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__TAXCODEIDENTIFIER);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__DAPCOUNTRIES);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__DDPCOUNTRIES);
    createEAttribute(x_avatax_confEClass, XAVATAX_CONF__OPTCOUNTER);
    createEReference(x_avatax_confEClass, XAVATAX_CONF__STOREENT_FOR_XAVATAX_CONF);

    acStoreentEClass = createEClass(AC_STOREENT);
    createEReference(acStoreentEClass, AC_STOREENT__XAVATAX_CONF_FOR_STOREENT);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isInitialized = false;

  /**
   * Complete the initialization of the package and its meta-model.  This
   * method is guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void initializePackageContents()
  {
    if (isInitialized) return;
    isInitialized = true;

    // Initialize package
    setName(eNAME);
    setNsPrefix(eNS_PREFIX);
    setNsURI(eNS_URI);

    // Obtain other dependent packages
    InfrastructureEntityPackage theInfrastructureEntityPackage = (InfrastructureEntityPackage)EPackage.Registry.INSTANCE.getEPackage(InfrastructureEntityPackage.eNS_URI);

    // Add supertypes to classes
    acRootEClass.getESuperTypes().add(theInfrastructureEntityPackage.getInfrastructureRoot());
    acStoreentEClass.getESuperTypes().add(theInfrastructureEntityPackage.getStoreent());

    // Initialize classes and features; add operations and parameters
    initEClass(acRootEClass, ACRoot.class, "ACRoot", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getACRoot_X_avatax_conf(), this.getX_avatax_conf(), null, "X_avatax_conf", null, 0, -1, ACRoot.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getACRoot_ACStoreent(), this.getACStoreent(), null, "ACStoreent", null, 0, -1, ACRoot.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(x_avatax_confEClass, X_avatax_conf.class, "X_avatax_conf", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getX_avatax_conf_Storeent_id(), ecorePackage.getEInt(), "storeent_id", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Urltoconnect(), ecorePackage.getEString(), "urltoconnect", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Accnum(), ecorePackage.getEString(), "accnum", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Companycode(), ecorePackage.getEString(), "companycode", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Taxcalculationmode(), ecorePackage.getEString(), "taxcalculationmode", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Transactionlogging(), ecorePackage.getEShort(), "transactionlogging", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Translogkeephours(), ecorePackage.getEIntegerObject(), "translogkeephours", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Supportedcountries(), ecorePackage.getEString(), "supportedcountries", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Taxcountries(), ecorePackage.getEString(), "taxcountries", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Addrountries(), ecorePackage.getEString(), "addrountries", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Behavioronerror(), ecorePackage.getEString(), "behavioronerror", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Defaulttax(), ecorePackage.getEBigDecimal(), "defaulttax", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Addrvalidationplaces(), ecorePackage.getEString(), "addrvalidationplaces", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Customervatid(), ecorePackage.getEShort(), "customervatid", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Pricecontainstaxes(), ecorePackage.getEShort(), "pricecontainstaxes", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Oitaxesdisplayed(), ecorePackage.getEShort(), "oitaxesdisplayed", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Logrequesttypes(), ecorePackage.getEString(), "logrequesttypes", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Authkey(), ecorePackage.getEString(), "authkey", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Taxcodeidentifier(), ecorePackage.getEString(), "taxcodeidentifier", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Dapcountries(), ecorePackage.getEString(), "dapcountries", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Ddpcountries(), ecorePackage.getEString(), "ddpcountries", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getX_avatax_conf_Optcounter(), ecorePackage.getEShort(), "optcounter", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getX_avatax_conf_StoreentForX_avatax_conf(), this.getACStoreent(), this.getACStoreent_X_avatax_confForStoreent(), "StoreentForX_avatax_conf", null, 0, 1, X_avatax_conf.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(acStoreentEClass, ACStoreent.class, "ACStoreent", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getACStoreent_X_avatax_confForStoreent(), this.getX_avatax_conf(), this.getX_avatax_conf_StoreentForX_avatax_conf(), "X_avatax_confForStoreent", null, 0, 1, ACStoreent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    // Create resource
    createResource(eNS_URI);
  }

} //ACEntityPackageImpl
