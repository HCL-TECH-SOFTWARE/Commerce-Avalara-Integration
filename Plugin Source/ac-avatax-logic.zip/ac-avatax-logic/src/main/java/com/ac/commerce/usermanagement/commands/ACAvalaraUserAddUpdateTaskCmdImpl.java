package com.ac.commerce.usermanagement.commands;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import com.ac.avalara.order.bean.ACAvalaraUsersDataBean;
import com.ac.avalara.settings.ACAvalaraConstants;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.command.TaskCommandImpl;
import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.exception.ParameterNotFoundException;
import com.ibm.commerce.user.objects.AddressAccessBean;

@SuppressWarnings("serial")
public class ACAvalaraUserAddUpdateTaskCmdImpl extends TaskCommandImpl implements ACAvalaraUserAddUpdateTaskCmd {

    private static final ACLogger LOGGER = new ACLogger(ACAvalaraUserAddUpdateTaskCmdImpl.class);
    private ACAvalaraSettings settings;

    @Override
    public void performExecute() throws ECException {
        String methodName = "performExecute";
        LOGGER.entering(methodName);

        super.performExecute();

        try {
            if (settings.getCustomerVatIdEnabled()) {
            	updateAvalaraUser();
            }
        } catch (Exception e) {
            LOGGER.error(methodName, "Exception occured in execute()", e);
        }

        LOGGER.exiting(methodName);
    }

    private void updateAvalaraUser() throws NamingException, CreateException, RemoteException, ParameterNotFoundException, FinderException {
        String methodName = "updateAvalaraUser";
        TypedProperty requestProperty = commandContext.getRequestProperties();
        String customerVatId = requestProperty.getString(ACAvalaraConstants.CUSTOMER_VAT_ID, "");
        
        AddressAccessBean aab = new AddressAccessBean().findSelfAddressByMember(getUserId());
        
        ACAvalaraUsersDataBean bean = new ACAvalaraUsersDataBean();
        bean.setCommandContext(getCommandContext());
        bean.setAddressId(aab.getAddressIdInEntityType().toString());
        bean.setCustomerVatId(customerVatId);
        try {
			bean.update();
		} catch (Exception e) {
			LOGGER.error(methodName, "Error occured while processing customer vat ID: " + e.getMessage());
		}
    }

    @Override
	public void setSettings(ACAvalaraSettings settings) {
		this.settings = settings;
	}
    
}
