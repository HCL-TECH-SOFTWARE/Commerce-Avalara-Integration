package com.ac.commerce.tax.commands;

import com.ibm.commerce.order.calculation.InitializeSalesTaxCmd;

public interface ACAvalaraInitializeSalesTaxCmd extends InitializeSalesTaxCmd {
	String defaultCommandClassName = ACAvalaraInitializeSalesTaxCmdImpl.class.getName();

}
