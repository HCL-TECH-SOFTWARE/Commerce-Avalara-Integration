/**
 */
package com.ac.commerce.infrastructure.facade.server.entity.datatypes;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage
 * @generated
 */
public interface ACEntityFactory extends EFactory
{
  /**
   * The singleton instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  ACEntityFactory eINSTANCE = com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACEntityFactoryImpl.init();

  /**
   * Returns a new object of class '<em>AC Root</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>AC Root</em>'.
   * @generated
   */
  ACRoot createACRoot();

  /**
   * Returns a new object of class '<em>Xavatax conf</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Xavatax conf</em>'.
   * @generated
   */
  X_avatax_conf createX_avatax_conf();

  /**
   * Returns a new object of class '<em>AC Storeent</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>AC Storeent</em>'.
   * @generated
   */
  ACStoreent createACStoreent();

  /**
   * Returns the package supported by this factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the package supported by this factory.
   * @generated
   */
  ACEntityPackage getACEntityPackage();

} //ACEntityFactory
