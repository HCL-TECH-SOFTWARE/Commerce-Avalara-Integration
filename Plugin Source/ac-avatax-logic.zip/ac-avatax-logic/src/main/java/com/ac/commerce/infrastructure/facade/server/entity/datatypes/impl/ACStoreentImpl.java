/**
 */
package com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl;

import com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage;
import com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACStoreent;
import com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf;

import com.ibm.commerce.infrastructure.facade.server.entity.datatypes.impl.StoreentImpl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>AC Storeent</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACStoreentImpl#getX_avatax_confForStoreent <em>Xavatax conf For Storeent</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ACStoreentImpl extends StoreentImpl implements ACStoreent
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final long serialVersionUID = 1L;

  /**
   * The cached value of the '{@link #getX_avatax_confForStoreent() <em>Xavatax conf For Storeent</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getX_avatax_confForStoreent()
   * @generated
   * @ordered
   */
  protected X_avatax_conf x_avatax_confForStoreent;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final int EOFFSET_CORRECTION = ACEntityPackage.Literals.AC_STOREENT.getFeatureID(ACEntityPackage.Literals.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT) - ACEntityPackage.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ACStoreentImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass()
  {
    return ACEntityPackage.Literals.AC_STOREENT;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public X_avatax_conf getX_avatax_confForStoreent()
  {
    return x_avatax_confForStoreent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetX_avatax_confForStoreent(X_avatax_conf newX_avatax_confForStoreent, NotificationChain msgs)
  {
    X_avatax_conf oldX_avatax_confForStoreent = x_avatax_confForStoreent;
    x_avatax_confForStoreent = newX_avatax_confForStoreent;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ACEntityPackage.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT + EOFFSET_CORRECTION, oldX_avatax_confForStoreent, newX_avatax_confForStoreent);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setX_avatax_confForStoreent(X_avatax_conf newX_avatax_confForStoreent)
  {
    if (newX_avatax_confForStoreent != x_avatax_confForStoreent)
    {
      NotificationChain msgs = null;
      if (x_avatax_confForStoreent != null)
        msgs = ((InternalEObject)x_avatax_confForStoreent).eInverseRemove(this, ACEntityPackage.XAVATAX_CONF__STOREENT_FOR_XAVATAX_CONF, X_avatax_conf.class, msgs);
      if (newX_avatax_confForStoreent != null)
        msgs = ((InternalEObject)newX_avatax_confForStoreent).eInverseAdd(this, ACEntityPackage.XAVATAX_CONF__STOREENT_FOR_XAVATAX_CONF, X_avatax_conf.class, msgs);
      msgs = basicSetX_avatax_confForStoreent(newX_avatax_confForStoreent, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ACEntityPackage.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT + EOFFSET_CORRECTION, newX_avatax_confForStoreent, newX_avatax_confForStoreent));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID - EOFFSET_CORRECTION)
    {
      case ACEntityPackage.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT:
        if (x_avatax_confForStoreent != null)
          msgs = ((InternalEObject)x_avatax_confForStoreent).eInverseRemove(this, ACEntityPackage.XAVATAX_CONF__STOREENT_FOR_XAVATAX_CONF, X_avatax_conf.class, msgs);
        return basicSetX_avatax_confForStoreent((X_avatax_conf)otherEnd, msgs);
    }
    return super.eInverseAdd(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID - EOFFSET_CORRECTION)
    {
      case ACEntityPackage.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT:
        return basicSetX_avatax_confForStoreent(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID - EOFFSET_CORRECTION)
    {
      case ACEntityPackage.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT:
        return getX_avatax_confForStoreent();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID - EOFFSET_CORRECTION)
    {
      case ACEntityPackage.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT:
        setX_avatax_confForStoreent((X_avatax_conf)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(int featureID)
  {
    switch (featureID - EOFFSET_CORRECTION)
    {
      case ACEntityPackage.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT:
        setX_avatax_confForStoreent((X_avatax_conf)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(int featureID)
  {
    switch (featureID - EOFFSET_CORRECTION)
    {
      case ACEntityPackage.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT:
        return x_avatax_confForStoreent != null;
    }
    return super.eIsSet(featureID);
  }


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int eDerivedStructuralFeatureID(int baseFeatureID, Class baseClass)
  {
    if (baseClass == ACStoreent.class)
    {
      switch (baseFeatureID - EOFFSET_CORRECTION)
      {
        case ACEntityPackage.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT: return ACEntityPackage.AC_STOREENT__XAVATAX_CONF_FOR_STOREENT + EOFFSET_CORRECTION;
        default: return -1;
      }
    }
    return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
  }

} //ACStoreentImpl
