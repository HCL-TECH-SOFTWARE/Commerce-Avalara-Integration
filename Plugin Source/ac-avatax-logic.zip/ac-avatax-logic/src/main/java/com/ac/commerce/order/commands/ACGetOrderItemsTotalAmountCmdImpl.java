package com.ac.commerce.order.commands;

import java.math.BigDecimal;
import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.exception.ECSystemException;
import com.ibm.commerce.order.objects.OrderItemAccessBean;
import com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmd;
import com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmdImpl;
import com.ibm.commerce.ras.ECMessage;
import com.ibm.commerce.ras.ECTrace;

public class ACGetOrderItemsTotalAmountCmdImpl extends
		GetOrderItemsTotalAmountCmdImpl implements GetOrderItemsTotalAmountCmd {
	private OrderItemAccessBean iabOrderItems[];
	private BigDecimal idTotalAmount;

	public ACGetOrderItemsTotalAmountCmdImpl() {
		iabOrderItems = null;

		idTotalAmount = new BigDecimal(0);
	}

	public void performExecute() throws ECException {
		String strMethod = "performExecute";
		if (ECTrace.traceEnabled(3L))
			ECTrace.entry(
					3L,
					"com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmdImpl",
					"performExecute");

		try {
			if (iabOrderItems != null && iabOrderItems.length > 0) {
				for (int i = 0; i < iabOrderItems.length; i++)
					if (iabOrderItems[i] != null) {
						if (ECTrace.traceEnabled(3L)) {
							ECTrace.trace(
									3L,
									"com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmdImpl",
									"performExecute",
									(new StringBuilder("order item id: "))
											.append(iabOrderItems[i]
													.getOrderItemIdInEntityType())
											.toString());

							ECTrace.trace(
									3L,
									"com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmdImpl",
									"performExecute",
									(new StringBuilder("Product total = "))
											.append(iabOrderItems[i]
													.getTotalProductInEntityType())
											.toString());

							ECTrace.trace(
									3L,
									"com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmdImpl",
									"performExecute",
									(new StringBuilder("Shipping total = "))
											.append(iabOrderItems[i]
													.getShippingChargeInEntityType())
											.toString());

							ECTrace.trace(
									3L,
									"com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmdImpl",
									"performExecute",
									(new StringBuilder("Total tax = ")).append(
											iabOrderItems[i]
													.getTaxAmountInEntityType())
											.toString());

							ECTrace.trace(
									3L,
									"com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmdImpl",
									"performExecute",
									(new StringBuilder("Adjustment total = "))
											.append(iabOrderItems[i]
													.getTotalAdjustmentInEntityType())
											.toString());

							ECTrace.trace(
									3L,
									"com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmdImpl",
									"performExecute",
									(new StringBuilder("Shipping tax total = "))
											.append(iabOrderItems[i]
													.getShippingTaxAmountInEntityType())
											.toString());

						}

						ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
						bean.setCommandContext(commandContext);
						bean.populate();
						ACAvalaraSettings settings = ACAvalaraSettingsUtils
								.loadAvalaraGeneralSettings(bean);

						if (iabOrderItems[i].getTotalProductInEntityType() != null)
							idTotalAmount = idTotalAmount.add(iabOrderItems[i]
									.getTotalProductInEntityType());

						if (iabOrderItems[i].getShippingChargeInEntityType() != null)
							idTotalAmount = idTotalAmount.add(iabOrderItems[i]
									.getShippingChargeInEntityType());

						if (!settings.getTaxIncluded()) {
							if (iabOrderItems[i].getTaxAmountInEntityType() != null)
								idTotalAmount = idTotalAmount
										.add(iabOrderItems[i]
												.getTaxAmountInEntityType());

							if (iabOrderItems[i]
									.getShippingTaxAmountInEntityType() != null)
								idTotalAmount = idTotalAmount
										.add(iabOrderItems[i]
												.getShippingTaxAmountInEntityType());
						}

						if (iabOrderItems[i].getTotalAdjustmentInEntityType() != null)
							idTotalAmount = idTotalAmount.add(iabOrderItems[i]
									.getTotalAdjustmentInEntityType());

					}

				ECTrace.trace(
						3L,
						"com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmdImpl",
						"performExecute",
						(new StringBuilder("idTotalAmount = ")).append(
								idTotalAmount).toString());
			}
		} catch (CreateException e) {
			throw new ECSystemException(
					ECMessage._ERR_CREATE_EXCEPTION,
					"com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmdImpl",
					"performExecute", new Object[] { e.toString() }, e);
		} catch (FinderException e) {
			throw new ECSystemException(
					ECMessage._ERR_FINDER_EXCEPTION,
					"com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmdImpl",
					"performExecute", new Object[] { e.toString() }, e);
		} catch (NamingException e) {
			throw new ECSystemException(
					ECMessage._ERR_NAMING_EXCEPTION,
					"com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmdImpl",
					"performExecute", new Object[] { e.toString() }, e);
		} catch (RemoteException e) {
			throw new ECSystemException(
					ECMessage._ERR_REMOTE_EXCEPTION,
					"com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmdImpl",
					"performExecute", new Object[] { e.toString() }, e);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (ECTrace.traceEnabled(3L))
			ECTrace.exit(
					3L,
					"com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmdImpl",
					"performExecute");/* 131 */
		ECTrace.exit(
				3L,
				"com.ibm.commerce.orderitems.commands.GetOrderItemsTotalAmountCmdImpl",
				"performExecute");
	}

	public void reset() {
		super.reset();
		iabOrderItems = null;
		idTotalAmount = new BigDecimal(0);
	}

	public OrderItemAccessBean[] getOrderItems() {
		return iabOrderItems;
	}

	public BigDecimal getTotalAmount() {
		return idTotalAmount;
	}

	public void setOrderItems(OrderItemAccessBean abOrderItems[]) {
		iabOrderItems = abOrderItems;
	}
}
