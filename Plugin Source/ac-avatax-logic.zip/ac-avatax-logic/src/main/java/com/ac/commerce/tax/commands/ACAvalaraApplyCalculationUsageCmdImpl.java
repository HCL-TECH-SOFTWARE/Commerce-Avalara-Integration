package com.ac.commerce.tax.commands;

import java.math.BigDecimal;

import com.ac.commerce.order.commands.ACAvalaraCreateAdjustSalesDocumentTaskCmd;
import com.ac.commerce.util.CommandFactory;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.beans.DataBeanManager;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.exception.ECSystemException;
import com.ibm.commerce.order.beans.OrderItemDataBean;
import com.ibm.commerce.order.calculation.ApplyCalculationUsageCmdImpl;
import com.ibm.commerce.order.calculation.Item;
import com.ibm.commerce.order.objects.OrderItemAccessBean;
import com.ibm.commerce.ras.ECMessage;
import com.ibm.commerce.ras.ECMessageHelper;


@SuppressWarnings("serial")
public class ACAvalaraApplyCalculationUsageCmdImpl extends ApplyCalculationUsageCmdImpl implements ACAvalaraApplyCalculationUsageCmd {

    private static final String CLASSNAME = ACAvalaraApplyCalculationUsageCmdImpl.class.getName();
    private static final ACLogger LOGGER = new ACLogger(ACAvalaraApplyCalculationUsageCmdImpl.class);

    @Override
    public void performExecute() throws ECException {
        String methodName = "performExecute";
        LOGGER.entering(methodName);
        try {
            LOGGER.trace(methodName, "getUsageId()={0}",getUsageId());
            Item[] items = getItems();
            if (items != null && items.length >0 && items[0].getOrderItem() != null) {            	
                LOGGER.trace(methodName, "Calling Avalara API for Tax calculation");
                ACAvalaraCreateAdjustSalesDocumentTaskCmd task = null;
                task = CommandFactory.createTask(ACAvalaraCreateAdjustSalesDocumentTaskCmd.class, getCommandContext());                
                task.setItems(items);
                task.execute();
                
            } 
        } catch (ECApplicationException e) {
            throw e;
        } catch (Exception e) {
            throw new ECSystemException(ECMessage._ERR_GENERIC, CLASSNAME, methodName, ECMessageHelper.generateMsgParms(e.getMessage()), e);
        }

        for(Item item : getItems()) {
        	
        	OrderItemAccessBean orderItem = item.getOrderItem();
			if (null != orderItem) {
				BigDecimal shippingTaxOld = null;
				BigDecimal salesTaxOld = null;
				try {
					shippingTaxOld = orderItem.getShippingTaxAmountInEntityType();
					salesTaxOld = orderItem.getTaxAmountInEntityType();
				} catch (Exception e) {
					LOGGER.error(methodName, e);
					throw new ECSystemException(ECMessage._ERR_GENERIC, CLASSNAME, methodName, ECMessageHelper.generateMsgParms(e.getMessage()), e);
				}
				BigDecimal shippingTax = item.getShippingTaxTotal();
				BigDecimal salesTax = item.getSalesTaxTotal();
				shippingTaxOld = null == shippingTaxOld ? BigDecimal.ZERO : shippingTaxOld;
				salesTaxOld = null == salesTaxOld ? BigDecimal.ZERO : salesTaxOld;
				shippingTax = null == shippingTax ? BigDecimal.ZERO : shippingTax;
				salesTax = null == salesTax ? BigDecimal.ZERO : salesTax;

				shippingTax = shippingTaxOld.add(shippingTax);
				salesTax = salesTaxOld.add(salesTax);
				orderItem.setShippingTaxAmount(shippingTax);
				orderItem.setTaxAmount(salesTax);
				// Francis Booth, April 28th, 2020
				// removed the commitCopyHelper because the JPA sessionBean managed the commit on its own
				//  https://help.hcltechsw.com/commerce/9.0.0/developer/tasks/tsdupdatewithaccessbeans.html
				
//				try { 
//				
////					orderItem.commitCopyHelper();
//					
//					
//				} catch (Exception e) {
//					LOGGER.error(methodName, e);
//					throw new ECSystemException(ECMessage._ERR_GENERIC, CLASSNAME, methodName, ECMessageHelper.generateMsgParms(e.getMessage()), e);
//				}
			}
			
        }
        LOGGER.exiting(methodName);
    }
}
