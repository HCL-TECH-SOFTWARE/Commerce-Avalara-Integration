package com.ac.commerce.member.facade.client;

import java.util.Map;

import com.ac.avalara.order.bean.ACAvalaraUsersDataBean;
import com.ac.avalara.settings.ACAvalaraConstants;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.member.facade.client.MemberFacadeClient;
import com.ibm.commerce.member.facade.client.PersonException;

public class ACMemberFacadeClient extends MemberFacadeClient {

	private static final ACLogger LOGGER = new ACLogger(ACAvalaraUsersDataBean.class);
	private static final String ADDRESS_TYPE_SHIPPING = "Shipping";
	private static final String ADDRESS_TYPE_SHIPPING_BILLING = "ShippingAndBilling";
	
	@Override
	public Map addAddressForPerson(Map parameters) throws PersonException {
		Map res = super.addAddressForPerson(parameters);
		String[] addressType = (String[]) parameters.get("addressType");
		if (addressType != null && addressType.length > 0){
			if (ADDRESS_TYPE_SHIPPING.equals(addressType[0]) || ADDRESS_TYPE_SHIPPING_BILLING.equals(addressType[0])){
				saveCustomerVatId(parameters, res);
			}
		}
		
		return res;
	}

	private void saveCustomerVatId(Map parameters, Map res) {
		String METHOD_NAME="saveCustomerVatId(Map parameters, Map res)";
		String[] value = (String[]) parameters.get(ACAvalaraConstants.CUSTOMER_VAT_ID);
		String[] addressId = (String[]) res.get("addressId");
		if (addressId != null && value != null){
			ACAvalaraUsersDataBean bean = new ACAvalaraUsersDataBean();
			bean.setAddressId(addressId[0].toString());
			bean.setCustomerVatId(value[0].toString());
			try {
				bean.update();
			} catch (Exception e) {
				LOGGER.error(METHOD_NAME, "Exception occured while saving customer Vat ID " + e.getMessage());
			}
		}
	}

	@Override
	public Map updateAddressForPerson(Map parameters) throws PersonException {
		Map res = super.updateAddressForPerson(parameters);
		
		saveCustomerVatId(parameters, res);	
		return res;
	}
	
	
}
