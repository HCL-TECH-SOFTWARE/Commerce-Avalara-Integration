package com.ac.commerce.usermanagement.commands;

public interface ACAvalaraTestConnectionCmd {

    String defaultCommandClassName = ACAvalaraTestConnectionCmdImpl.class.getName();
}
