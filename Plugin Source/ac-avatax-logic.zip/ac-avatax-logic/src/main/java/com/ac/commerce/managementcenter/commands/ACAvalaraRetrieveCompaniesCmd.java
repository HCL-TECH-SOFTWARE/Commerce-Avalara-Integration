package com.ac.commerce.managementcenter.commands;

public interface ACAvalaraRetrieveCompaniesCmd {
	String defaultCommandClassName = ACAvalaraRetrieveCompaniesCmdImpl.class.getName();
}
