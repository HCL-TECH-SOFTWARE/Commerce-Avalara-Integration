package com.ac.avalara.utility;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import net.avalara.avatax.rest.client.AvaTaxClient;
import net.avalara.avatax.rest.client.enums.DocumentType;
import net.avalara.avatax.rest.client.enums.TaxOverrideTypeId;
import net.avalara.avatax.rest.client.enums.VoidReasonCode;
import net.avalara.avatax.rest.client.models.AddressLocationInfo;
import net.avalara.avatax.rest.client.models.AddressesModel;
import net.avalara.avatax.rest.client.models.CommitTransactionModel;
import net.avalara.avatax.rest.client.models.CreateOrAdjustTransactionModel;
import net.avalara.avatax.rest.client.models.CreateTransactionModel;
import net.avalara.avatax.rest.client.models.LineItemModel;
import net.avalara.avatax.rest.client.models.TaxOverrideModel;
import net.avalara.avatax.rest.client.models.TransactionLineDetailModel;
import net.avalara.avatax.rest.client.models.TransactionLineModel;
import net.avalara.avatax.rest.client.models.TransactionModel;
import net.avalara.avatax.rest.client.models.VoidTransactionModel;

import org.apache.commons.lang3.StringUtils;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.order.bean.ACAvalaraShipModeDetails;
import com.ac.avalara.order.bean.ACAvalaraShipModeDetailsDataBean;
import com.ac.avalara.order.bean.ACAvalaraTaxDetails;
import com.ac.avalara.order.bean.ACAvalaraTaxDetailsDataBean;
import com.ac.avalara.order.bean.ACAvalaraTaxDetailsType;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ac.avatax.exception.AvalaraException;
import com.ac.avatax.rest.logger.AvalaraLogger;
import com.ac.avatax.rest.logger.AvalaraLoggerSettings;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.command.CommandContext;
import com.ibm.commerce.order.calculation.Item;
import com.ibm.commerce.order.objects.OrderAccessBean;
import com.ibm.commerce.order.objects.OrderItemAccessBean;
import com.ibm.commerce.ordermanagement.objects.RMAItemAccessBean;
import com.ibm.commerce.price.utils.MonetaryAmount;
import com.ibm.commerce.ras.ECMessageHelper;

/**
 * Utility class is used for Tax Calculation via AVALARA API.
 * 
 * @author askosyr
 */
public final class ACAvalaraTaxUtils {

	private static final String CALCULATION_DATE_FORMAT = "yyyy-MM-dd";
	private static final String CLASSNAME = ACAvalaraTaxUtils.class.getName();
	private static final AvalaraLogger AVA_LOGGER = new AvalaraLogger();
	private static final ACLogger LOGGER = new ACLogger(ACAvalaraTaxUtils.class);
	

	public static void commitTransaction(String orderId, CommandContext commandContext, ACAvalaraSettings settings, AvalaraLoggerSettings loggerSettings) throws AvalaraException {
		String methodName = "commitTransaction";
		LOGGER.entering(methodName);
		AvaTaxClient client = ACAvalaraUtils.getAvaTaxClient(settings);
		CommitTransactionModel model = new CommitTransactionModel();
		model.setCommit(Boolean.TRUE);

		if (loggerSettings.isLogEnabled() && loggerSettings.isLogCalculateRequest()) {
			AVA_LOGGER.init(loggerSettings);
			StringBuilder msg = new StringBuilder("Requesting Commit of document on Avalara[").append(settings.getUrl()).append("]: for documentId:").append(orderId).append(". Request: ").append(model);
			AVA_LOGGER.log(msg.toString());
		}

		try {
			TransactionModel response = client.commitTransaction(settings.getCompanyId(), orderId, model);
			if (loggerSettings.isLogEnabled() && loggerSettings.isLogCalculateRequest()) {
				StringBuilder msg = new StringBuilder("Response for commit document on Avalara[").append(settings.getUrl()).append("]: for documentId:").append(orderId).append(". ").append(response);
				AVA_LOGGER.log(msg.toString());
			}
		} catch (AvalaraException e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw (e);
		} catch (Exception e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw new AvalaraException("Exception occured while getting taxes from Avalara", e);
		}
		LOGGER.exiting(methodName);
	}

	public static void createOrAdjustSaleCalculateOnly(Item[] items, CommandContext commandContext, ACAvalaraSettings settings, AvalaraLoggerSettings loggerSettings) throws AvalaraException {
		String methodName = "recordTax";
		LOGGER.entering(methodName);
		try {
			
			sendTaxTransactionDocument(DocumentType.SalesOrder, items, commandContext, settings, loggerSettings);
		} catch (AvalaraException e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw (e);
		} catch (Exception e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw new AvalaraException("Exception occured while getting taxes from Avalara", e);
		}
		LOGGER.exiting(methodName);

	}	
	

	public static void createOrAdjustSaleAndSubmit(Item[] items, CommandContext commandContext, ACAvalaraSettings settings, AvalaraLoggerSettings loggerSettings) throws AvalaraException {
		String methodName = "recordTax";
		LOGGER.entering(methodName);
		try {
			
			sendTaxTransactionDocument(DocumentType.SalesInvoice, items, commandContext, settings, loggerSettings);
		} catch (AvalaraException e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw (e);
		} catch (Exception e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw new AvalaraException("Exception occured while getting taxes from Avalara", e);
		}
		LOGGER.exiting(methodName);

	}

	public static void sendTaxTransactionDocument(DocumentType documentType, Item[] items, CommandContext commandContext, ACAvalaraSettings settings, AvalaraLoggerSettings loggerSettings) throws Exception {
		String methodName = "sendTaxTransactionDocument";
		LOGGER.entering(methodName);

		if (ACAvalaraUtils.isNoAddressesInItems(items)) {
			LOGGER.warn(methodName, "There is no address information in some of items {0}", new Object[] { items });
			return;
		}

		AvaTaxClient client = ACAvalaraUtils.getAvaTaxClient(settings);

		try {
			Integer fulfillmentCenterId = items[0].getFulfillmentCenterId();
			Integer storeId = items[0].getStoreEntityId();
			
			AddressLocationInfo shipFromAddress = ACAvalaraModelHelper.getShipFromAddress(fulfillmentCenterId, storeId, commandContext);
			if (!StringUtils.contains(settings.getTaxCountries(), shipFromAddress.getCountry())) {
				LOGGER.info(methodName, "{0} is not present in list of countries for which calculation is enabled", new Object[] { shipFromAddress.getCountry() });
				return;
			}
			
			OrderAccessBean orderBean = items[0].getOrderItem().getOrder();
			String orderId = orderBean.getOrderId();
			String currency = orderBean.getCurrency();
			String companyId = settings.getCompanyId();
			String customerCode = orderBean.getMemberId();
			
			
			
						

			LandedCostType landedCostType = LandedCostType.NONE;

			String dapCountries = settings.getDapCountries();
			String ddpCountries = settings.getDdpCountries();
			AddressLocationInfo shipToAddressLandedCost;
			ACAvalaraShipModeDetails shipModeDetailsLandedCost;

			if (ACAvalaraUtils.isShippingToCountriesWithEnbaledLandedCost(items, dapCountries, ddpCountries, commandContext)) {

				shipToAddressLandedCost = ACAvalaraModelHelper.getShipToAddressForLandedCost(items, dapCountries, ddpCountries, commandContext);
				String toCountry = null;
				if (null != shipToAddressLandedCost) {

					toCountry = shipToAddressLandedCost.getCountry();
					if (null != dapCountries && dapCountries.contains(toCountry)) {
						landedCostType = LandedCostType.DAP;
					} else if (null != ddpCountries && ddpCountries.contains(toCountry)) {
						landedCostType = LandedCostType.DDP;
					}
				}

				ACAvalaraShipModeDetailsDataBean shipModeDetailsBean = new ACAvalaraShipModeDetailsDataBean();
				shipModeDetailsBean.setCommandContext(commandContext);
				shipModeDetailsBean.setShipModeId(items[0].getShippingModeId());
				shipModeDetailsBean.populate();
				shipModeDetailsLandedCost = shipModeDetailsBean.getDetails();

			} else {
				shipToAddressLandedCost = null;
				shipModeDetailsLandedCost = null;
			}

			List<LineItemModel> lines = ACAvalaraModelHelper.getLineItemInfoForGetTax(items, settings, commandContext);
			LineItemModel insurance = ACAvalaraModelHelper.getLineItemInfoForInsurance(orderBean.getOrderIdInEntityType());
			if(  null != insurance) {
				lines.add(insurance);
			}
			
			String customerUsageType = ACAvalaraUtils.getCustomerUsageType(commandContext);

			CreateTransactionModel model = ACAvalaraModelHelper.getCreateTransactionModel(documentType, orderId, currency, companyId, customerCode, shipFromAddress, shipToAddressLandedCost, lines, customerUsageType, dapCountries, ddpCountries, landedCostType,
					shipModeDetailsLandedCost);

			if (loggerSettings.isLogEnabled() && loggerSettings.isLogCalculateRequest()) {
				AVA_LOGGER.init(loggerSettings);
				StringBuilder msg = new StringBuilder(documentType.name()).append(" document request on Avalara[").append(settings.getUrl()).append("] with data: ").append(model);
				AVA_LOGGER.log(msg.toString());
			}

			TransactionModel response = client.createTransaction("", model);

			if (loggerSettings.isLogEnabled() && loggerSettings.isLogCalculateRequest()) {
				StringBuilder msg = new StringBuilder(documentType.name()).append(" document response from Avalara[").append(settings.getUrl()).append("]: ").append(response);
				AVA_LOGGER.log(msg.toString());
			}

			if (response != null) {
				updateTaxDetails(response, items);
			} else {
				String msg = "Unexpected error with " + documentType.name() + " document: response is null";
				LOGGER.error(methodName, msg);
				if (loggerSettings.isLogEnabled() && loggerSettings.isLogCalculateRequest()) {
					AVA_LOGGER.log(msg);
				}
				throw new AvalaraException(msg);
			}

		} catch (AvalaraException e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw (e);
		} catch (Exception e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw new AvalaraException("Exception occured with " + documentType.name() + " avalara tax document", e);
		}
		LOGGER.exiting(methodName);
	}

	public static void cancelTax(String transactionCode, String comment, CommandContext commandContext) throws AvalaraException {
		String methodName = "getTax";
		LOGGER.entering(methodName);

		String orderId = null;
		String currency = null;
		try {
			ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
			bean.setCommandContext(commandContext);
			bean.populate();

			ACAvalaraSettings settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);
			AvalaraLoggerSettings loggerSettings = ACAvalaraSettingsUtils.loadAvalaraLoggerSettings(bean);

			if (settings.isTaxSubmissionEnabled()) {

				AvaTaxClient client = ACAvalaraUtils.getAvaTaxClient(settings);
				VoidTransactionModel model = new VoidTransactionModel();

				model.setCode(VoidReasonCode.DocVoided);

				if (loggerSettings.isLogEnabled() && loggerSettings.isLogCancelRequest()) {
					AVA_LOGGER.init(loggerSettings);
					StringBuilder msg = new StringBuilder("Void document request on Avalara[").append(settings.getUrl()).append("] with data: ").append(model);
					AVA_LOGGER.log(msg.toString());
				}
				TransactionModel response = client.voidTransaction(settings.getCompanyId(), transactionCode, model);

				if (loggerSettings.isLogEnabled() && loggerSettings.isLogCancelRequest()) {
					StringBuilder msg = new StringBuilder("Void document response on Avalara[").append(settings.getUrl()).append("] : ").append(response);
					AVA_LOGGER.log(msg.toString());
				}

				// TODO response processing
				LOGGER.trace("Cancelling ava transaction {0}. Response: {1}", transactionCode, response);

			}
		} catch (AvalaraException e) {
			LOGGER.error(methodName, e.getMessage());
			throw e;
		} catch (Exception e) {
			LOGGER.error(methodName, e.getMessage());
			throw new AvalaraException("Exception occured while cancelling taxes from Avalara", e);
		}
	}

	public static void updateTaxDetails(TransactionModel response, Item[] items) throws Exception {
		String methodName = "updateTaxDetails";
		LOGGER.entering(methodName);

		Map<String, BigDecimal> itemTaxes = new HashMap<String, BigDecimal>();
		Map<String, BigDecimal> shipTaxes = new HashMap<String, BigDecimal>();
		Map<String, TransactionLineModel> lines = new HashMap<String, TransactionLineModel>();
		Map<String, TransactionLineModel> shipLines = new HashMap<String, TransactionLineModel>();
		List<TransactionLineModel> importDuties = new ArrayList<TransactionLineModel>();
		List<TransactionLineModel> importFees = new ArrayList<TransactionLineModel>();

		// setting tax details in DB
		for (TransactionLineModel line : response.getLines()) {
			if ("ImportDuties".equals(line.getLineNumber())) {
				importDuties.add(line);
			} else if ("ImportFees".equals(line.getLineNumber())) {
				importFees.add(line);
			} else if (line.getLineNumber().startsWith("FR")) {
				// shipping tax
				shipTaxes.put(StringUtils.replace(line.getLineNumber(), "FR", ""), line.getTax());
				shipLines.put(StringUtils.replace(line.getLineNumber(), "FR", ""), line);
			} else {
				// item tax
				itemTaxes.put(line.getLineNumber(), line.getTax());
				lines.put(line.getLineNumber(), line);
			}
		}

		for (Item item : items) {
			Long id = item.getOrderItemId();
			String itemId = String.valueOf(id);
			Long orderId = item.getOrderItem().getOrderIdInEntityType();
			
			BigDecimal shippngTaxTotal = null == item.getShippingTaxTotal() ? BigDecimal.ZERO : item.getShippingTaxTotal();
			BigDecimal salesTaxTotal = null == item.getSalesTaxTotal() ? BigDecimal.ZERO : item.getSalesTaxTotal();
			shippngTaxTotal = shippngTaxTotal.add(null == shipTaxes.get(itemId) ? BigDecimal.ZERO : shipTaxes.get(itemId));
			salesTaxTotal = salesTaxTotal.add(null == itemTaxes.get(itemId) ? BigDecimal.ZERO : itemTaxes.get(itemId));
			
			item.setShippingTaxTotal(shippngTaxTotal);
			item.setSalesTaxTotal(salesTaxTotal);
			
			
			TransactionLineModel line = lines.get(itemId);
			if (null != line) {
				ACAvalaraTaxDetailsDataBean detailsDataBean = new ACAvalaraTaxDetailsDataBean();
				detailsDataBean.setOrderId(orderId);
				detailsDataBean.setOrderItemId(id);
				List<ACAvalaraTaxDetails> details = new ArrayList<ACAvalaraTaxDetails>();

				for (TransactionLineDetailModel detailLine : line.getDetails()) {
					ACAvalaraTaxDetails detail = new ACAvalaraTaxDetails();
					detail.setOrderId(orderId);
					detail.setOrderItemId(id);
					detail.setRate(String.valueOf(detailLine.getRate()));
					detail.setExcemption(String.valueOf(detailLine.getExemptAmount()));
					detail.setNontaxable(String.valueOf(detailLine.getNonTaxableAmount()));
					detail.setTax(String.valueOf(detailLine.getTax()));
					detail.setTaxable(String.valueOf(detailLine.getTaxableAmount()));
					detail.setTaxname(detailLine.getTaxName());
					detail.setTaxtype(null != detailLine.getTaxType() ? detailLine.getTaxType().name() : null);
					detail.setType(ACAvalaraTaxDetailsType.LN);
					details.add(detail);
				}

				TransactionLineModel shipLine = shipLines.get(id);
				if (null != shipLine) {
					for (TransactionLineDetailModel detailLine : shipLine.getDetails()) {
						ACAvalaraTaxDetails detail = new ACAvalaraTaxDetails();
						detail.setOrderId(orderId);
						detail.setOrderItemId(id);
						detail.setRate(String.valueOf(detailLine.getRate()));
						detail.setExcemption(String.valueOf(detailLine.getExemptAmount()));
						detail.setNontaxable(String.valueOf(detailLine.getNonTaxableAmount()));
						detail.setTax(String.valueOf(detailLine.getTax()));
						detail.setTaxable(String.valueOf(detailLine.getTaxableAmount()));
						detail.setTaxname(detailLine.getTaxName());
						detail.setTaxtype(null != detailLine.getTaxType() ? detailLine.getTaxType().name() : null);
						detail.setType(ACAvalaraTaxDetailsType.SHP);
						details.add(detail);
					}
					shipLines.remove(String.valueOf(id));
				}

				detailsDataBean.setDetails(details);
				detailsDataBean.update();

			}

			ACAvalaraTaxDetailsDataBean orderTaxDetailsDataBean = new ACAvalaraTaxDetailsDataBean();
			orderTaxDetailsDataBean.setOrderId(orderId);
			List<ACAvalaraTaxDetails> details = new ArrayList<ACAvalaraTaxDetails>();

			if (!importDuties.isEmpty()) {
				TransactionLineModel detailLine = importDuties.get(0);
				ACAvalaraTaxDetails detail = new ACAvalaraTaxDetails();
				detail.setOrderId(orderId);
				detail.setTax(String.valueOf(detailLine.getTax()));
				detail.setType(ACAvalaraTaxDetailsType.CD);
				details.add(detail);
			}
			if (!importFees.isEmpty()) {
				TransactionLineModel detailLine = importFees.get(0);
				ACAvalaraTaxDetails detail = new ACAvalaraTaxDetails();
				detail.setOrderId(orderId);
				detail.setTax(String.valueOf(detailLine.getTax()));
				detail.setType(ACAvalaraTaxDetailsType.CF);
				details.add(detail);
			}

			if (!StringUtils.isEmpty(response.getDescription())) {
				ACAvalaraTaxDetails detail = new ACAvalaraTaxDetails();
				detail.setOrderId(orderId);
				detail.setTaxname(response.getDescription());
				detail.setType(ACAvalaraTaxDetailsType.DAP);
				details.add(detail);
			}
			orderTaxDetailsDataBean.setDetails(details);
			orderTaxDetailsDataBean.update();

			shipTaxes.remove(String.valueOf(id));
			itemTaxes.remove(String.valueOf(id));
			lines.remove(String.valueOf(id));
		}

		if (shipTaxes.size() > 0 || itemTaxes.size() > 0) {
			LOGGER.warn(methodName, "Not all taxes was consumed. Ship tax left: {0}, Item tax left {1}. Avalara Response: {2}", shipTaxes.size(), itemTaxes.size(), response);
		}

		LOGGER.exiting(methodName);
	}

	public static void recordReturnTax(Vector<RMAItemAccessBean> rmaItems, CommandContext commandContext, String returnId, String orderId) throws AvalaraException {
		String methodName = "recordReturnTax";
		LOGGER.entering(methodName);

		try {
			ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
			bean.setCommandContext(commandContext);
			bean.populate();

			ACAvalaraSettings settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);
			AvalaraLoggerSettings loggerSettings = ACAvalaraSettingsUtils.loadAvalaraLoggerSettings(bean);

			sendReturnTransactionDocument(DocumentType.ReturnInvoice, settings, loggerSettings, rmaItems, commandContext, returnId, orderId);
		} catch (AvalaraException e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw (e);
		} catch (Exception e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw new AvalaraException("Exception occured while getting taxes from Avalara", e);
		}

		LOGGER.exiting(methodName);
	}

	public static TransactionModel sendReturnTransactionDocument(DocumentType documentType, ACAvalaraSettings settings, AvalaraLoggerSettings loggerSettings, Vector<RMAItemAccessBean> rmaItems, CommandContext commandContext,
			String returnId, String orderId) throws AvalaraException {
		String methodName = "sendReturnTransactionDocument";
		String currency = null;
		TransactionModel retval = null;
		LOGGER.entering(methodName);
		try {
			// Calculate Sales Tax

			// Setting docType depending on Order Status
			OrderAccessBean orderBean = new OrderAccessBean();
			orderBean.setInitKey_orderId(orderId);
//			orderBean.instantiateEntity();

			OrderItemAccessBean oab = new OrderItemAccessBean();
			oab.setInitKey_orderItemId(rmaItems.get(0).getOrderItemsId());
//			oab.instantiateEntity();

			AddressLocationInfo shipFromAddress = ACAvalaraModelHelper.getShipFromAddress(oab.getFulfillmentCenterId().toString(), oab.getStoreId(), commandContext);

			if (settings.getTaxCountries().contains(shipFromAddress.getCountry())) {

				currency = rmaItems.get(0).getCurrency();

				AvaTaxClient client = ACAvalaraUtils.getAvaTaxClient(settings);

				List<LineItemModel> lines = ACAvalaraModelHelper.getLineItemInfoForReturnTax(rmaItems, settings, commandContext);
				String customerUsageType = ACAvalaraUtils.getCustomerUsageType(commandContext);
				AddressesModel addressModel = new AddressesModel();
				addressModel.setShipFrom(shipFromAddress);
				ArrayList<LineItemModel> linesArrayList = new ArrayList<LineItemModel>();
				linesArrayList.addAll(lines);
				TaxOverrideModel taxOverrideModel = ACAvalaraModelHelper.getReturnTaxOverrideDocLevel(oab.getOrderIdInEntityType(), commandContext, new Date(orderBean.getPlaceOrderTimeInEntityType().getTime()));

				CreateTransactionModel model = ACAvalaraModelHelper.getReturnModel(documentType, lines, customerUsageType, addressModel, rmaItems.get(0).getRmaId(), settings.getCompanyId(), taxOverrideModel, currency, orderBean.getMemberId(), linesArrayList,
						orderId);

				CreateOrAdjustTransactionModel m = new CreateOrAdjustTransactionModel();
				m.setCreateTransactionModel(model);

				if (loggerSettings.isLogEnabled() && loggerSettings.isLogCancelRequest()) {
					AVA_LOGGER.init(loggerSettings);
					StringBuilder msg = new StringBuilder(documentType.name()).append(" document request on Avalara[").append(settings.getUrl()).append("] with data: ").append(model);
					AVA_LOGGER.log(msg.toString());
				}
				retval = client.createOrAdjustTransaction("", m);

				if (loggerSettings.isLogEnabled() && loggerSettings.isLogCancelRequest()) {
					StringBuilder msg = new StringBuilder(documentType.name()).append(" document response on Avalara[").append(settings.getUrl()).append("]: ").append(retval);
					AVA_LOGGER.log(msg.toString());
				}
				LOGGER.trace(methodName, "Creating Tax request for OrderId: {0}", orderId);
			}
		} catch (Exception e) {
			throw new AvalaraException("Exception occured while getting taxes from Avalara", e);
		}

		LOGGER.exiting(methodName);
		return retval;
	}

	public static Vector calculateOnlyReturnTax(Vector iRMAItemABVector, CommandContext commandContext, String rmaId, String orderId) throws AvalaraException {
		return calculateReturnTax(DocumentType.ReturnOrder, iRMAItemABVector, commandContext, rmaId, orderId);
	}
	
	public static Vector calculateAndSubmitReturnTax(Vector iRMAItemABVector, CommandContext commandContext, String rmaId, String orderId) throws AvalaraException {
		return calculateReturnTax(DocumentType.ReturnInvoice, iRMAItemABVector, commandContext, rmaId, orderId);
	}	
	
	private static Vector calculateReturnTax(DocumentType documentType, Vector iRMAItemABVector, CommandContext commandContext, String rmaId, String orderId) throws AvalaraException {
		String methodName = "calculateReturnTax";
		LOGGER.entering(methodName);
		Vector retval = new Vector(iRMAItemABVector.size());

		try {
			ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
			bean.setCommandContext(commandContext);
			bean.populate();

			ACAvalaraSettings settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);
			AvalaraLoggerSettings loggerSettings = ACAvalaraSettingsUtils.loadAvalaraLoggerSettings(bean);
			TransactionModel response = sendReturnTransactionDocument(documentType, settings, loggerSettings, iRMAItemABVector, commandContext, rmaId, orderId);

			try {
				if (ACAvalaraModelHelper.isErrorsInResponse(response)) {
					LOGGER.error(methodName, String.valueOf(response));
					throw new AvalaraException("Exception occured while getting return taxes from Avalara");
				}

				for (int i = 0; i < iRMAItemABVector.size(); i++) {
					RMAItemAccessBean rmaItem = (RMAItemAccessBean) iRMAItemABVector.get(i);
					for (TransactionLineModel line : response.getLines()) {
						String orderItemId = line.getLineNumber();
						if (orderItemId.equals(rmaItem.getOrderItemsId())) {
							if (Boolean.TRUE.equals(settings.getTaxIncluded())) {
								retval.add(i, new MonetaryAmount(BigDecimal.ZERO, rmaItem.getCurrency()));
							} else {
								if (null != line.getTaxOverrideAmount() && TaxOverrideTypeId.None.compareTo(line.getTaxOverrideType()) != 0) {
									retval.add(i, new MonetaryAmount(line.getTaxOverrideAmount().negate(), rmaItem.getCurrency()));
								} else {
									retval.add(i, new MonetaryAmount(line.getTax().negate(), rmaItem.getCurrency()));
								}
							}
							break;
						}
					}
				}
			} catch (Exception e) {
				throw new AvalaraException("Exception occured while getting taxes from Avalara", e);
			}

		} catch (AvalaraException e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw (e);
		} catch (Exception e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw new AvalaraException("Exception occured while getting taxes from Avalara", e);
		}

		LOGGER.exiting(methodName);

		return retval;
	}

	public static Vector calculateReturnTaxDefault(Vector iRMAItemABVector, CommandContext commandContext, String rmaId, String orderId) throws AvalaraException {
		String methodName = "calculateReturnDefault";
		LOGGER.entering(methodName);
		Vector retval = new Vector(iRMAItemABVector.size());

		try {
			ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
			bean.setCommandContext(commandContext);
			bean.populate();

			ACAvalaraSettings settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);
			AvalaraLoggerSettings loggerSettings = ACAvalaraSettingsUtils.loadAvalaraLoggerSettings(bean);

			BigDecimal defaultTaxRate = BigDecimal.ZERO;
			if (settings.isErrorSetDefaultTax()) {
				defaultTaxRate = settings.getDefaultTaxRate();
				defaultTaxRate = defaultTaxRate.divide(new BigDecimal(100.0d), 2, RoundingMode.HALF_UP);
			}

			for (int i = 0; i < iRMAItemABVector.size(); i++) {
				RMAItemAccessBean rmaItem = (RMAItemAccessBean) iRMAItemABVector.get(i);
				if (Boolean.TRUE.equals(settings.getTaxIncluded())) {
					retval.add(i, new MonetaryAmount(BigDecimal.ZERO, rmaItem.getCurrency()));
				} else {
					BigDecimal lineAmount = rmaItem.getCreditAmountInEntityType().add(rmaItem.getAdjustmentCreditInEntityType());
					BigDecimal tax = lineAmount.multiply(defaultTaxRate);
					tax.setScale(2, RoundingMode.HALF_UP);
					retval.add(i, new MonetaryAmount(tax, rmaItem.getCurrency()));
				}
			}

		} catch (AvalaraException e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw (e);
		} catch (Exception e) {
			LOGGER.error(methodName, ECMessageHelper.getExceptionStackTrace(e));
			throw new AvalaraException("Exception occured while getting taxes from Avalara", e);
		}

		LOGGER.exiting(methodName);

		return retval;
	}

}
