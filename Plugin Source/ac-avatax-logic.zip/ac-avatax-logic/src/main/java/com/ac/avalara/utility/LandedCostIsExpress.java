package com.ac.avalara.utility;

public enum LandedCostIsExpress {
Y, N;
}
