package com.ac.commerce.tax.commands;

import com.ibm.commerce.order.calculation.CalculationRuleQualifyCmd;

public interface ACCalculationRuleQualifyCmd extends CalculationRuleQualifyCmd {
	public static final String NAME = ACCalculationRuleQualifyCmd.class.getName();
	public static final String defaultCommandClassName = ACCalculationRuleQualifyCmdImpl.class.getName();
}
