package com.ac.commerce.infrastructure.facade.server.metadata;

public class ACMetaData extends com.ibm.commerce.infrastructure.facade.server.metadata.InfrastructureMetadata {

	private static final String PACKAGE_NAME = "com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACEntityPackageImpl";

	/**
	 * @see com.ibm.commerce.foundation.server.services.dataaccess.db.jdbc.ComponentMetadata#getEPackageName()
	 */
	public String getEPackageName() {
		return PACKAGE_NAME;
	}

	/**
	 * @see com.ibm.commerce.foundation.server.services.dataaccess.db.jdbc.ComponentMetadata#getComponentId()
	 */
	public org.eclipse.emf.ecore.EClass getRootEClass() {
		return com.ac.commerce.infrastructure.facade.server.entity.datatypes.impl.ACEntityPackageImpl.eINSTANCE.getACRoot();
	}
}
