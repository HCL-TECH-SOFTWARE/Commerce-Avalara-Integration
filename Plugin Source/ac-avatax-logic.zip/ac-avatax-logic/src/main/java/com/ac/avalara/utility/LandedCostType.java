package com.ac.avalara.utility;

public enum LandedCostType {
	NONE, DAP, DDP
}
