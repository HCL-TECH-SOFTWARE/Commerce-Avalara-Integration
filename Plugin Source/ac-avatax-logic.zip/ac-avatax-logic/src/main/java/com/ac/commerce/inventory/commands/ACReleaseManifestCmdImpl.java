/**
 * 
 */
package com.ac.commerce.inventory.commands;

import com.ac.avalara.order.bean.ACAvalaraConfigurationDataBean;
import com.ac.avalara.settings.ACAvalaraConstants;
import com.ac.avalara.settings.ACAvalaraSettings;
import com.ac.avalara.settings.ACAvalaraSettingsUtils;
import com.ac.avatax.rest.logger.AvalaraLoggerSettings;
import com.ac.commerce.order.commands.ACAvalaraCommitTransactionTaskCmd;
import com.ac.commerce.util.CommandFactory;
import com.ac.commerce.util.logging.ACLogger;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.inventory.commands.ReleaseManifestCmdImpl;
import com.ibm.commerce.order.objects.OrderAccessBean;

/**
 * @author a.stakhov
 * 
 * Implement Commit sales tax to Avalara Admin Console functionality on Shipping Confirmation step
 *
 */
public class ACReleaseManifestCmdImpl extends ReleaseManifestCmdImpl {
    
    private static final ACLogger LOGGER = new ACLogger(ACReleaseManifestCmdImpl.class);
    
    @Override
    public void performExecute() throws ECException {
        String methodName = "performExecute";
        LOGGER.entering(methodName);
        super.performExecute();
        // check if order shipped and commit if necessary
		try {
			OrderAccessBean order = new OrderAccessBean();
			order.setInitKey_orderId(getOrdersId());
//			order.instantiateEntity();
			
			ACAvalaraConfigurationDataBean bean = new ACAvalaraConfigurationDataBean();
			bean.setCommandContext(commandContext);
			try {
				bean.populate();
			} catch (Exception e) {
				LOGGER.error(methodName, "Error occured while loading avatax configuration:" + e.getMessage());
			}
			ACAvalaraSettings settings = ACAvalaraSettingsUtils.loadAvalaraGeneralSettings(bean);
			AvalaraLoggerSettings loggerSettings = ACAvalaraSettingsUtils.loadAvalaraLoggerSettings(bean);
			
			if (order.getStatus().equals(ACAvalaraSettingsUtils.getConfProperty(ACAvalaraConstants.AVATAX_COMMIT_ON_ORDER_STATUS))) {
		        ACAvalaraCommitTransactionTaskCmd task = CommandFactory.createTask(ACAvalaraCommitTransactionTaskCmd.class, commandContext);
		        task.setOrderId(order.getOrderIdInEntityType());
		        task.execute();				
			}

		} catch (Exception e) {
			LOGGER.error(methodName, "Error occured while commiting transaction:" + e.getMessage());
		}
        


        LOGGER.exiting(methodName);
    }
}
