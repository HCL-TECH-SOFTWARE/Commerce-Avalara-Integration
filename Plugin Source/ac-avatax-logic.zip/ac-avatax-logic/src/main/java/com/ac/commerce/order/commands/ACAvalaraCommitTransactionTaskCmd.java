package com.ac.commerce.order.commands;

import com.ibm.commerce.command.TaskCommand;

public interface ACAvalaraCommitTransactionTaskCmd extends TaskCommand {
    String NAME = ACAvalaraCommitTransactionTaskCmd.class.getName();
    String defaultCommandClassName = ACAvalaraCommitTransactionTaskCmdImpl.class.getName();

    void setOrderId(Long orderId);
}
