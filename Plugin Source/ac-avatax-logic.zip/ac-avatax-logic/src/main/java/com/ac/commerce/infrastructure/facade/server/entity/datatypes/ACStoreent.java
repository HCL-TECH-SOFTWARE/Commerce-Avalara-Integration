/**
 */
package com.ac.commerce.infrastructure.facade.server.entity.datatypes;

import com.ibm.commerce.infrastructure.facade.server.entity.datatypes.Storeent;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>AC Storeent</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACStoreent#getX_avatax_confForStoreent <em>Xavatax conf For Storeent</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getACStoreent()
 * @model
 * @generated
 */
public interface ACStoreent extends Storeent
{
  /**
   * Returns the value of the '<em><b>Xavatax conf For Storeent</b></em>' reference.
   * It is bidirectional and its opposite is '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getStoreentForX_avatax_conf <em>Storeent For Xavatax conf</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Xavatax conf For Storeent</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Xavatax conf For Storeent</em>' reference.
   * @see #setX_avatax_confForStoreent(X_avatax_conf)
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACEntityPackage#getACStoreent_X_avatax_confForStoreent()
   * @see com.ac.commerce.infrastructure.facade.server.entity.datatypes.X_avatax_conf#getStoreentForX_avatax_conf
   * @model opposite="StoreentForX_avatax_conf" resolveProxies="false"
   * @generated
   */
  X_avatax_conf getX_avatax_confForStoreent();

  /**
   * Sets the value of the '{@link com.ac.commerce.infrastructure.facade.server.entity.datatypes.ACStoreent#getX_avatax_confForStoreent <em>Xavatax conf For Storeent</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Xavatax conf For Storeent</em>' reference.
   * @see #getX_avatax_confForStoreent()
   * @generated
   */
  void setX_avatax_confForStoreent(X_avatax_conf value);

} // ACStoreent
