package com.ac.avatax.rest.logger;

import org.apache.commons.io.filefilter.WildcardFileFilter;

import java.io.File;
import java.io.FileFilter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AvalaraLogger {

	private static final String NEWLINE = "\n";

	private long maxFileSize = 20;
	private String fileName;
	private String logDirectory;
	private File logFile;
	private int hoursToKeepLogs;

	public void prepare() {
		File file = getLogFile();
		long l = file.length();

		if (l > (long) (maxFileSize * 1048576)) {
			SimpleDateFormat simpledateformat = new SimpleDateFormat(
					"yyyyMMdd'T'HHmmssSSS");

			String s = file.getAbsolutePath() + "."
					+ simpledateformat.format(new Date());

			File file1 = new File(s);
			file.renameTo(file1);
		}
		
		// check old files to remove
		File dir = new File(logDirectory);
		FileFilter fileFilter = new WildcardFileFilter(fileName + ".*");
		File[] files = dir.listFiles(fileFilter);
		long currentTime = Calendar.getInstance().getTimeInMillis();
		for (File currFile : files) {
			int hoursModifiedBefore = (int)((currentTime - currFile.lastModified()) / (1000 * 60 * 60));
		   if (hoursModifiedBefore > hoursToKeepLogs){
			   currFile.delete();
		   }
		}
	}

	public AvalaraLogger init(AvalaraLoggerSettings setting)  {
		this.fileName = setting.getFileName();
		this.logDirectory = setting.getDirectory();
		prepare();
		logFile = getLogFile();
		
		return this;
	}

	public File getLogFile() {
		File file = new File(logDirectory);
		String s = file.getAbsolutePath();
		if (!file.isDirectory()) {
			System.err.println("The log directory \"" + s
					+ "\" is missing or is not a directory.");
			file.mkdirs();
			return file;
		} else
			return new File(logDirectory, fileName == null ? "avalara.log"
					: fileName);
	}

	public synchronized void log(String s) {
		FileOutputStream fileoutputstream = null;
		try {

			fileoutputstream = new FileOutputStream(logFile.getAbsolutePath(), true);
			SimpleDateFormat simpledateformat = new SimpleDateFormat("yyyy'-'MM'-'dd' 'HH':'mm':'ss'.'SSS");
			Object aobj[] = { NEWLINE, simpledateformat.format(new Date()),
					Thread.currentThread().getName(), s };
			String s2 = MessageFormat.format("{0}{1} {2} {3}> ", aobj);
			byte abyte0[] = s2.getBytes("UTF-8");
			fileoutputstream.write(abyte0);
			byte abyte1[] = NEWLINE.getBytes("UTF-8");
			fileoutputstream.write(abyte1);
			fileoutputstream.close();
		} catch (Exception e) {
			if (fileoutputstream != null) {
				try {
					fileoutputstream.close();
				} catch (IOException ioexception1) {
				}
			}
		}
	}
}
