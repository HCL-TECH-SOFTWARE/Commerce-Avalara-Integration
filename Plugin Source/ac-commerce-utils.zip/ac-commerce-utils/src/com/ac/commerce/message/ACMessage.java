package com.ac.commerce.message;

import com.ibm.commerce.ras.ECMessage;

@SuppressWarnings("serial")
public class ACMessage extends ECMessage {

    public ACMessage(long msgSeverity, int msgType, String msgKey) {
        super(msgSeverity, msgType, msgKey, "com.ac.commerce.message.ACMessage");
    }

    public static final String CV_MESSAGES_RESOURCE_BUNDLE = "com.ac.commerce.message.ACMessage";
    public static final int USER = 1;
    public static final int SYSTEM = 2;
    public static final long ERROR = 1L;
    public static final long WARNING = 2L;
    public static final long STATUS = 4L;
    public static final long INFO = 16L;
    public static final ACMessage _ERR_INVALID_EMAIL_ATTACHMENT = new ACMessage(ERROR, USER, "_ERR_INVALID_EMAIL_ATTACHMENT");

}
