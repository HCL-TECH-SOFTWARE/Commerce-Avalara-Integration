package com.ac.commerce.email;

import java.io.File;

import com.ibm.commerce.exception.ECSystemException;
import com.ibm.commerce.messaging.commands.SendMsgCmd;

public interface ACSendMsgCmd extends SendMsgCmd {
    void setFrom(String s);

    void setTo(String s);

    void setSubject(String s);

    void attachFile(File file, String s) throws ECSystemException;

    void attachContent(byte abyte0[], String s, String s1) throws ECSystemException;

    String TEXT_PLAIN_TYPE = "text/plain";
    String FROM = "sender";
    String SUBJECT = "subject";
    String BODY = "body";
    String RECIPIENT = "recipient";
    String ATTACHMENT = "attachment";
    String defaultCommandClassName = ACSendMsgCmdImpl.class.getName();
}
