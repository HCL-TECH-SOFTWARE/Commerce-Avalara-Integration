package com.ac.commerce.email;

import java.io.File;

public class ACAttachment {

    private File file;
    private String name;
    private String type;
    private String data;
    private int contentType = -1;
    public static final int FILE_DATA = 1;
    public static final int STRING_DATA = 2;

    public ACAttachment(String data, String name, String type) {
        this.data = data;
        this.name = name;
        this.type = type;
        contentType = STRING_DATA;
    }

    public ACAttachment(File file, String type) {
        this.file = file;
        this.type = type;
        contentType = FILE_DATA;
    }

    /**
     * @param file
     *            The file to set.
     */
    public void setFile(File file) {
        this.file = file;
    }

    /**
     * @return Returns the file.
     */
    public File getFile() {
        return file;
    }

    /**
     * @param name
     *            The name to set.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return Returns the name.
     */
    public String getName() {
        return name;
    }

    /**
     * @param type
     *            The type to set.
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return Returns the type.
     */
    public String getType() {
        return type;
    }

    /**
     * @param data
     *            The data to set.
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * @return Returns the data.
     */
    public String getData() {
        return data;
    }

    /**
     * @param contentType
     *            The contentType to set.
     */
    public void setContentType(int contentType) {
        this.contentType = contentType;
    }

    /**
     * @return Returns the contentType.
     */
    public int getContentType() {
        return contentType;
    }

}
