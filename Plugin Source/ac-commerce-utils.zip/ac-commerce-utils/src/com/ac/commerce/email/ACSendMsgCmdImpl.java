package com.ac.commerce.email;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

import com.ibm.commerce.exception.ECSystemException;
import com.ibm.commerce.messaging.commands.SendMsgCmdImpl;
import com.ibm.commerce.ras.ECMessageHelper;
import com.ac.commerce.message.ACMessage;
import com.ac.commerce.util.logging.ACLogger;

@SuppressWarnings("serial")
public class ACSendMsgCmdImpl extends SendMsgCmdImpl implements ACSendMsgCmd {
    private static final String CLASS_NAME = ACSendMsgCmdImpl.class.getName();
    private static final ACLogger LOGGER = new ACLogger(ACSendMsgCmdImpl.class);

    @Override
    public void setFrom(String fromEmail) {
        setConfigData(FROM, fromEmail);
    }

    @Override
    public void setTo(String toEmail) {
        setConfigData(RECIPIENT, toEmail);
    }

    @Override
    public void setSubject(String subjectEmail) {
        setConfigData(SUBJECT, subjectEmail);
    }

    @Override
    public void attachFile(File name, String type) throws ECSystemException {
        attachContent(getAttachmentContent(name), name.getName(), type);
    }

    @Override
    public void attachContent(byte data[], String name, String type) {
        addContentPart(data, name, type == null ? TEXT_PLAIN_TYPE : type);
    }

    private static byte[] getAttachmentContent(File file) throws ECSystemException {
        final String methodName = "getAttachmentContent";
        if (!file.isFile()) {
            throw new ECSystemException(ACMessage._ERR_INVALID_EMAIL_ATTACHMENT, CLASS_NAME, methodName,
                ECMessageHelper.generateMsgParms(file.getAbsolutePath()));
        }
        try {
            return FileUtils.readFileToByteArray(file);
        } catch (IOException e) {
            LOGGER.error(methodName, "Exception occured in getAttachmentContent", e);
            throw new ECSystemException(ACMessage._ERR_INVALID_EMAIL_ATTACHMENT, CLASS_NAME, methodName,
                ECMessageHelper.generateMsgParms(file.getAbsolutePath()));
        }
    }
}
