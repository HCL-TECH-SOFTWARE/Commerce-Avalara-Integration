package com.ac.commerce.payment.helpers;

import java.util.Comparator;
import java.util.Map;

import com.ibm.commerce.payment.beans.PaymentPolicyInfo;

public class PaymentPolicyInfoComparator implements Comparator<PaymentPolicyInfo> {

	private Map<String, Integer> paymentMethods;
	   
	public PaymentPolicyInfoComparator(Map<String, Integer> paymentMethods) {
		super();
		this.paymentMethods = paymentMethods;
	}

	@Override
    public int compare(PaymentPolicyInfo object1, PaymentPolicyInfo object2) {
        return getPriority(object1).compareTo(getPriority(object2));
    }
	
	private Integer getPriority(PaymentPolicyInfo obj) {
		Integer ret = 0;
		if (paymentMethods.containsKey(obj.getPolicyName())) {
			ret = paymentMethods.get(obj.getPolicyName());
		}
		return ret;
	}

}