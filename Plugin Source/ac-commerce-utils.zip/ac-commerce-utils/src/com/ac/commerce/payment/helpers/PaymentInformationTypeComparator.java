package com.ac.commerce.payment.helpers;

import java.util.Comparator;
import java.util.Map;

import com.ibm.commerce.order.facade.datatypes.PaymentInformationType;

public class PaymentInformationTypeComparator implements Comparator<PaymentInformationType> {

    private Map<String, Integer> paymentMethods;

    public PaymentInformationTypeComparator(Map<String, Integer> paymentMethods) {
        super();
        this.paymentMethods = paymentMethods;
    }

    @Override
    public int compare(PaymentInformationType object1, PaymentInformationType object2) {
        return getPriority(object1).compareTo(getPriority(object2));
    }

    private Integer getPriority(PaymentInformationType obj) {
        Integer ret = 0;
        if (paymentMethods.containsKey(obj.getPaymentMethod().getPaymentMethodName())) {
            ret = paymentMethods.get(obj.getPaymentMethod().getPaymentMethodName());
        }
        return ret;
    }
}