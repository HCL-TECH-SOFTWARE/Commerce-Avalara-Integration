package com.ac.commerce.payment.helpers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;

import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.order.facade.datatypes.PaymentInformationType;
import com.ibm.commerce.payment.beans.PaymentPolicyInfo;
import com.ibm.commerce.ras.ECMessage;
import com.ac.util.exception.ACApplicationException;
import com.ac.util.messages.ACMessage;

public class CreditCardHelper {
    private static final String PAY_PAL = "PayPal";
    private static final String DISCOVER = "Discover";
    private static final String MASTER_CARD = "Master Card";
    private static final String VISA = "VISA";
    private static final String AMEX = "AMEX";
    private static final String NFM = "NFM";
    protected static final Map<String, Integer> paymentMethods;		//Used for the Checkout -> Shipping&Billing page
    protected static final Map<String, Integer> paymentMethodsQCP;	//Used for the My Account -> Quick Checkout Profile Page
    protected static final List<String> isUsedInCreditCardBook;
    private static final ECMessage _ERR_CVV_INVALID = new ECMessage(1L, 2, "_ERR_CVV_INVALID", null, null, "HZ4T0TAK0E");

    static {
        paymentMethods = new ConcurrentHashMap<String, Integer>();
        
        paymentMethods.put(VISA, 1);
        paymentMethods.put(MASTER_CARD, 2);
        paymentMethods.put(DISCOVER, 3);
        paymentMethods.put(AMEX, 4);
        paymentMethods.put(NFM, 5);
        paymentMethods.put(PAY_PAL, 6);
        
        paymentMethodsQCP = new ConcurrentHashMap<String, Integer>();
        
        paymentMethodsQCP.put(VISA, 1);
        paymentMethodsQCP.put(MASTER_CARD, 2);
        paymentMethodsQCP.put(DISCOVER, 3);
        paymentMethodsQCP.put(AMEX, 4);

        isUsedInCreditCardBook = new ArrayList<String>();
        isUsedInCreditCardBook.add(StringUtils.lowerCase(MASTER_CARD));
        isUsedInCreditCardBook.add(StringUtils.lowerCase(VISA));
        isUsedInCreditCardBook.add(StringUtils.lowerCase(AMEX));
        isUsedInCreditCardBook.add(StringUtils.lowerCase(DISCOVER));
    }

    public static PaymentInformationType[] filterAndSort(PaymentInformationType[] payments) {
        payments = filter(payments);
        Arrays.sort(payments, new PaymentInformationTypeComparator(paymentMethods));
        return payments;
    }
    
	public static PaymentPolicyInfo[] filterAndSortQCP(PaymentPolicyInfo[] payments) {
		LinkedList<PaymentPolicyInfo> list = new LinkedList<PaymentPolicyInfo>();
        list.addAll(Arrays.asList(payments));
        Iterator<PaymentPolicyInfo> iterator = list.iterator();
        while (iterator.hasNext()) {
        	PaymentPolicyInfo policy = iterator.next();
            if (!paymentMethodsQCP.containsKey(policy.getPolicyName())) {
                iterator.remove();
            }
        }
        payments = list.toArray(new PaymentPolicyInfo[0]);
        Arrays.sort(payments, new PaymentPolicyInfoComparator(paymentMethodsQCP));
        
		return payments;
	}

    protected static PaymentInformationType[] filter(PaymentInformationType[] payments) {
        LinkedList<PaymentInformationType> list = new LinkedList<PaymentInformationType>();
        list.addAll(Arrays.asList(payments));
        Iterator<PaymentInformationType> iterator = list.iterator();
        while (iterator.hasNext()) {
            PaymentInformationType policy = iterator.next();
            if (!paymentMethods.containsKey(policy.getPaymentMethod().getPaymentMethodName())) {
                iterator.remove();
            }
        }
        return list.toArray(new PaymentInformationType[0]);
    }



    public static void assertCreditCardCvv(String cardBrand, String cardCvv) throws ECException {
        if (isUsedInCreditBook(cardBrand)) {
            if (null == cardCvv) {
                cardCvv = "";
            }
            cardCvv = StringUtils.trim(cardCvv);
            if (StringUtils.isEmpty(cardCvv)) {
                throw new ACApplicationException(ACMessage._ERR_INVALID_CARD_CVV2, CreditCardHelper.class.getCanonicalName(),
                    "assertCreditCardCvv");
            }
            if (StringUtils.equalsIgnoreCase(AMEX, cardBrand)) {
                if (!cardCvv.matches("^[0-9]{4}$")) {
                    throw new ECApplicationException(_ERR_CVV_INVALID, CreditCardHelper.class.getCanonicalName(), "assertCreditCardCvv");
                }
            } else {
                if (!cardCvv.matches("^[0-9]{3}$")) {
                    throw new ECApplicationException(_ERR_CVV_INVALID, CreditCardHelper.class.getCanonicalName(), "assertCreditCardCvv");
                }
            }
        }

    }

    public static boolean isUsedInCreditBook(String policyName) {
        return isUsedInCreditCardBook.contains(StringUtils.lowerCase(policyName));
    }


}
