package com.ac.commerce.payment;

import com.ibm.commerce.command.CommandContext;
import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.order.commands.OrderCalculateCmd;
import com.ibm.commerce.order.commands.PrepareOrderCmd;
import com.ibm.commerce.order.objects.OrderAccessBean;
import com.ac.commerce.objects.helpers.OrderAccessBeans;
import com.ac.commerce.util.CommandFactory;
import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.exception.ACRuntimeException;

public class PaymentUtilsService {

    private static final ACLogger LOGGER = new ACLogger(PaymentUtilsService.class);
    private CommandContext commandContext;

    public PaymentUtilsService(CommandContext commandContext) {
        this.commandContext = commandContext;
    }

    /**
     * Method executes OrderCalculateCmd
     * 
     * @throws ACRuntimeException
     *             in case any error occurs
     */
    public void runOrderCalculateCmd() throws ACRuntimeException {
        String methodName = "runOrderCalculateCmd";
        LOGGER.entering(methodName);
        try {
            TypedProperty prop = new TypedProperty();
            prop.put("calculationUsageId", new Integer[] { -1, -2, -3, -4, -5, -6, -7 });
            prop.put("storeId", commandContext.getStoreId());

            OrderCalculateCmd orderCalculate = CommandFactory.createCommand(OrderCalculateCmd.class, commandContext.getStoreId());
            CommandContext clone = (CommandContext) commandContext.clone();
            clone.setStoreId(clone.getStoreId());
            orderCalculate.setCommandContext(clone);
            orderCalculate.setRequestProperties(prop);
            orderCalculate.setAccCheck(false);
            orderCalculate.execute();
        } catch (Exception e) {
            throw new ACRuntimeException(e);
        } finally {
            LOGGER.exiting(methodName);
        }
    }

    /**
     * This method executes PrepareOrderCmd command that prepares an order by determining prices, discounts, shipping charges, and taxes for
     * an order.
     * 
     * @author a.lebedinskiy <a.lebedinskiy@sysiq.com>
     * @see <a
     *      href="http://pic.dhe.ibm.com/infocenter/wchelp/v7r0m0/index.jsp?topic=%2Fcom.ibm.commerce.api.doc%2Fcom%2Fibm%2Fcommerce%2Forder%2Fcommands%2FPrepareOrderCmd.html">Interface
     *      PrepareOrderCmd</a>
     * @param orderId
     *            String representation of order unique identifier
     * @param commandCtx
     *            Command context to execute PrepareOrderCmd command
     * @throws ACRuntimeException
     */
    public void runPrepareOrderCmd(Long orderId) throws ACRuntimeException {
        String methodName = "runPrepareOrderCmd";
        LOGGER.entering(methodName);
        try {
            PrepareOrderCmd cmd = CommandFactory.createTask(PrepareOrderCmd.class, commandContext.getStoreId());
            OrderAccessBean abOrder = OrderAccessBeans.bean(orderId);
            cmd.setOrder(abOrder);

            CommandContext clone = (CommandContext) commandContext.clone();
            clone.becomeUser(abOrder.getMemberIdInEntityType());
            cmd.setCommandContext(clone);

            cmd.execute();
        } catch (Exception e) {
            throw new ACRuntimeException(e);
        } finally {
            LOGGER.exiting(methodName);
        }
    }
}
