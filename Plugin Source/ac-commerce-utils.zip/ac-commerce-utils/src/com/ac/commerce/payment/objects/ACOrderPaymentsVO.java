package com.ac.commerce.payment.objects;

import com.ibm.commerce.price.beans.FormattedMonetaryAmountDataBean;

public class ACOrderPaymentsVO {

    public ACOrderPaymentsVO() {
        super();
    }

    private String paymentMethod;
    private String paymentAccount;
    private double paymentAmount;
    private FormattedMonetaryAmountDataBean formattedPaymentAmount;
    private String paymentInstructionId;

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentAccount(String paymentAccount) {
        this.paymentAccount = paymentAccount;
    }

    public String getPaymentAccount() {
        return paymentAccount;
    }

    public void setPaymentAmount(double paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public double getPaymentAmount() {
        return paymentAmount;
    }

    public void setFormattedPaymentAmount(FormattedMonetaryAmountDataBean formattedAmount) {
        formattedPaymentAmount = formattedAmount;
    }

    public FormattedMonetaryAmountDataBean getFormattedPaymentAmount() {
        return formattedPaymentAmount;
    }

    public void setPaymentInstructionId(String paymentInstructionId) {
        this.paymentInstructionId = paymentInstructionId;
    }

    public String getPaymentInstructionId() {
        return paymentInstructionId;
    }
}
