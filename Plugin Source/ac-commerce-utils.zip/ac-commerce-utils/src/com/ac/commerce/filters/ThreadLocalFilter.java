package com.ac.commerce.filters;

import java.io.IOException;
import java.util.Properties;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

import com.ibm.commerce.server.JSPHelper;
import com.ac.commerce.util.configuration.ACPropertyLoaderFactory;
import com.ac.commerce.util.logging.ACLogger;

public class ThreadLocalFilter implements Filter {
    private static final String CACHE_KEY = ThreadLocalFilter.class.getCanonicalName() +".cachekey";
    public static final String DEBUG_ATTRIBUTE_KEY = ThreadLocalFilter.class.getCanonicalName() +".attributekey";
    private static final String DEBUG_PARAM_NAME_PROPERTY = "debug.param.name";
    private static final String DEBUG_PARAM_PASSWORD_PROPERTY = "debug.param.value";
    
    private static final ACLogger LOGGER = new ACLogger(ThreadLocalFilter.class);
    private static final String CONFIG_FILE = "config.file";
    private String configFile = null; 
    public final static ThreadLocal<ServletRequest> CURRENT_REQUEST = new ThreadLocal<ServletRequest>();
    public final static ThreadLocal<ServletResponse> CURRENT_RESPONSE = new ThreadLocal<ServletResponse>();

    @Override
    public void destroy() {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        CURRENT_REQUEST.set(request);
        CURRENT_RESPONSE.set(response);
        setNoCacheAttribute(request);
        try {
            chain.doFilter(request, response);
        } finally {
            CURRENT_REQUEST.set(null);
            CURRENT_RESPONSE.set(null);
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        String methodName = "init(FilterConfig filterConfig)";
        LOGGER.entering(methodName);
        configFile = filterConfig.getInitParameter(CONFIG_FILE);
        LOGGER.fine(methodName, "configFile = {0}", configFile);
        LOGGER.exiting(methodName);
    }

    private void setNoCacheAttribute(ServletRequest request) {
        String methodName = "setNoCacheAttribute(ServletRequest request)";
        LOGGER.entering(methodName);
        Properties configuration = getConfiguration();
        LOGGER.fine(methodName, "configuration = {0}", configuration);
       
        String debugParam = configuration.getProperty(DEBUG_PARAM_NAME_PROPERTY);
        LOGGER.fine(methodName, "debugParam = {0}", debugParam);
        
        String parameter = request.getParameter(debugParam);
        if (StringUtils.isNotEmpty(parameter)) {
            String password = configuration.getProperty(DEBUG_PARAM_PASSWORD_PROPERTY);
            parameter = StringUtils.trimToEmpty(parameter);
            password = StringUtils.trimToEmpty(password);
            LOGGER.fine(methodName, "parameter = {0}, password={1}", parameter, password);
            if(StringUtils.equals(parameter, password)){
                LOGGER.fine(methodName, "Marked request to not cache and set attribute {0}=true", DEBUG_ATTRIBUTE_KEY);
                request.setAttribute(DEBUG_ATTRIBUTE_KEY, true);
                JSPHelper.setUncacheable(((HttpServletRequest) request), true);
            }
        }
        LOGGER.exiting(methodName);
    }
    
    private Properties getConfiguration(){
        String methodName = "getConfiguration()";
        LOGGER.entering(methodName);
        Properties ret = ACPropertyLoaderFactory.getInstance().getProperties(configFile);
        LOGGER.entering(methodName, ret);
        return ret;
    }
}
