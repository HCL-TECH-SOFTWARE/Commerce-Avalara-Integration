package com.ac.commerce.util.request;

import java.lang.reflect.Field;

import com.ibm.commerce.command.ControllerCommandImpl;
import com.ibm.commerce.datatype.TypedProperty;
import com.ac.commerce.util.logging.ACLogger;

public final class RequestPropertiesHelper {

    private static final ACLogger LOGGER = new ACLogger(RequestPropertiesHelper.class);

    private RequestPropertiesHelper() {
        // Utility class
    }

    public static void injectRequestFields(ControllerCommandImpl c, TypedProperty props, Field field) {
        String methodName = "injectRequestFields";
        RequestProperty annotation = field.getAnnotation(RequestProperty.class);
        if (annotation != null) {
            try {
                field.setAccessible(true);
                String def = RequestProperty.NULL.equals(annotation.defaultValue()) ? null : annotation.defaultValue();
                field.set(c, props.getString(annotation.value(), def));
            } catch (Exception e) {
                LOGGER.error(methodName, e.getMessage(), e);
            }
        }
    }
}
