/**
 * 
 */
package com.ac.commerce.util.configuration;

import com.ibm.commerce.command.ControllerCommandImpl;
import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.exception.ECException;
import com.ac.util.Objects;

/**
 * @author a.kudla
 * 
 */
public class ACPropertyManagerCmdImpl extends ControllerCommandImpl implements ACPropertyManagerCmd {
    private ACPropertyLoader loader = ACPropertyLoaderFactory.getInstance();
    private String key;
    private String property;
    private String value;
    private String cmd;

    @Override
    public void performExecute() throws ECException {
        if (Objects.eq("clear", cmd)) {
            clearCache();
        } else {
            processCache();
        }
        listAll();
    }

    private void processCache() {
        if (key != null && property != null && value != null) {
            loader.putPropertyToCache(property, value, key);
        }
    }

    private boolean clearCache() {
        if (key != null) {
            return property == null ? loader.clearCacheEntry(key) : loader.putPropertyToCache(property, value, key);
        }
        loader.clearCaches();
        return true;
    }

    @Override
    public void validateParameters() throws ECException {
        key = getRequestProperties().getString("key", null);
        property = getRequestProperties().getString("property", null);
        value = getRequestProperties().getString("value", null);
        cmd = getRequestProperties().getString("cmd", null);
    }

    private void listAll() {
        TypedProperty responseProps = new TypedProperty();
        if (cmd == null && key != null) {
            responseProps.put(key, loader.getProperties(key));
        } else {
            for (String cacheKey : loader.getPropertiesCacheKeys()) {
                responseProps.put(cacheKey, loader.getProperties(cacheKey));
            }
        }
        setResponseProperties(responseProps);
    }

}
