package com.ac.commerce.util.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.ac.commerce.util.logging.ACLogger;

/**
 * Database utilities like Apache commons db utils
 */
public final class DBUtils {

    private static final ACLogger LOGGER = new ACLogger(DBUtils.class);

    private DBUtils() {
    }

    public static void close(ResultSet rs) throws SQLException {
        if (rs != null) {
            rs.close();
        }
    }

    public static void close(Statement st) throws SQLException {
        if (st != null) {
            st.close();
        }
    }

    public static void close(Connection conn) throws SQLException {
        if (conn != null) {
            conn.close();
        }
    }

    public static void closeQuietly(ResultSet rs) {
        String methodName = "closeQuietly(ResultSet rs)";
        try {
            close(rs);
        } catch (SQLException e) {
            LOGGER.error(methodName, "Exception while closing ResultSet ", e);
        }
    }

    public static void closeQuietly(Statement st) {
        String methodName = "closeQuietly(Statement st)";
        try {
            close(st);
        } catch (SQLException e) {
            LOGGER.error(methodName, "Exception while closing Statement ", e);
        }
    }

    public static void closeQuietly(Connection conn) {
        String methodName = "closeQuietly(Connection conn)";
        try {
            close(conn);
        } catch (SQLException e) {
            LOGGER.error(methodName, "Exception while closing Connection ", e);
        }
    }

    public static void closeQuietly(Connection conn, Statement st, ResultSet rs) {
        try {
            closeQuietly(rs);
        } finally {
            try {
                closeQuietly(st);
            } finally {
                closeQuietly(conn);
            }
        }
    }
}
