package com.ac.commerce.util;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import javax.servlet.ServletRequest;

import com.ac.commerce.filters.ThreadLocalFilter;
import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.profiler.ACProfiler;

public final class ServiceHelper {

    private ServiceHelper() {
        // Utility class
    }

    public static <T> T getLoggingProxy(Class<T> clazz, Object instance) {
        return clazz.cast(Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(), new Class[] { clazz },
            new ProxyLoggingInvocationHandler(instance)));
    }

    private static class ProxyLoggingInvocationHandler implements InvocationHandler {
        private final Object _delegate;
        private final ACLogger _log;
        private final String className;

        public ProxyLoggingInvocationHandler(Object obj2Proxy) {
            super();
            _delegate = obj2Proxy;
            _log = new ACLogger(obj2Proxy.getClass());
            className = obj2Proxy.getClass().getCanonicalName();
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            final String methodName = method.getName();
            boolean isInRequest = false;
            ServletRequest request = ThreadLocalFilter.CURRENT_REQUEST.get();
            String label = className + "." + methodName;
            if (request != null) {
                isInRequest = true;
                ACProfiler.INSTANCE.start(label, request);
            }

            boolean debug = _log.isFineLoggable();
            if (debug) {
                _log.entering(methodName, args);
            } else {
                _log.entering(methodName);
            }

            try {
                Object result = method.invoke(_delegate, args);

                if (debug) {
                    if (method.getReturnType() == void.class) {
                        _log.exiting(methodName);
                    } else {
                        _log.exiting(methodName, result);
                    }
                } else {
                    _log.exiting(methodName);
                }

                return result;
            } catch (InvocationTargetException ex) {
                Throwable targetException = ex.getTargetException();
                _log.error(methodName, "", targetException);
                throw targetException;
            } finally {
                if (isInRequest) {
                    ACProfiler.INSTANCE.stop(label, request);
                }
            }
        }

    }
}
