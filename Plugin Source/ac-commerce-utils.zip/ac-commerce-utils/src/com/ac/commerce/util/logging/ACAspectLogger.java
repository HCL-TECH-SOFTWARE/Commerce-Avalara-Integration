package com.ac.commerce.util.logging;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.ibm.commerce.foundation.common.util.logging.LoggingHelper;

public class ACAspectLogger {
    private static final Level LVL_TRACE = LoggingHelper.DEFAULT_TRACE_LOG_LEVEL;
    private static final Level LVL_INFO = Level.INFO;
    private static final Level LVL_WARNING = Level.WARNING;
    private static final Level LVL_SEVERE = Level.SEVERE;

    private Logger logger;
    private String className;

    public <T> ACAspectLogger(Class<T> loggedClass, Logger logger) {
        className = loggedClass.getName();
        this.logger = logger;
    }

    public void trace(String methodName, String msg) {
        logger.logp(LVL_TRACE, className, methodName, msg);
    }

    public void trace(String methodName, String msg, Object param) {
        logger.logp(LVL_TRACE, className, methodName, msg, param);
    }

    public void trace(String methodName, String msg, Object... param) {
        logger.logp(LVL_TRACE, className, methodName, msg, param);
    }

    public void trace(String methodName, String msg, Throwable e) {
        logger.logp(LVL_TRACE, className, methodName, msg, e);
    }

    public void entering(String methodName) {
        logger.entering(className, methodName);
    }

    public void entering() {
        // logger.entering(className);
    }

    public void entering(String methodName, Object param) {
        logger.entering(className, methodName, param);
    }

    public void entering(String methodName, Object[] param) {
        logger.entering(className, methodName, param);
    }

    public void exiting(String methodName) {
        logger.exiting(className, methodName);
    }

    public void exiting(String methodName, Object result) {
        logger.exiting(className, methodName, result);
    }

    public void info(String methodName, String msg) {
        logger.logp(LVL_INFO, className, methodName, msg);
    }

    public void info(String methodName, String msg, Object param) {
        logger.logp(LVL_INFO, className, methodName, msg, param);
    }

    public void info(String methodName, String msg, Object[] param) {
        logger.logp(LVL_INFO, className, methodName, msg, param);
    }

    public void info(String methodName, String msg, Throwable e) {
        logger.logp(LVL_INFO, className, methodName, msg, e);
    }

    public void warn(String methodName, String msg) {
        logger.logp(LVL_WARNING, className, methodName, msg);
    }

    public void warn(String methodName, String msg, Object param) {
        logger.logp(LVL_WARNING, className, methodName, msg, param);
    }

    public void warn(String methodName, String msg, Object[] param) {
        logger.logp(LVL_WARNING, className, methodName, msg, param);
    }

    public void warn(String methodName, String msg, Throwable e) {
        logger.logp(LVL_WARNING, className, methodName, msg, e);
    }

    public void error(String methodName, String msg) {
        logger.logp(LVL_SEVERE, className, methodName, msg);
    }

    public void error(String methodName, String msg, Object param) {
        logger.logp(LVL_SEVERE, className, methodName, msg, param);
    }

    public void error(String methodName, String msg, Object[] param) {
        logger.logp(LVL_SEVERE, className, methodName, msg, param);
    }

    public void error(String methodName, String msg, Throwable e) {
        logger.logp(LVL_SEVERE, className, methodName, msg, e);
    }

    public void throwing(String methodName, Throwable e) {
        logger.throwing(className, methodName, e);
    }

    public boolean isTraceEnabled() {
        return LoggingHelper.isTraceEnabled(logger);
    }

    public boolean isEntryExitTraceEnabled() {
        return LoggingHelper.isEntryExitTraceEnabled(logger);
    }

    public boolean isInfoLoggable() {
        return logger.isLoggable(LVL_INFO);
    }

    public boolean isWarningLoggable() {
        return logger.isLoggable(LVL_WARNING);
    }

    public boolean isErrorLoggable() {
        return logger.isLoggable(LVL_SEVERE);
    }

    public String getClassName() {
        return className;
    }
}
