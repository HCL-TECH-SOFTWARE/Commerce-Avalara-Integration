package com.ac.commerce.util.io;

import java.io.Closeable;
import java.io.IOException;

/**
 * I/O utilities like Apache commons db utils
 */
public final class IOUtils {

    private IOUtils() {
    }

    public static void closeQuietly(Closeable closeable) {
        try {
            if (closeable != null) {
                closeable.close();
            }
        } catch (IOException e) {
            // skip
        }
    }
}
