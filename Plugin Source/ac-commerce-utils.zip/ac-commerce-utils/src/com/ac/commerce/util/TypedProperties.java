package com.ac.commerce.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.logging.Logger;

import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.exception.ParameterNotFoundException;
import com.ibm.commerce.foundation.common.util.logging.LoggingHelper;

public final class TypedProperties {
    public static final Logger LOGGER = LoggingHelper.getLogger(TypedProperties.class);

    private TypedProperties() {
        // Singleton
    }

    public static boolean contains(TypedProperty prop, String key, String value) {
        try {
            return prop.containsKey(key) && prop.getString(key).equals(value);
        } catch (ParameterNotFoundException e) {
            LOGGER.severe("TypedProperties.contains:" + e.getMessage());
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    public static <T> T get(TypedProperty prop, String key) {
        if (prop == null) {
            return null;
        }
        try {
            return (T) (prop.containsKey(key) ? prop.get(key) : null);
        } catch (ParameterNotFoundException e) {
            LOGGER.severe("TypedProperties.get:" + e.getMessage());
        }
        return null;
    }

    public static TypedProperty copy(TypedProperty prop) {
        return new TypedProperty(prop);
    }

    /** Converts the Map into TypedProperty for external command call */
    public static TypedProperty fromMap(Map propMap) {
        TypedProperty props = new TypedProperty();
        Set<Entry> entries = propMap.entrySet();
        for (Entry entry : entries) {
            props.put(entry.getKey(), entry.getValue());
        }
        return props;
    }

    @SuppressWarnings("unchecked")
    public static Map<Object, Object> getMap(TypedProperty properties) {
        Map<Object, Object> result = new HashMap<Object, Object>();
        for (Entry entry : (Set<Entry>) properties.getMap().entrySet()) {
            Object value = entry.getValue();
            result.put(entry.getKey(), value instanceof Object[] ? ((Object[]) value)[0] : value);
        }

        return result;
    }

    @SuppressWarnings("unchecked")
    public static <T> T putIfAbsent(TypedProperty props, String property, T newValue) {
        T value = get(props, property);
        if (newValue == null) {
            return value;
        }
        return value == null ? (T) props.put(property, newValue) : value;
    }

}
