package com.ac.commerce.util;

import static java.lang.String.format;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.ac.commerce.util.logging.ACLogger;

public final class BeanUtils {
    private static final ACLogger LOG = new ACLogger(BeanUtils.class);
    private static InitialContext initialContext;
    static {
        try {
            initialContext = new InitialContext();
        } catch (NamingException e) {
            LOG.error("BeanUtils.initialize", "Cannot init initialContext", e);
        }
    }

    private BeanUtils() {
        // Utility class
    }

    @SuppressWarnings("unchecked")
    public static <T> T lookup(Class<T> clazz) {
        String methodName = "lookup(Class<T> clazz)";
        try {
            return (T) initialContext.lookup(clazz.getName());
        } catch (NamingException e) {
            LOG.error(methodName, format("lookup failed for %s", clazz.getName()), e);
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    public static <T> T lookup(String classPath) {
        String methodName = "lookup(String classPath)";
        try {
            return (T) initialContext.lookup(classPath);
        } catch (NamingException e) {
            LOG.error(methodName, format("lookup failed for %s", classPath), e);
        }
        return null;
    }
}
