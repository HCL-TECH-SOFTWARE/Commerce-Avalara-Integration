package com.ac.commerce.util;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.ibm.commerce.command.CommandContext;
import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.foundation.common.util.logging.LoggingHelper;
import com.ibm.commerce.messaging.commands.SendMsgCmd;

/**
 * Utility class for sending messages
 * 
 * @author v.potaychuk
 * 
 */
public final class ACMessageUtils {
    // messages for TypedProperty
    public static final String MESSAGE_TYPE = "messageType";
    public static final String STORE_ID = "storeId";
    public static final String MESSAGE_BODY = "messageBody";
    public static final String SUBJECT = "subject";
    public static final String RECEPIENT = "recipient";
    public static final String SENDER = "sender";

    private static final String CLASS_NAME = ACMessageUtils.class.getName();
    private static final Logger LOGGER = LoggingHelper.getLogger(ACMessageUtils.class);

    private ACMessageUtils() {
    }

    /**
     * Send simple email without JSP composition service
     */
    public static void sendSimpleEmail(CommandContext cmd, TypedProperty props) {
        final String methodName = "sendSimpleEmail";
        try {
            SendMsgCmd api = CommandFactory.createTask(SendMsgCmd.class, props.getInteger(STORE_ID));
            api.setMsgType(props.getString(MESSAGE_TYPE));
            api.setStoreID(props.getInteger(STORE_ID));

            // Set the content for English (with language id of -1)
            // The first parameter is null. This means that the transport used
            // is dependent on the
            // value set in the Administration Console.
            api.setContent(null, "-1", props.getString(MESSAGE_BODY).getBytes());

            // Set the subject, recipient and sender information using
            // Configurable message data services.
            // To adapt the following example to use the file adapter instead of
            // the e-mail adapter, replace
            // the 3 lines of code for the e-mail adapter with the following 2
            // lines:
            // api.setConfigData("location","c:\");
            // api.setConfigData("FileName","abc.txt");

            api.setConfigData(SUBJECT, props.getString(SUBJECT));
            api.setConfigData(RECEPIENT, props.getString(RECEPIENT));
            api.setConfigData(SENDER, props.getString(SENDER));

            // Send out the message using sendImmediate send service.
            api.sendImmediate();

            // Set the command context obtained from the controller command.
            api.setCommandContext(cmd);

            // Run the outbound messaging system services
            api.execute();

        } catch (Exception ex) {
            LOGGER.logp(Level.FINEST, CLASS_NAME, methodName, "Exception occured in sendSimpleEmail", ex);
        }
    }

    /**
     * Send email using JSP composition service
     */
    public static void sendJSPCompositionEmail(CommandContext cmd, TypedProperty props) {
        final String methodName = "sendJSPCompositionEmail";
        try {
            SendMsgCmd cmdSendMsg = CommandFactory.createTask(SendMsgCmd.class, props.getInteger(STORE_ID));

            // Change the argument to the name of the message type that was
            // inserted into the MSGTYPES table
            cmdSendMsg.setMsgType(props.getString(MESSAGE_TYPE));
            cmdSendMsg.setStoreID(props.getInteger(STORE_ID));

            cmdSendMsg.setConfigData(SUBJECT, props.getString(SUBJECT));
            cmdSendMsg.setConfigData(RECEPIENT, props.getString(RECEPIENT));
            cmdSendMsg.setConfigData(SENDER, props.getString(SENDER));

            CommandContext ccc = (CommandContext) cmd.clone();
            cmdSendMsg.compose(null, ccc, props);
            cmdSendMsg.sendTransacted();
            cmdSendMsg.setCommandContext(ccc);
            cmdSendMsg.setStoreID(ccc.getStoreId());
            cmdSendMsg.setDefaultProperties(props);
            cmdSendMsg.execute();
        } catch (Exception ex) {
            LOGGER.logp(Level.FINEST, CLASS_NAME, methodName, "Exception occured in sendJSPCompositionEmail", ex);
        }
    }
}
