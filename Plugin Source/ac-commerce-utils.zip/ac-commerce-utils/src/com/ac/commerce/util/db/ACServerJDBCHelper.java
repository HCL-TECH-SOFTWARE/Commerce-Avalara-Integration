/**
 * 
 */
package com.ac.commerce.util.db;

import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.ibm.commerce.base.objects.ServerJDBCHelperBean;
import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.Lists;
import com.ac.util.Option;
import com.ac.util.function.Function;

/**
 * Helper class to execute sqls. Wrapper on @ServerJDBCHelperAccessBean Example of usage can be found in @SIServerJDBCHelperTest
 * 
 * @author a.kudla
 * 
 */
public final class ACServerJDBCHelper {

    private static final ACLogger LOGGER = new ACLogger(ACServerJDBCHelper.class);

    private static final Function<List, Object> HEAD_MAPPER = new Function<List, Object>() {

        @Override
        public Object apply(List value) {
            return Lists.head(value);
        }
    };

    private ACServerJDBCHelper() {
        // Utility class
    }

    /**
     * Method to execute aggregated sqls like count, sum, ....
     * 
     * @param <T>
     *            - result type
     * @param sqlStatement
     *            - parametrized query
     * @param params
     *            - parameters for query
     * @return
     */
    @Nonnull
    @SuppressWarnings("unchecked")
    public static <T> Option<T> selectAggregate(@Nonnull String sqlStatement, @Nullable String... params) {
        final String methodName = "executeSQLQuery";
        LOGGER.entering(methodName, sqlStatement, params);
        T res = (T) Lists.head(query(sqlStatement, HEAD_MAPPER, params));
        Option<T> ret = Option.of(res);
        LOGGER.exiting(methodName, ret);
        return ret;
    }

    /**
     * 
     * Generic method to execute sql.
     * 
     * @param sqlStatement
     *            - parametrized sql
     * @param params
     *            - params for sql
     * @return results in a form of list of lists
     */
    @Nonnull
    public static List<List> query(@Nonnull String sqlStatement, @Nullable String... params) {
        final String methodName = "executeSQLQuery";
        ServerJDBCHelperBean jdbcHelper = new ServerJDBCHelperBean();
        try {
            return Lists.nonNull(jdbcHelper.executeParameterizedQuery(sqlStatement, params));
        } catch (Exception e) {
            LOGGER.error(methodName, "Error while executiong quety", e);
        }
        return Lists.newArrayList();
    }

    /**
     * 
     * Generic method to execute sql.
     * 
     * @param <T>
     *            - result type
     * @param sqlStatement
     *            - parametrized sql
     * @param mapper
     *            - mapper for results
     * @param params
     *            - parameters for sql
     * @return
     */
    @Nonnull
    @SuppressWarnings("unchecked")
    public static <T> List<T> query(@Nonnull String sqlStatement, @Nonnull Function<List, T> mapper, @Nullable String... params) {
        List<List> res = query(sqlStatement, params);
        return Lists.map(res, mapper);
    }
}
