package com.ac.commerce.util;

/**
 * contains constants usable throughout WC code
 * 
 * NOTE1. This is the way IBM uses it: "catentryId" but not "catEntryId"
 * http://pic.dhe.ibm.com/infocenter/wchelp/v7r0m0/topic/com.ibm.commerce.developer.doc/refs/rcacgcerd.htm
 * http://pic.dhe.ibm.com/infocenter/wchelp/v7r0m0/topic/com.ibm.commerce.customercare.doc/refs/rlhretp.htm
 * 
 * NOTE2. These constants are elaborated after studing the way IBM parces similar parameters. There is no one place exist where these
 * constants are gathered together, moreover, sometimes IBM is contradictive in the use of constants - storeId in one place and storeid in
 * another.
 * 
 * NOTE 3 IMPORTANT. These constants are NOT to be used to call IBM commands or services. These constants should be used to call OUR
 * commands and services, so these constants are under OUR control and responsibility to change.
 * 
 * @author a.nenko@sysiq.com
 */

public interface ACCommerceConstants {
    String STORE_ID_PARAM = "storeId";
    String LANG_ID_PARAM = "langId";
    String USER_ID_PARAM = "userId";
    String ORDER_ID_PARAM = "orderId";
    String ITEM_ID_PARAM = "itemId";
    String CATALOG_ID_PARAM = "catalogId";
    String CATGROUP_ID_PARAM = "catgroupId";
    String CATENTRY_ID_PARAM = "catentryId";

    String FIELD1 = "FIELD1";
    String FIELD2 = "FIELD2";
    String FIELD3 = "FIELD3";
    String FIELD4 = "FIELD4";
    String FIELD5 = "FIELD5";
}
