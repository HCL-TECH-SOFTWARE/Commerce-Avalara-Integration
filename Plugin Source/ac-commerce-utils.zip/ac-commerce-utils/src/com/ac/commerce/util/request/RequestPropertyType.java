package com.ac.commerce.util.request;

public enum RequestPropertyType {
    STRING, LONG;
}
