package com.ac.commerce.util;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import org.apache.commons.json.JSONObject;

import com.ibm.commerce.beans.DataBeanManager;
import com.ibm.commerce.command.CommandContext;
import com.ibm.commerce.common.beans.StoreCurrencyFormatDescriptionDataBean;
import com.ibm.commerce.common.objects.StoreAccessBean;
import com.ibm.commerce.component.contextservice.BusinessContextServiceFactory;
import com.ibm.commerce.component.contextserviceimpl.BusinessContextInternalService;
import com.ibm.commerce.context.baseimpl.ContextHelper;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.exception.ExceptionHandler;
import com.ibm.commerce.marketing.databeans.PromoCodeListDataBean;
import com.ibm.commerce.marketing.databeans.PromotionCodeData;
import com.ibm.commerce.order.beans.OrderAdjustmentDataBean;
import com.ibm.commerce.order.beans.OrderDataBean;
import com.ibm.commerce.order.facade.client.OrderException;
import com.ibm.commerce.order.objects.OrderItemAccessBean;
import com.ibm.commerce.payment.ppc.bean.commands.PPCListPIsForOrderCmd;
import com.ibm.commerce.payment.ppc.beans.PPCListPIsForOrderDataBean;
import com.ibm.commerce.price.beans.FormattedMonetaryAmountDataBean;
import com.ibm.commerce.price.utils.MonetaryAmount;
import com.ibm.commerce.ras.ECMessage;
import com.ibm.commerce.rest.utils.JSONUtil;
import com.ac.commerce.objects.helpers.OrderAccessBeans;
import com.ac.commerce.objects.helpers.options.OrderAccessBeanOption;
import com.ac.commerce.payment.objects.ACOrderPaymentsVO;
import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.exception.ACApplicationException;

/**
 * Utility class for getting order information
 *
 * @author s.bansal
 */
public final class ACOrderUtils {
    private static final String GIFT_CARD_PAYMENT_METHOD = "Gift Card";
    private static final ACLogger LOGGER = new ACLogger(ACOrderUtils.class);
    public final static NumberFormat format;

    static {
        format = NumberFormat.getInstance();
        format.setMaximumFractionDigits(2);
        format.setMinimumFractionDigits(2);
        // Utility class
    }

    /**
     * getOrderItemsForOrder method gets the orderitem information for the input orderId
     *
     * @param orderId
     * @return OrderItemAccessBean[]
     */
    @Nullable
    public static OrderItemAccessBean[] getOrderItemsForOrder(Long orderId) {
        String methodName = "getOrderItemsForOrder";
        LOGGER.entering(methodName, orderId);
        OrderAccessBeanOption orbean = OrderAccessBeans.optionBean(orderId);
        OrderItemAccessBean[] accessBean = orbean.isObjectDefined() ? orbean.getOrderItems() : null;
        LOGGER.exiting(methodName, accessBean);
        return accessBean;
    }

    /**
     * Returns list of payment instructions for the specified order
     *
     * @param orderId
     *            - order ID to select payment instructions
     * @param cmdContext
     *            - command context
     * @return - list of payment instructions
     * @throws ECException
     *             in case of exception
     */
    @SuppressWarnings("unchecked")
    public static List<com.ibm.commerce.payments.plugincontroller.PaymentInstruction> getPayInstrumentsForOrder(Long orderId,
        CommandContext cmdContext) throws ECException {
        String methodName = "getPayInstrumentsForOrder";
        LOGGER.entering(methodName);
        List<com.ibm.commerce.payments.plugincontroller.PaymentInstruction> payInstruments = new ArrayList<com.ibm.commerce.payments.plugincontroller.PaymentInstruction>();
        PPCListPIsForOrderDataBean ppcListPidataBean = new PPCListPIsForOrderDataBean();
        ppcListPidataBean.setStoreId(cmdContext.getStoreId().toString());
        ppcListPidataBean.setOrderId(orderId.toString());
        PPCListPIsForOrderCmd ppcListPIForSendCmd = (PPCListPIsForOrderCmd) com.ibm.commerce.command.CommandFactory.createCommand(
            ppcListPidataBean.getCommandInterfaceName(), cmdContext.getStoreId());
        ppcListPIForSendCmd.setCommandContext(cmdContext);
        ppcListPIForSendCmd.setDataBean(ppcListPidataBean);
        ppcListPIForSendCmd.execute();
        if (ppcListPidataBean.getPaymentInstructionList() != null) {
            payInstruments = ppcListPidataBean.getPaymentInstructionList();
        }

        LOGGER.exiting(methodName);
        return payInstruments;
    }

    /**
     * returns remaining payment amount for the order
     *
     * @param orderDataBean
     *            - order data bean which represents an order to get remaining amount
     * @param cmdContext
     *            - command context
     * @return FormattedMonetaryAmountDataBean
     */
    public static FormattedMonetaryAmountDataBean getCurrentPaymentAmountRemaining(OrderDataBean orderDataBean, CommandContext cmdContext) {
        String strMethod = "getCurrentPaymentAmountRemaining";
        FormattedMonetaryAmountDataBean formattedResult = null;
        BigDecimal result = new BigDecimal(0.00);
        try {
            FormattedMonetaryAmountDataBean totalRemaining = orderDataBean.getPaymentAmountRemaining();
            FormattedMonetaryAmountDataBean futureCharge = orderDataBean.getFormattedFutureTotal();
            result = result.add(totalRemaining.getAmount());
            if (futureCharge != null && futureCharge.getPrimaryPrice().getValue().doubleValue() > 0) {
                result = result.subtract(futureCharge.getAmount());
            }
            StoreAccessBean iStoreAB = new StoreAccessBean();
            iStoreAB.setInitKey_storeEntityId(orderDataBean.getStoreEntityId());
            formattedResult = new FormattedMonetaryAmountDataBean(new MonetaryAmount(result, orderDataBean.getCurrency()), iStoreAB,
                cmdContext.getLanguageId());
        } catch (Exception e) {
            LOGGER.error(strMethod, "Exception caught while getting current items remaining amount: " + e);
        }
        return formattedResult;
    }

    /**
     * Returns Map with the data regarding the order. Map represents information about total amount of an order, taxes, giftcard
     * transactions, adjustments
     *
     * @param ctx
     *            - command context
     * @param orderId
     *            - order ID to get order data
     * @return - map with the information about the order
     * @throws OrderException
     *             - in case of exception
     */
    public static Map<String, Object> getTotalOrderInfo(CommandContext ctx, Long orderId) throws OrderException {
        return getTotalOrderInfo(ctx, orderId, false);
    }

    /**
     * Returns Map with the data regarding the order. Map represents information about total amount of an order, taxes, giftcard
     * transactions, adjustments
     *
     * @param ctx
     *            - command context
     * @param orderId
     *            - order ID to get order data
     * @param skipACP
     *            - flag for check ACP policy or not
     * @return - map with the information about the order
     * @throws OrderException
     *             - in case of exception
     */
    public static Map<String, Object> getTotalOrderInfo(CommandContext ctx, Long orderId, Boolean skipACP) throws OrderException {
        final String METHOD_NAME = "getTotalOrderInfo";
        LOGGER.entering(METHOD_NAME);
        Map<String, Object> ret = new HashMap<String, Object>();

        try {
            /* new PaymentUtilsService(getCommandContext()).runOrderCalculateCmd(); */
        } catch (Exception e) {
            LOGGER.error(METHOD_NAME, e.getMessage(), e);
        }

        try {
            OrderDataBean orderDB = new OrderDataBean();
            orderDB.setOrderId(orderId.toString());
            if (!skipACP) {
                DataBeanManager.activate(orderDB, getCommandContext());
            } else {
                orderDB.setCommandContext(ctx);
                orderDB.populate();
            }

            BigDecimal totalProductDiscount = BigDecimal.ZERO;
            loadCurrency(getCommandContext(), ret);

            getOrderAdjustments(orderDB, ret);

            ret.put("subtotal", orderDB.getCurrentTotal());

            loadOrderItemAdjustments(orderDB, totalProductDiscount, ret);

            ret.put("tax", orderDB.getCurrentShippingTaxTotal());

            ret.put("shippingCharge", orderDB.getCurrentShippingCharge());

            ret.put("shippingTax", orderDB.getTotalShippingTaxInEntityType());

            BigDecimal giftCardAmountApplicableToInstock = loadGiftCardInstructions(getCommandContext(), orderDB, ret);

            BigDecimal totalValue = orderDB.getGrandTotal().getAmount();
            totalValue = totalValue.subtract(giftCardAmountApplicableToInstock);
            ret.put("totalValue", totalValue);

            loadPromotions(getCommandContext(), orderId, ret);

        } catch (Exception e) {
            LOGGER.error(METHOD_NAME, "Exception occured while getting order data: " + ExceptionHandler.convertStackTraceToString(e));
            throw new OrderException("Exception occured while getting order data", e.getMessage());
        }
        return ret;
    }

    protected static CommandContext getCommandContext() {
        CommandContext commandContext = null;
        com.ibm.commerce.component.contextservice.ActivityToken newToken = ((BusinessContextInternalService) BusinessContextServiceFactory
            .getBusinessContextService()).getActivityToken();
        commandContext = ContextHelper.createCommandContext(newToken);
        return commandContext;
    }

    /**
     * Loads promotions for the order and adds them to the Map parameter ret
     *
     * @param ctx
     *            - command context
     * @param orderId
     *            - order ID to load promotions
     * @param ret
     *            - map to add promotions information
     * @throws Exception
     *             - in case of exception
     */
    public static void loadPromotions(CommandContext ctx, Long orderId, Map<String, Object> ret) throws Exception {
        final String METHOD_NAME = "loadPromotions";
        LOGGER.entering(METHOD_NAME);
        PromoCodeListDataBean promoCodeList = new PromoCodeListDataBean();
        promoCodeList.setCommandContext(ctx);
        promoCodeList.setOrderId(orderId);
        promoCodeList.populate();

        List<JSONObject> promoCodes = new ArrayList<JSONObject>();
        if (null != promoCodeList.getCodes() && promoCodeList.getCodes().length > 0) {
            for (PromotionCodeData promoCodeData : promoCodeList.getCodes()) {
                Map<String, Object> promoCode = new HashMap<String, Object>();
                promoCode.put("code", promoCodeData.getCode());
                promoCode.put("descArray", promoCodeData.getDescArray());
                promoCode.put("description", promoCodeData.getDescription());
                JSONObject jsonObj = JSONUtil.createJSONObject(promoCode);
                promoCodes.add(jsonObj);
            }
        }
        ret.put("promoCodes", promoCodes);
        LOGGER.exiting(METHOD_NAME);
    }

    /**
     * loads payment instructions for gift card payments and total amount paid with gift cards
     *
     * @param ctx
     *            - command context
     * @param orderId
     *            - order ID to load gift card information
     * @param ret
     *            - map to add payment information regarding gift card transactions
     * @throws OrderException
     */
    public static BigDecimal loadGiftCardInstructions(CommandContext ctx, OrderDataBean orderDb, Map<String, Object> ret)
    throws OrderException {
        final String METHOD_NAME = "loadGiftCardInstructions";
        BigDecimal giftCardAmountApplicableToInstock = BigDecimal.ZERO;
        LOGGER.entering(METHOD_NAME);
        try {
            List<ACOrderPaymentsVO> giftCardPaymentTransactions = getGiftCardPaymentTransactions(orderDb, ctx);
            List<Map<String, Object>> giftCardPaymentTransactionsArr = new ArrayList<Map<String, Object>>();
            if (null != giftCardPaymentTransactions && giftCardPaymentTransactions.size() > 0) {
                for (ACOrderPaymentsVO payment : giftCardPaymentTransactions) {
                    Map<String, Object> map = new HashMap<String, Object>();
                    map.put("paymentAccount", payment.getPaymentAccount());
                    map.put("primaryPrice", payment.getFormattedPaymentAmount().getPrimaryPrice().getValue());
                    map.put("paymentInstructionId", payment.getPaymentInstructionId());
                    giftCardPaymentTransactionsArr.add(map);
                    giftCardAmountApplicableToInstock = giftCardAmountApplicableToInstock
                    .add(BigDecimal.valueOf(payment.getPaymentAmount()));
                }
            }
            ret.put("giftCardPaymentTransactions", giftCardPaymentTransactionsArr);

        } catch (Exception e) {
            throw new OrderException("INVALID_PARAMETER_VALUE", e.getMessage());
        }
        ret.put("giftCardAmountApplicableToInstock", giftCardAmountApplicableToInstock);
        LOGGER.exiting(METHOD_NAME);
        return giftCardAmountApplicableToInstock;
    }

    /**
     * loads current currency code from the command context and puts this value to the parameter Map
     *
     * @param ctx
     *            - command context
     * @param ret
     *            - Map to add currenct parameter
     */
    public static void loadCurrency(CommandContext ctx, Map<String, Object> ret) {
        final String METHOD_NAME = "loadCurrency";
        LOGGER.entering(METHOD_NAME);
        try {
            StoreCurrencyFormatDescriptionDataBean currency = new StoreCurrencyFormatDescriptionDataBean();
            currency.setCommandContext(ctx);
            currency.setNumberUsage("-1");
            currency.setLangId(ctx.getLanguageId().toString());
            currency.setStoreId(ctx.getStoreId().toString());
            currency.setCurrencyCode(ctx.getCurrency());
            currency.populate();

            ret.put("currency", currency.getCurrencySymbol());
        } catch (Exception e) {
            LOGGER.error(METHOD_NAME, e.getMessage(), e);
        }
        LOGGER.exiting(METHOD_NAME);
    }

    /**
     * Load order adjustments
     *
     * @param orderDB
     *            - order data bean which represents data about current order
     * @param totalProductDiscount
     *            - total product discount value
     * @param ret
     *            - Map to add information
     * @throws RemoteException
     * @throws CreateException
     * @throws FinderException
     * @throws NamingException
     */
    public static void loadOrderItemAdjustments(OrderDataBean orderDB, BigDecimal totalProductDiscount, Map<String, Object> ret)
    throws RemoteException, CreateException, FinderException, NamingException {
        final String METHOD_NAME = "loadOrderItemAdjustments";
        LOGGER.entering(METHOD_NAME);

        OrderAdjustmentDataBean[] adjustments = orderDB.getOrderAdjustmentDataBeans();
        if (adjustments != null) {
            for (OrderAdjustmentDataBean adjustment : adjustments) {
                OrderAdjustmentDataBean adjustmentBean = adjustments[0];
                if (adjustmentBean.getDisplayLevel().toString().equals("OrderItem")) {
                    totalProductDiscount = totalProductDiscount.add(adjustmentBean.getAmountInEntityType());
                }
            }
            // end totalProductDiscount

            ret.put("totalProductDiscount", totalProductDiscount);

            // totalOrderDiscount
            BigDecimal totalOrderDiscount = BigDecimal.ZERO;
            totalOrderDiscount = orderDB.getTotalAdjustmentInEntityType().subtract(totalProductDiscount);
            ret.put("totalOrderDiscount", totalOrderDiscount);
            // end totalOrderDiscount
        }
        LOGGER.exiting(METHOD_NAME);
    }

    /**
     * loads order adjustments
     *
     * @param orderDB
     *            - order data bean which represents an order for getting adjustment
     * @param ret
     *            - Map to add information regarding adjustments
     * @throws RemoteException
     * @throws CreateException
     * @throws FinderException
     * @throws NamingException
     */
    public static void getOrderAdjustments(OrderDataBean orderDB, Map<String, Object> ret) throws RemoteException, CreateException,
    FinderException, NamingException {
        final String METHOD_NAME = "getOrderAdjustments";
        LOGGER.entering(METHOD_NAME);
        List<JSONObject> jsonAdjustmentList = new ArrayList<JSONObject>();
        OrderAdjustmentDataBean[] adjustments = orderDB.getOrderAdjustmentDataBeans();
        if (adjustments != null && adjustments.length > 0) {
            OrderAdjustmentDataBean adjustmentBean = adjustments[0];
            if (adjustmentBean.getDisplayLevel().equals("Order")) {
                Map<String, Object> map = new HashMap<String, Object>();
                map.put("description", adjustmentBean.getDescriptionString());
                map.put("price", adjustmentBean.getAmount());
                JSONObject jsonObj = JSONUtil.createJSONObject(map);
                jsonAdjustmentList.add(jsonObj);
            }
        }

        ret.put("adjustments", jsonAdjustmentList);
        LOGGER.exiting(METHOD_NAME);
    }

    public static List<ACOrderPaymentsVO> getGiftCardPaymentTransactions(Long orderId, CommandContext ctx) throws ACApplicationException {
        try {
            OrderDataBean orderDB = new OrderDataBean();
            orderDB.setOrderId(orderId.toString());

            DataBeanManager.activate(orderDB, ctx);
            return getGiftCardPaymentTransactions(orderDB, ctx);
        } catch (Exception e) {
            throw new ACApplicationException(ECMessage._ERR_OBJECTS_CANT_LOAD, ACOrderUtils.class.getName(),
            "getGiftCardPaymentTransactions");
        }
    }

    /**
     * returns payment transactions regarding gift card payment methods
     *
     * @param orderId
     *            - order ID to load gift card payment transaction
     * @param ctx
     *            - command context
     * @return - list of objects with the information regarding gift cards payments
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    public static List<ACOrderPaymentsVO> getGiftCardPaymentTransactions(OrderDataBean orderDB, CommandContext ctx) throws Exception {
        final String METHOD_NAME = "getGiftCardPaymentTransactions";
        LOGGER.entering(METHOD_NAME);
        List<ACOrderPaymentsVO> giftCardPayments = new ArrayList<ACOrderPaymentsVO>();

        OrderDataBean.PaymentInstruction[] payInstructions = orderDB.getPaymentInstructions();
        for (OrderDataBean.PaymentInstruction edpPayInst : payInstructions) {
            edpPayInst.getPaymentInstruction().getId();
            Map extendedDataMap = edpPayInst.getPaymentInstruction().getProtocolData();
            String extendedDataAccount = (String) extendedDataMap.get("account");
            String paymentMethod = (String) extendedDataMap.get("payment_method");
            BigDecimal amount = edpPayInst.getPaymentInstruction().getAmount();
            String piId = edpPayInst.getPaymentInstruction().getId().toString();

            if (paymentMethod != null && paymentMethod.equals(GIFT_CARD_PAYMENT_METHOD)) {
                ACOrderPaymentsVO paymentsVO = new ACOrderPaymentsVO();
                paymentsVO.setPaymentMethod(paymentMethod);
                paymentsVO.setPaymentAccount(extendedDataAccount);
                paymentsVO.setPaymentAmount(amount.doubleValue());
                paymentsVO.setPaymentInstructionId(piId);

                FormattedMonetaryAmountDataBean formattedAmount = new FormattedMonetaryAmountDataBean(new MonetaryAmount(amount,
                    ctx.getCurrency()), ctx.getStore(), ctx.getLanguageId());
                paymentsVO.setFormattedPaymentAmount(formattedAmount);

                giftCardPayments.add(paymentsVO);
            }
        }

        LOGGER.exiting(METHOD_NAME);
        return giftCardPayments;
    }

    /**
     * Returns total amount paid with gift cards for the order
     *
     * @param orderId
     *            - order ID which represents current order
     * @param ctx
     *            - command context
     * @return - FormattedMonetaryAmountDataBean
     * @throws Exception
     *             if any error occur
     */
    public static FormattedMonetaryAmountDataBean getGiftCardsTotalAmount(Long orderId, CommandContext ctx) throws Exception {
        final String METHOD_NAME = "getGiftCardsTotalAmount";
        LOGGER.entering(METHOD_NAME);
        FormattedMonetaryAmountDataBean formattedResult = null;
        OrderDataBean orderDB = new OrderDataBean();
        orderDB.setOrderId(orderId.toString());
        DataBeanManager.activate(orderDB, ctx);
        List<ACOrderPaymentsVO> giftCardTransactions = getGiftCardPaymentTransactions(orderDB, ctx);
        BigDecimal totalAmount = BigDecimal.valueOf(0.0);
        for (ACOrderPaymentsVO payment : giftCardTransactions) {
            totalAmount = totalAmount.add(BigDecimal.valueOf(payment.getPaymentAmount()));
        }
        try {
            formattedResult = new FormattedMonetaryAmountDataBean(new MonetaryAmount(totalAmount, ctx.getCurrency()), ctx.getStore(),
                ctx.getLanguageId());
        } catch (Exception e) {
            LOGGER.error(METHOD_NAME, "Exception caught while getting gift cards amount: " + e);
        }
        LOGGER.exiting(METHOD_NAME);
        return formattedResult;
    }

    /***
     * Returns orderId for orderItem
     *
     * @param orderItemId
     *
     * @return - orderId
     * @throws FinderException
     * @throws NamingException
     * @throws RemoteException
     * @throws NumberFormatException
     * @throws CreateException
     */
    public static String getOrderIdForOrderItem(String orderItemId) throws NumberFormatException, RemoteException, NamingException,
        FinderException, CreateException {
        final String methodName = "getOrderIdForOrderItem";
        LOGGER.entering(methodName, orderItemId);
        Long[] orderItemIds = new Long[] { Long.parseLong(orderItemId) };
        OrderItemAccessBean oiab = new OrderItemAccessBean();
        oiab.setInitKey_orderItemId(orderItemId);
        oiab.instantiateEntity();
        LOGGER.exiting(methodName, oiab.getOrderId());
        return oiab.getOrderId();
    }
}
