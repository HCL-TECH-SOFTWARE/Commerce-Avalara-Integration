package com.ac.commerce.util;

import java.util.List;

import com.ibm.commerce.order.facade.datatypes.PaymentInstructionType;
import com.ibm.commerce.order.facade.datatypes.ProtocolDataType;
import com.ibm.commerce.payments.plugin.PaymentInstruction;
import com.ac.util.Option;

public final class PaymentInstructions {
    private PaymentInstructions() {
        // Utility class
    }

    public static final Option<String> getExtendedData(PaymentInstruction instr, String key) {
        return Option.of(instr.getExtendedData().getString(key));
    }

    public static final String getValue(PaymentInstructionType type, String key, String def) {
        List<ProtocolDataType> data = type.getProtocolData();
        for (ProtocolDataType value : data) {
            if (value.getName().equals(key)) {
                return value.getValue() == null ? def : value.getValue();
            }
        }
        return def;
    }
}
