package com.ac.commerce.util;

// Commented due to code duplication in SIAddressUtils
/*import static com.ibm.commerce.member.constants.ECMemberCommandParameterConstants.EC_ADDR_BILLING;
import static com.ibm.commerce.member.constants.ECMemberCommandParameterConstants.EC_ADDR_PERMANENT;
import static com.ibm.commerce.member.constants.ECMemberCommandParameterConstants.EC_ADDR_SHIPPINGBILLING;
import static com.ibm.commerce.member.constants.ECMemberCommandParameterConstants.EC_USER_REGISTERED_SHOPPER;
import static org.apache.commons.lang.StringUtils.isNotEmpty;

import java.util.List;

import javax.annotation.Nonnull;

import com.ibm.commerce.user.objects.AddressAccessBean;
import com.sysiq.commerce.objects.helpers.AccessBeansHandler;
import com.sysiq.commerce.objects.helpers.AddressAccessBeans;
import com.sysiq.commerce.objects.helpers.OrderAccessBeans;
import com.sysiq.commerce.objects.helpers.UserAccessBeans;
import com.sysiq.commerce.objects.helpers.options.AddressAccessBeanOption;
import com.sysiq.commerce.objects.helpers.options.OrderAccessBeanOption;
import com.sysiq.commerce.objects.helpers.options.UserAccessBeanOption;
import com.sysiq.util.Option;
import com.sysiq.util.exception.SIRuntimeException;

public final class SIUserUtils {

    private SIUserUtils() {
        // Utility class
    }

    public static AddressAccessBeanOption getAddressForOrder(String orderId) {
        return getAddressForOrder(OrderAccessBeans.optionBean(orderId));
    }

    public static AddressAccessBeanOption getAddressForMemmber(Long memberId) {
        return getAddressForMemmber(memberId, null);
    }

    public static AddressAccessBeanOption getAddressForOrder(OrderAccessBeanOption orderBean) {
        Option<Long> memberId = orderBean.getMemberIdInEJBType();
        return getAddressForMemmber(memberId.getOrElse(Long.valueOf(-100)), orderBean);
    }

    @Nonnull
    public static AddressAccessBeanOption getAddressForMemmber(Long memberId, OrderAccessBeanOption orderBean) {
        AddressAccessBeanOption selfAddressBean = AccessBeansHandler.createProxy(new AddressAccessBean(), AddressAccessBeanOption.class);
        selfAddressBean = selfAddressBean.findSelfAddressByMember(memberId);
        if (selfAddressBean.isObjectDefined()) {
            return selfAddressBean;
        }

        UserAccessBeanOption userBean = UserAccessBeans.optionBean(Option.of(memberId));
        if (!userBean.isObjectDefined()) {
            throw new SIRuntimeException("User cannot be found");
        }
        // If user is registered user then he should have self address
        if (userBean.getRegisterType().getOrElse("").equals(EC_USER_REGISTERED_SHOPPER)) {
            throw new SIRuntimeException("User cannot be registered shopper");
        }

        // If there is a billing address we will send the billing address

        if (orderBean.getAddressId().isDefined() && isNotEmpty(orderBean.getAddressId().get())) {
            String billingAddressId = orderBean.getAddressId().get();
            selfAddressBean = AddressAccessBeans.optionBean(billingAddressId);
        } else {
            // Get all address and treat the last billing or shippingbilling
            // address as self address
            // As there is no order by just getting all address and
            // iterating through them for finding
            // the last address
            List<AddressAccessBeanOption> list = selfAddressBean.findByMemberId(memberId);
            for (AddressAccessBeanOption temp : list) {
                Option<String> status = temp.getStatus();
                Option<String> addressType = temp.getAddressType();
                if (status.isDefined() && addressType.isDefined() && status.get().equals(EC_ADDR_PERMANENT)
                    && (addressType.get().equals(EC_ADDR_BILLING) || addressType.get().equals(EC_ADDR_SHIPPINGBILLING))) {
                    selfAddressBean = temp;
                }
            }
        }

        return selfAddressBean;
    }
}*/
