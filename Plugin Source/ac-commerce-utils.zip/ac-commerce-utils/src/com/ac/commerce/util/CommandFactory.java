package com.ac.commerce.util;

import com.ibm.commerce.command.CommandContext;
import com.ibm.commerce.command.ControllerCommand;
import com.ibm.commerce.command.TaskCommand;
import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.exception.ECException;

public final class CommandFactory {
    private CommandFactory() {
        // Utility class
    }

    @SuppressWarnings("unchecked")
    public static <T extends ControllerCommand> T createCommand(Class<T> clazz, Integer storeId) throws ECException {
        return (T) com.ibm.commerce.command.CommandFactory.createCommand(clazz.getName(), storeId);
    }

    @SuppressWarnings("unchecked")
    public static <T extends TaskCommand> T createTask(Class<T> clazz, Integer storeId) throws ECException {
        return (T) com.ibm.commerce.command.CommandFactory.createCommand(clazz.getName(), storeId);
    }

    public static <T extends TaskCommand> T createTask(Class<T> clazz, CommandContext context) throws ECException {
        T ret = createTask(clazz, context.getStoreId());
        ret.setCommandContext(context);
        return ret;
    }

    public static <T extends ControllerCommand> T createCommand(Class<T> clazz, CommandContext context) throws ECException {
        T ret = createCommand(clazz, context.getStoreId());
        ret.setCommandContext(context);
        return ret;
    }

    public static <T extends ControllerCommand> T createCommand(Class<T> clazz, CommandContext context, TypedProperty props)
        throws ECException {
        T ret = createCommand(clazz, context);
        ret.setRequestProperties(props);
        return ret;
    }

}
