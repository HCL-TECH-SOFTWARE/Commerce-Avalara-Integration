/**
 * 
 */
package com.ac.commerce.util.configuration;

/**
 * @author a.kudla
 * 
 */
interface ACPropertyManagerCmd {
    final String defaultCommandClassName = ACPropertyManagerCmd.class.getName();
}
