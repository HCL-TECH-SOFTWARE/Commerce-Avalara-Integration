package com.ac.commerce.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.IOUtils;

import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.IOStreams;

public final class ZIPUtility {

    private static final ACLogger LOGGER = new ACLogger(ZIPUtility.class);
    public static final int BUFFER_SIZE = 2048;

    private ZIPUtility() {
        // Utility class
    }

    // This function converts the zip file into uncompressed files which are
    // placed in the
    // destination directory
    // destination directory should be created first
    public static boolean unzipFiles(String srcDirectory, String srcFile, String destDirectory) {
        final String methodName = "unzipFiles";
        LOGGER.entering(methodName);

        LOGGER.trace(methodName, "Validate input parameters");

        // first make sure that all the arguments are valid and not null
        if (srcDirectory == null || "".equals(srcDirectory)) {
            LOGGER.error(methodName, "Validation error: srcDirectory is required");
            return false;
        }
        if (srcFile == null || "".equals(srcFile)) {
            LOGGER.error(methodName, "Validation error: srcFile is required");
            return false;
        }
        if (destDirectory == null || "".equals(destDirectory)) {
            LOGGER.error(methodName, "Validation error: destDirectory is required");
            return false;
        }

        LOGGER.trace(methodName, "Validation successful");

        // now make sure that these directories exist
        File sourceDirectory = new File(srcDirectory);
        File sourceFile = new File(srcDirectory + File.separator + srcFile);
        File destinationDirectory = new File(destDirectory);

        LOGGER.trace(methodName, "Validate resources");
        if (!sourceDirectory.exists()) {
            LOGGER.error(methodName, "Source directory not found");
            return false;
        }
        if (!sourceFile.exists()) {
            LOGGER.error(methodName, "Source file not found");
            return false;
        }
        if (!destinationDirectory.exists()) {
            LOGGER.error(methodName, "Destination directory not found");
            return false;
        }

        LOGGER.trace(methodName, "Validation successful");

        ZipEntry entry = null;
        ZipInputStream zis = null;
        try {
            // now start with unzip process
            LOGGER.trace(methodName, "Open input stream for " + sourceDirectory);
            FileInputStream fis = new FileInputStream(sourceFile);
            LOGGER.trace(methodName, "Open zip input stream for " + sourceDirectory);
            zis = new ZipInputStream(new BufferedInputStream(fis));

            LOGGER.trace(methodName, "Begin unzip");
            while ((entry = zis.getNextEntry()) != null) {
                String outputFilename = destDirectory + File.separator + entry.getName();

                LOGGER.trace(methodName, "Extracting file: " + entry.getName());

                LOGGER.trace(methodName, "Check directory if exists");
                createDirIfNeeded(destDirectory, entry);
                writeDataToDisk(zis, outputFilename);
            }

            LOGGER.trace(methodName, "Unzip successfully finished");
        } catch (IOException e) {
            LOGGER.error(methodName, "Unzip error:", e);
            return false;
        } finally {
            IOStreams.close(zis);
        }

        LOGGER.exiting(methodName);
        return true;
    }

    private static void writeDataToDisk(ZipInputStream zis, String outputFilename) {
        String methodName = "writeDataToDisk";
        // write the file to the disk
        FileOutputStream fos = null;
        BufferedOutputStream dest = null;
        try {
            fos = new FileOutputStream(outputFilename);
            dest = new BufferedOutputStream(fos, BUFFER_SIZE);
            LOGGER.trace(methodName, "Write unzipped file " + outputFilename);
            IOUtils.copyLarge(zis, dest);
            dest.flush();

        } catch (IOException ex) {
            LOGGER.error(methodName, "Exception while saving data to " + outputFilename);
        } finally {
            IOStreams.close(dest);
            IOStreams.close(fos);
        }
        LOGGER.trace(methodName, "Unzipped successfully for file " + outputFilename);
    }

    private static void createDirIfNeeded(String destDirectory, ZipEntry entry) {
        final String methodName = "createDirIfNeeded";
        LOGGER.entering(methodName);

        String name = entry.getName();

        LOGGER.trace(methodName, "Check path");
        if (name.contains("/")) {
            LOGGER.trace(methodName, "Directory not exists");

            int index = name.lastIndexOf('/');
            String dirSequence = name.substring(0, index);
            String path = destDirectory + File.separator + dirSequence;

            LOGGER.trace(methodName, "Create directory " + path);
            File newDirs = new File(path);

            // create the directory
            if (newDirs.mkdirs()) {
                LOGGER.trace(methodName, "Successfully create directory " + path);
            } else {
                LOGGER.error(methodName, "Directory creation faild " + path);
            }
        }

        LOGGER.exiting(methodName);
    }

}