package com.ac.commerce.util;

import static com.ibm.commerce.member.constants.ECMemberCommandParameterConstants.EC_USER_REGISTERED_SHOPPER;
import static org.apache.commons.lang.StringUtils.isNotEmpty;

import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.List;

import javax.annotation.Nonnull;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;
import javax.persistence.NoResultException;

import com.ibm.commerce.order.objects.OrderAccessBean;
import com.ibm.commerce.user.helpers.ECUserConstants;
import com.ibm.commerce.user.objects.AddressAccessBean;
import com.ibm.commerce.user.objects.UserAccessBean;
import com.ac.commerce.objects.helpers.AddressAccessBeans;
import com.ac.commerce.objects.helpers.OrderAccessBeans;
import com.ac.commerce.objects.helpers.UserAccessBeans;
import com.ac.commerce.objects.helpers.options.OrderAccessBeanOption;
import com.ac.commerce.objects.helpers.options.UserAccessBeanOption;
import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.Collections;
import com.ac.util.None;
import com.ac.util.Option;

/**
 * Utility class for fetching address information
 * 
 * @author v.potaychuk
 */
public final class ACAddressUtils {

    private final static ACLogger LOGGER = new ACLogger(ACAddressUtils.class);

    private ACAddressUtils() {
        // Utility class
    }

    public static Option<AddressAccessBean> getAddressForOrder(String orderId) {
        final String methodName = "";
        LOGGER.entering(methodName, orderId);
        OrderAccessBeanOption orderBean = OrderAccessBeans.optionBean(orderId);
        Option<AddressAccessBean> ret = getAddressForOrder(orderBean);
        LOGGER.exiting(methodName, ret);
        return ret;
    }

    public static Option<AddressAccessBean> getAddressForOrder(@Nonnull OrderAccessBeanOption orderBean) {
        Option<Long> memberId = orderBean.getMemberIdInEntityType();
        return getAddressForMember(memberId, orderBean);
    }

    public static Option<AddressAccessBean> getAddressForMember(Option<Long> memberId, @Nonnull OrderAccessBeanOption orderBean) {
        Option<AddressAccessBean> selfAddressBean = AddressAccessBeans.findSelfAddressByMember(memberId);
        if (selfAddressBean.isDefined()) {
            return AddressAccessBeans.findSelfAddressByMember(memberId);
        }
        UserAccessBeanOption userBean = UserAccessBeans.optionBean(memberId);

        if (userBean.getRegisterType().getOrElse("").equals(EC_USER_REGISTERED_SHOPPER)) {
            return None.instance();
        }

        if (isNotEmpty(orderBean.getAddressId().getOrElse(""))) {
            return AddressAccessBeans.bean(orderBean.getAddressId());
        }

        List<AddressAccessBean> addresses = AddressAccessBeans.findByMemberId(memberId);

        selfAddressBean = Collections.find(addresses, AddressAccessBeans.STATUS.in("P", "B", "SB"));
        return selfAddressBean;
    }
    
    public static AddressAccessBean getAddressForMemmber(Long memberId) throws RemoteException, CreateException, FinderException, NamingException {
        return getAddressForMemmber(memberId, null);
    }
    
    // TODO: v.potaychuk@sysiq.com need create single 
    /**
     * v.potaychuk: I've added this method because previous one is not working (public static Option<AddressAccessBean> getAddressForMember(Option<Long> memberId, @Nonnull OrderAccessBeanOption orderBean))
     */
    public static AddressAccessBean getAddressForMemmber(Long memberId, OrderAccessBean orderBean) throws RemoteException, CreateException, FinderException, NamingException
    {
        AddressAccessBean selfAddressBean = new AddressAccessBean();

         try {
                selfAddressBean = selfAddressBean.findSelfAddressByMember(memberId);
            } catch (NoResultException e) {
                 UserAccessBean userBean = new UserAccessBean();
                 userBean.setInitKey_memberId(memberId.toString());
                 userBean.instantiateEntity();
                 // If user is registered user then he should have self address
                 if ( userBean.getRegisterType().equals(ECUserConstants.EC_USER_REGISTERED_SHOPPER))
                     throw e;
                 
                 // If there is a billing address we will send the billing address

                 if (orderBean != null &&  orderBean.getAddressId() != null && orderBean.getAddressId().trim().length() > 0 )
                 {
                     String billingAddressId = orderBean.getAddressId();                     
                     selfAddressBean = new AddressAccessBean();
                     selfAddressBean.setInitKey_addressId(billingAddressId);
                     selfAddressBean.instantiateEntity();
                 }
                 else
                 {
                     // Get all address and treat the last billing or shippingbilling address as self address
                     // As there is no order by just getting all address and iterating through them for finding 
                     // the last address
                     selfAddressBean = new AddressAccessBean();
                     Enumeration enum1 = selfAddressBean.findByMemberId(memberId);
                     while (enum1.hasMoreElements())
                     {
                          AddressAccessBean tempAddressBean =  (AddressAccessBean) enum1.nextElement();
                          if(tempAddressBean.getStatus().equals(ECUserConstants.EC_ADDR_PERMANENT) && ( tempAddressBean.getAddressType().equals(ECUserConstants.EC_ADDR_BILLING) 
                              || tempAddressBean.getAddressType().equals(ECUserConstants.EC_ADDR_SHIPPINGBILLING)))
                          {
                              selfAddressBean = tempAddressBean;
                          }
                     }
                 }
            }
        return selfAddressBean;
    }
}
