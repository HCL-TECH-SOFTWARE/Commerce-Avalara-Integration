package com.ac.commerce.util.configuration;

import java.util.Locale;
import java.util.Properties;
import java.util.Set;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * This is a helper class to fetch messages from properties files
 * 
 */
public interface ACPropertyLoader {

    /**
     * Return message from properties file
     * 
     * @param resourceBundleName
     *            property file name
     * @param messageKey
     *            message key in property file
     * @return message
     */
    @Nullable
    String getString(String resourceBundleName, String messageKey);

    /**
     * Return property from properties file
     * 
     * @param resourceBundleName
     *            property file name
     * @param storeName
     *            store name or store ID
     * @param messageKey
     *            message key in property file
     * @return message
     */
    int getInt(String resourceBundleName, String storeName, String messageKey);

    /**
     * Return property from properties file
     * 
     * @param resourceBundleName
     *            property file name
     * @param messageKey
     *            message key in property file
     * @return message
     */
    int getInt(String resourceBundleName, String messageKey);

    /**
     * Return integer value from properties file
     * 
     * @param resourceBundleName
     *            property file name
     * @param key
     *            value key in property file
     * @param defaultValue
     *            default value
     * @return boolean value
     */
    int getInt(String resourceBundleName, String key, int defaultValue);

    /**
     * Return message from properties file
     * 
     * @param resourceBundleName
     *            property file name
     * @param storeName
     *            store name or store ID
     * @param messageKey
     *            message key in property file
     * @return message
     */
    @Nullable
    String getString(String resourceBundleName, String storeName, String messageKey);

    /**
     * Return boolean value from properties file
     * 
     * @param resourceBundleName
     *            property file name
     * @param key
     *            value key in property file
     * @return boolean value
     */
    boolean getBoolean(String resourceBundleName, String key);

    /**
     * Return boolean value from properties file
     * 
     * @param resourceBundleName
     *            property file name
     * @param storeName
     *            store name or store ID
     * @param key
     *            value key in property file
     * @return boolean value
     */
    boolean getBoolean(String resourceBundleName, String storeName, String key);

    /**
     * Return localized message from property file.
     * 
     * @param resourceBundleName
     *            property file name
     * @param storeName
     *            store name or store ID
     * @param messageKey
     *            message key in property file
     * @param locale
     *            locale object (can be null)
     * @param args
     *            arguments (can be null)
     * @return localized message
     */
    @Nullable
    String getLocalizedMessage(String resourceBundleName, String storeName, String messageKey, Locale locale, Object... args);

    @Nonnull
    String getPropertyFileName(String resourcePath, String storeName);

    @Nonnull
    String getPropertyFileName(String resourcePath, String storeName, Locale locale);

    @Nonnull
    Properties getProperties(String fileName);

    @Nonnull
    Properties getProperties(String fileName, String storeName);

    @Nonnull
    Properties getProperties(String fileName, String storeName, Locale locale);

    /**
     * Returns all keys associated with properties cache entries
     * 
     * @return set of keys
     */
    @Nonnull
    Set<String> getPropertiesCacheKeys();

    /**
     * Clears all entries in properties and resource bundles caches
     */
    void clearCaches();

    /**
     * Removes entry from bundle and properties caches
     * 
     * @param key
     *            entry key
     * @return true if entry exists and then was removed
     */
    boolean clearCacheEntry(String key);

    /**
     * Puts a value to a properties cache specified by a key
     * 
     * @param key
     *            property key
     * @param value
     *            value to put
     * @param cacheKey
     *            properties entry key
     * @return
     */
    boolean putPropertyToCache(String key, String value, String cacheKey);

    /**
     * Return boolean value from properties file
     * 
     * @param resourceBundleName
     *            property file name
     * @param key
     *            value key in property file
     * @param defaultValue
     *            default value
     * @return boolean value
     */
    boolean getBoolean(String resourceBundleName, String key, boolean defaultValue);
}
