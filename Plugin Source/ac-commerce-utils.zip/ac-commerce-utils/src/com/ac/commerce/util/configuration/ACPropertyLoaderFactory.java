package com.ac.commerce.util.configuration;

/**
 * Factory is used to instantiate {@link ACPropertyLoader}. Creates implementation based on selected configuration store e.g. property
 * files, database or whatever
 * 
 */
public final class ACPropertyLoaderFactory {

    private static class SIPropertyLoaderHolder {
        private static final ACPropertyLoader INSTANCE = new ACPropertyLoaderFileImpl();
    }

    private ACPropertyLoaderFactory() {
    }

    public static ACPropertyLoader getInstance() {
        return SIPropertyLoaderHolder.INSTANCE;
    }
}
