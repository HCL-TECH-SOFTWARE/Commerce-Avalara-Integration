package com.ac.commerce.util.request;

import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.LOCAL_VARIABLE;
import static java.lang.annotation.ElementType.PARAMETER;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ FIELD, PARAMETER, CONSTRUCTOR, LOCAL_VARIABLE })
@Retention(RetentionPolicy.RUNTIME)
public @interface RequestProperty {
    String value();

    // TODO v.mykhailov issue with incompatible types. DO NOT REMOVE package. Bug report - http://bugs.sun.com/view_bug.do?bug_id=6512707
    // also see http://stackoverflow.com/questions/1425088/incompatible-types-found-required-default-enums-in-annotations
    RequestPropertyType type() default com.ac.commerce.util.request.RequestPropertyType.STRING;

    String defaultValue() default NULL;

    public static final String NULL = "THIS IS A SPECIAL NULL VALUE - DO NOT USE";
}
