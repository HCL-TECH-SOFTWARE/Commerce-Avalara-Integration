package com.ac.commerce.util;

import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;

import javax.annotation.Nonnull;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import com.ibm.commerce.catalog.objects.CatalogGroupAccessBean;
import com.ibm.commerce.catalog.objects.CatalogGroupCatalogEntryRelationAccessBean;
import com.ibm.commerce.catalog.objects.ProductAccessBean;
import com.ibm.commerce.catalog.objects.StoreCatalogAccessBean;
import com.ac.commerce.util.logging.ACLogger;

/**
 * Utility class for fetching catentry information
 *
 * @author v.mykhailov
 */
public final class ACCatEntryUtils {

    private final static ACLogger LOGGER = new ACLogger(ACCatEntryUtils.class);
    private final static String MASTER_CATALOG_SIGN = "1";

    private ACCatEntryUtils() {
        // Utility class
    }

    @SuppressWarnings("unchecked")
    @Nonnull
    public static Set<String> getCatEntryCategoryNames(@Nonnull Long catEntryId) {
        String methodName = "getCatEntryCategoryNames";
        LOGGER.entering(methodName, catEntryId);

        Set<String> categories = new HashSet<String>();
//        try {
            ProductAccessBean pab = new ProductAccessBean();
            pab = pab.findByItem(catEntryId);
            Long productId = Long.valueOf(pab.getCatalogEntryReferenceNumber());

            CatalogGroupCatalogEntryRelationAccessBean catGpEnRel = new CatalogGroupCatalogEntryRelationAccessBean();
            Enumeration<CatalogGroupCatalogEntryRelationAccessBean> catGroupCatEntryRels = catGpEnRel.findByCatalogEntryId(productId);
            while (catGroupCatEntryRels.hasMoreElements()) {
                CatalogGroupCatalogEntryRelationAccessBean curCatalog = catGroupCatEntryRels.nextElement();
                Enumeration<StoreCatalogAccessBean> storeCatalogAb = new StoreCatalogAccessBean().findByCatalogId(Long.valueOf(curCatalog
                    .getCatalogId()));

                if (!storeCatalogAb.nextElement().getMasterCatalog().equalsIgnoreCase(MASTER_CATALOG_SIGN)) {
                    String catId = curCatalog.getCatalogGroupId();
                    CatalogGroupAccessBean catGroupAb = new CatalogGroupAccessBean();
                    catGroupAb.setInitKey_catalogGroupReferenceNumber(catId);
                    catGroupAb.instantiateEntity();
                    categories.add(catGroupAb.getIdentifier());
                }
            }
//        } catch (RemoteException e) {
//            LOGGER.error(methodName, e.getMessage(), e);
//        } catch (CreateException e) {
//            LOGGER.error(methodName, e.getMessage(), e);
//        } catch (FinderException e) {
//            LOGGER.error(methodName, e.getMessage(), e);
//        } catch (NamingException e) {
//            LOGGER.error(methodName, e.getMessage(), e);
//        }

        LOGGER.exiting(methodName, categories);
        return categories;
    }
}
