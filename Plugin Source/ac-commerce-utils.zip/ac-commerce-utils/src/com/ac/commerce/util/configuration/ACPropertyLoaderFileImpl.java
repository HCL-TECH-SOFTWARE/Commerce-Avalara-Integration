package com.ac.commerce.util.configuration;

import java.text.MessageFormat;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang.NumberUtils;
import org.apache.commons.lang.StringUtils;

import com.ac.commerce.util.ACCommerceUtils;
import com.ac.commerce.util.logging.ACLogger;

// TODO v.mykhailov make cache as proxy class for ACPropertyLoader
public class ACPropertyLoaderFileImpl implements ACPropertyLoader {
    public static final String PATH_DELIMITER = ".";
    private static final ACLogger LOGGER = new ACLogger(ACPropertyLoader.class);

    private Map<String, Properties> propertiesCache = new ConcurrentHashMap<String, Properties>();

    @Override
    public String getString(String resourceBundleName, String messageKey) {
        return getLocalizedMessage(resourceBundleName, null, messageKey, null);
    }

    @Override
    public String getString(String resourceBundleName, String storeName, String messageKey) {
        return getLocalizedMessage(resourceBundleName, storeName, messageKey, null);
    }

    @Override
    public boolean getBoolean(String resourceBundleName, String key) {
        return getBoolean(resourceBundleName, null, key);
    }

    @Override
    public boolean getBoolean(String resourceBundleName, String key, boolean defaultValue) {
        String value = getString(resourceBundleName, null, key);
        return value == null ? defaultValue : getBoolean(resourceBundleName, key);
    }

    @Override
    public boolean getBoolean(String resourceBundleName, String storeName, String key) {
        return BooleanUtils.toBoolean(getString(resourceBundleName, storeName, key));
    }

    @Override
    public int getInt(String resourceBundleName, String key) {
        return getInt(resourceBundleName, null, key);
    }

    @Override
    public int getInt(String resourceBundleName, String storeName, String key) {
        return NumberUtils.stringToInt(getString(resourceBundleName, storeName, key));
    }

    @Override
    public int getInt(String resourceBundleName, String key, int defaultValue) {
        String value = getString(resourceBundleName, null, key);
        return value == null ? defaultValue : getInt(resourceBundleName, key);
    }

    @Override
    public String getLocalizedMessage(String resourceBundleName, String storeName, String messageKey, Locale locale, Object... args) {
        String methodName = "getLocalizedMessage";
        try {
            Properties props = getResourceBundle(resourceBundleName, storeName, locale);
            String messagePattern = props.getProperty(messageKey);

            if (args != null && args.length > 0) {
                return MessageFormat.format(messagePattern, args);
            }
            return messagePattern;
        } catch (Exception e) {
            LOGGER.warn(methodName, "Exception while getting localized message", e);
            return null;
        }
    }

    @Override
    public String getPropertyFileName(String resourcePath, String storeName) {
        return getPropertyFileName(resourcePath, storeName, null);
    }

    @Override
    public String getPropertyFileName(String resourcePath, String storeName, Locale locale) {
        String methodName = "getPropertyFileName";
        LOGGER.entering(methodName, resourcePath, storeName, locale);
        String storeNameCorrected = storeName;
        if (StringUtils.isNumeric(storeName)) {
            storeNameCorrected = ACCommerceUtils.getStoreName(storeName);
        }

        // TODO a.nenko Investigate and/or fix why locale.toString() returns "en_us" instead of "en_US"
        // This may cause problem of not found resources for non-Windows hosts
        String localeSuffix = locale != null ? "_" + locale.toString() : "";
        if (StringUtils.isEmpty(storeNameCorrected)) {
            return resourcePath + localeSuffix;
        }

        int lastIndexOf = resourcePath.lastIndexOf(PATH_DELIMITER);
        if (lastIndexOf == -1) {
            // Example: for "storetext" and "10651" return AuroraStorefrontAssetStore.storetext
            return storeNameCorrected + PATH_DELIMITER + resourcePath + localeSuffix;
        }
        // Example: for "package.subpack.conf" and "10651" return package.subpack.AuroraStorefrontAssetStore.conf (O.o)
        String firstPart = resourcePath.substring(0, lastIndexOf);
        String lastPart = resourcePath.substring(lastIndexOf);
        return firstPart + PATH_DELIMITER + storeNameCorrected + lastPart + localeSuffix;
    }

    @Override
    public Properties getProperties(String fileName) {
        return getProperties(fileName, null);
    }

    @Override
    public Properties getProperties(String fileName, String storeName) {
        return getProperties(fileName, storeName, null);
    }

    @Override
    public Properties getProperties(String fileName, String storeName, Locale locale) {
        final String methodName = "getProperties(String fileName, String storeName)";
        LOGGER.entering(methodName, fileName, storeName);
        Properties p = new Properties();
        try {
            String fileNameWithStoreDir = fileName;
            if (StringUtils.isNotEmpty(storeName)) {
                fileNameWithStoreDir = getPropertyFileName(fileNameWithStoreDir, storeName, locale);
            }
            if (propertiesCache.containsKey(fileNameWithStoreDir)) {
                return propertiesCache.get(fileNameWithStoreDir);
            }

            p = getResourceBundle(fileName, storeName, locale);
            propertiesCache.put(fileNameWithStoreDir, p);
        } catch (MissingResourceException e) {
            LOGGER.error(methodName, e.getMessage());
        }
        LOGGER.exiting(methodName, p);
        return p;
    }

    private Properties convertToProperties(ResourceBundle rb) {
        Properties p = new Properties();
        Enumeration<String> keys = rb.getKeys();
        while (keys.hasMoreElements()) {
            String key = keys.nextElement();
            p.put(key, rb.getString(key));
        }
        return p;
    }

    private Properties getResourceBundle(String resourceBundleName, String storeName, Locale locale) {
        String fileNameWithStoreDir = resourceBundleName;
        if (StringUtils.isNotEmpty(storeName)) {
            fileNameWithStoreDir = getPropertyFileName(fileNameWithStoreDir, storeName, locale);
        } else if (locale != null) {
            // when store is missing but locale is defined
            fileNameWithStoreDir += "_" + locale.toString();
        }
        if (propertiesCache.containsKey(fileNameWithStoreDir)) {
            return propertiesCache.get(fileNameWithStoreDir);
        }

        ResourceBundle resourceBundle = locateResourceBundle(resourceBundleName, fileNameWithStoreDir, locale);
        Properties props = convertToProperties(resourceBundle);
        propertiesCache.put(fileNameWithStoreDir, props);
        return props;
    }

    private ResourceBundle locateResourceBundle(String resourceBundleName, String fileNameWithStoreDir, Locale locale) {
        String methodName = "locateResourceBundle";
        ResourceBundle rb = null;
        try {
            if (locale != null) {
                rb = ResourceBundle.getBundle(fileNameWithStoreDir, locale);
            } else {
                rb = ResourceBundle.getBundle(fileNameWithStoreDir);
            }
        } catch (MissingResourceException e) {
            LOGGER.warn(methodName, "Can't locate ResourceBundle=" + fileNameWithStoreDir, e);
            // try without store name
            if (locale != null) {
                rb = ResourceBundle.getBundle(resourceBundleName, locale);
            } else {
                rb = ResourceBundle.getBundle(resourceBundleName);
            }
        }
        return rb;
    }

    @Override
    public boolean putPropertyToCache(String key, String value, String cacheKey) {
        String methodName = "putPropertyToCache";
        boolean replaced = false;
        Properties properties = propertiesCache.get(cacheKey);

        if (properties != null) {
            replaced = properties.put(key, value) != null;
            LOGGER.trace(methodName, "Update property {0}={1} in cache {2} ", key, value, cacheKey);
        } else {
            createPropertiesInCache(key, value, cacheKey);
            LOGGER.trace(methodName, "Create cache entry {0} with property {1}={2} ", cacheKey, key, value);
        }

        return replaced;
    }

    private void createPropertiesInCache(String key, String value, String cacheKey) {
        Properties p = new Properties();
        p.put(key, value);
        propertiesCache.put(cacheKey, p);
    }

    @Override
    public boolean clearCacheEntry(String key) {
        String methodName = "clearCacheEntry";
        boolean removed = false;

        if (propertiesCache.containsKey(key)) {
            removed = propertiesCache.remove(key) != null;
            LOGGER.trace(methodName, "Clear {0} entry in properties cache", key);
        }

        return removed;
    }

    @Override
    public void clearCaches() {
        String methodName = "clearCaches";
        propertiesCache.clear();
        LOGGER.trace(methodName, "Clear ALL property loader caches");
    }

    @Override
    public Set<String> getPropertiesCacheKeys() {
        return propertiesCache.keySet();
    }

}
