package com.ac.commerce.util;

import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.fulfillment.objects.ShippingModeAccessBean;
import com.ibm.commerce.user.objects.AddressAccessBean;
import com.ac.commerce.objects.helpers.AddressAccessBeans;
import com.ac.commerce.objects.helpers.StoreAccessBeans;
import com.ac.commerce.util.configuration.ACPropertyLoader;
import com.ac.commerce.util.configuration.ACPropertyLoaderFactory;
import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.Option;

/**
 * General class for commerce utility methods
 *
 * @author v.potaychuk
 *
 */
public final class ACCommerceUtils {
    private static final ACLogger LOGGER = new ACLogger(ACCommerceUtils.class);
    private static final ACPropertyLoader LOADER = ACPropertyLoaderFactory.getInstance();
    private static final String PROPERTIES = "com.ac.commerce.shipping.shipping";
    private final static String PHYSICAL_STORE_TAX = "PHYSICAL_STORE_TAX";
    private static final String PICKUP_IN_STORE_CARRIER = "PICKUP_IN_STORE_CARRIER";
    private static final String PICKUP_IN_STORE_CODE = "PICKUP_IN_STORE_CODE";
    private static final String NO_SHIPPING_MODE_ID = "NO_SHIPPING_MODE_ID";
    private static final String HM_STORE_ID = "HM_STORE_ID";

    private static final Map<String, String> STORE_NAME_CACHE = new ConcurrentHashMap<String, String>();

    private ACCommerceUtils() {
        // Utility class
    }

    /**
     * Get store name by store ID
     *
     * @param storeId
     * @return String storeName
     */
    @Nullable
    public static String getStoreName(@Nullable String storeId) {
        final String methodName = "getStoreName(String storeId)";
        LOGGER.entering(methodName, storeId);
        if (storeId == null) {
            return null;
        }
        String storeName = STORE_NAME_CACHE.get(storeId);
        if (storeName == null) {
            storeName = StoreAccessBeans.optionBean(storeId).getDirectory().getOrElse(null);
            if (storeName != null) {
                STORE_NAME_CACHE.put(storeId, storeName);
            }
        }
        LOGGER.trace(methodName, "Getting store name {0} for {1}", storeName, storeId);
        LOGGER.exiting(methodName, storeName);
        return storeName;
    }

    /**
     * Get buyer email address
     *
     * @param orderId
     * @return
     * @throws ECException
     */
    @Nonnull
    public static Option<String> getBuyerEmailId(String orderId) {
        final String methodName = "getBuyerEmailId()";
        LOGGER.entering(methodName, orderId);

        Option<AddressAccessBean> bean = ACAddressUtils.getAddressForOrder(orderId);
        Option<String> emailId = AddressAccessBeans.EMAIL1.getValue(bean);

        LOGGER.exiting(methodName, emailId);
        return emailId;
    }

    public static String getPickUpInStoreShipModeId() throws NumberFormatException, RemoteException, NamingException, FinderException,
        CreateException {

        String shipModeId = "";
        String pickUpInStoreCarrier = LOADER.getString(PROPERTIES, PICKUP_IN_STORE_CARRIER);
        String pickUpInStoreCode = LOADER.getString(PROPERTIES, PICKUP_IN_STORE_CODE);
        String storeId = LOADER.getString(PROPERTIES, HM_STORE_ID);

        ShippingModeAccessBean smab = new ShippingModeAccessBean();
        Enumeration<ShippingModeAccessBean> shipModesList = smab.findByStorePathCodeAndCarrier(Integer.valueOf(storeId), pickUpInStoreCode,
            pickUpInStoreCarrier);
        while (shipModesList.hasMoreElements()) {
            ShippingModeAccessBean shippingModeAccessBean = shipModesList.nextElement();
            if (shippingModeAccessBean.getMarkForDelete() == 1) {
                continue;
            }
            shipModeId = shippingModeAccessBean.getShippingModeId();
            break;
        }
        return shipModeId;
    }
    
    public static String getNoShippingShipModeId() throws NumberFormatException, RemoteException, NamingException, FinderException,
        CreateException {
        final String methodName = "getNoShippingShipModeId()";
        LOGGER.entering(methodName);
        return LOADER.getString(PROPERTIES, NO_SHIPPING_MODE_ID);
    }
}
