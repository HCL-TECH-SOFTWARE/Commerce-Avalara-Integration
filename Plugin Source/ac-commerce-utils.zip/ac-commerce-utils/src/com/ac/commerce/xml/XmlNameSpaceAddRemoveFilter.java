package com.ac.commerce.xml;

import org.apache.commons.lang.StringUtils;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.XMLFilterImpl;

/**
 * JAXB filter to add/remove namespace for each element
 */
public class XmlNameSpaceAddRemoveFilter extends XMLFilterImpl {

    private String nameSpaceUri;
    private boolean addedNamespace = false;

    /**
     * Creates filter to remove namespaces from each element.
     */
    public XmlNameSpaceAddRemoveFilter() {
        this(null);
    }

    /**
     * Creates filter to add namespace to each element.
     * 
     * @param nameSpaceUri
     *            namespace to add. Null if need to remove any namespaces on element
     */
    public XmlNameSpaceAddRemoveFilter(String nameSpaceUri) {
        this.nameSpaceUri = StringUtils.defaultString(nameSpaceUri);
    }

    @Override
    public void startDocument() throws SAXException {
        super.startDocument();
        if (StringUtils.isNotEmpty(nameSpaceUri)) {
            startControlledPrefixMapping();
        }
    }

    @Override
    public void startElement(String arg0, String arg1, String arg2, Attributes arg3) throws SAXException {
        super.startElement(nameSpaceUri, arg1, arg2, arg3);
    }

    @Override
    public void endElement(String arg0, String arg1, String arg2) throws SAXException {
        super.endElement(nameSpaceUri, arg1, arg2);
    }

    @Override
    public void startPrefixMapping(String prefix, String url) throws SAXException {
        if (StringUtils.isNotEmpty(nameSpaceUri)) {
            startControlledPrefixMapping();
        }
        // If empty -> remove the namespace, i.e. don't call startPrefixMapping for parent!
    }

    private void startControlledPrefixMapping() throws SAXException {
        if (StringUtils.isNotEmpty(nameSpaceUri) && !addedNamespace) {
            // We should add namespace since it is set and has not yet been done.
            super.startPrefixMapping("", nameSpaceUri);
            // Make sure we don't do it twice
            addedNamespace = true;
        }
    }
}
