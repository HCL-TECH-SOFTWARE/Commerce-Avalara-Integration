/**
 * 
 */
package com.ac.commerce.objects.helpers.options;

import com.ibm.commerce.common.objects.StoreAccessBean;
import com.ac.commerce.objects.helpers.HasObjectDefined;
import com.ac.util.Option;

public interface StoreAccessBeanOption extends HasObjectDefined<StoreAccessBean> {
    public Option<String> getDirectory();

    public void setDirectory(String newValue);
}