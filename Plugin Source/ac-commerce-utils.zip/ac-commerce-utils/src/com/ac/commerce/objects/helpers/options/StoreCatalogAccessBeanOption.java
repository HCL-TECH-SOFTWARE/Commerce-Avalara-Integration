/**
 * 
 */
package com.ac.commerce.objects.helpers.options;

import com.ac.util.Option;

/**
 * @author a.kudla
 * 
 */
public interface StoreCatalogAccessBeanOption {

    Option<String> getMasterCatalog();

    Option<String> getCatalogReferenceNumber();
}
