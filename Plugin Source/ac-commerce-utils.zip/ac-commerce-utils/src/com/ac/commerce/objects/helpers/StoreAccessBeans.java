package com.ac.commerce.objects.helpers;

import static com.ac.commerce.objects.helpers.AccessBeansHandler.createNothingProxy;
import static com.ac.commerce.objects.helpers.AccessBeansHandler.createProxy;

import java.rmi.RemoteException;
import java.util.logging.Logger;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import com.ibm.commerce.common.objects.StoreAccessBean;
import com.ibm.commerce.foundation.common.util.logging.LoggingHelper;
import com.ac.commerce.objects.helpers.options.StoreAccessBeanOption;

/**
 * @author a.kudla
 * 
 *         Helper class to work with Store access beans
 * 
 */
public final class StoreAccessBeans {
    static final Logger LOGGER = LoggingHelper.getLogger(StoreAccessBeans.class);

    private StoreAccessBeans() {
        // Utility class
    }

    public static StoreAccessBean bean(String storeId) throws RemoteException, CreateException, FinderException, NamingException {
        StoreAccessBean storeab = new StoreAccessBean();
        storeab.setInitKey_storeEntityId(storeId);
        storeab.instantiateEntity();
        return storeab;
    }

    public static StoreAccessBeanOption optionBean(String storeId) {
        try {
            return createProxy(bean(storeId), StoreAccessBeanOption.class);
        } catch (Exception e) {
            LOGGER.log(LoggingHelper.DEFAULT_TRACE_LOG_LEVEL, "Exception while searching store bean", e);
        }
        return createNothingProxy(StoreAccessBeanOption.class);
    }

}
