/**
 * 
 */
package com.ac.commerce.objects.helpers;

import static java.lang.String.format;

import java.lang.reflect.Method;
import java.util.Enumeration;

import javassist.util.proxy.MethodFilter;
import javassist.util.proxy.MethodHandler;
import javassist.util.proxy.ProxyFactory;

import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.Enumerations;
import com.ac.util.Option;
import com.ac.util.exception.ACRuntimeException;

public class AccessBeansHandler<T> implements MethodHandler {
    static final ACLogger LOGGER = new ACLogger(AccessBeansHandler.class);
    private Object bean;
    private Class<T> clazz;

    AccessBeansHandler(Object bean, Class<T> clazz) {
        this.bean = bean;
        this.clazz = clazz;
    }

    @Override
    public Object invoke(Object self, Method method, Method proceed, Object[] args) throws Throwable {
        String name = method.getName();
        LOGGER.trace(name, format("Invoking AccessBeansHandler.%s", name));
        if (name.equals("isObjectDefined")) {
            return true;
        }

        if (name.equals("getDefinedBean")) {
            return bean;
        }

        if (name.equals("toString")) {
            return format("AccessBeansHandler<%s,%s>", bean, clazz);
        }
        Method m = bean.getClass().getMethod(name, method.getParameterTypes());
        Object res = null;
        try {
            res = m.invoke(bean, args);
        } catch (Exception e) {
            LOGGER.error(name, format("Method invokation failed %s", name), e);
        }

        if (method.getReturnType().equals(Option.class)) {
            return Option.of(res);
        } else if (method.getReturnType().equals(Enumeration.class)) {
            return Enumerations.asList((Enumeration) res);
        } else if (method.getReturnType().equals(clazz)) {
            return createProxy(res, clazz);
        }
        return res;
    }

    @SuppressWarnings("unchecked")
    public static <T> T createProxy(Object bean, Class<T> clazz) throws IllegalArgumentException {
        try {
            ProxyFactory factory = new ProxyFactory();
            factory.setInterfaces(new Class[] { clazz });
            factory.setFilter(new MethodFilter() {
                @Override
                public boolean isHandled(Method arg0) {
                    return true;
                }
            });
            MethodHandler handler = bean == null ? new NothingHandler(clazz) : new AccessBeansHandler(bean, clazz);
            return (T) factory.create(new Class<?>[0], new Object[0], handler);
        } catch (Exception e) {
            throw new ACRuntimeException(e);
        }
    }

    @SuppressWarnings("unchecked")
    public static <T> T createNothingProxy(Class<T> clazz) {
        try {
            ProxyFactory factory = new ProxyFactory();
            factory.setInterfaces(new Class[] { clazz });
            factory.setFilter(new MethodFilter() {
                @Override
                public boolean isHandled(Method arg0) {
                    return true;
                }
            });
            return (T) factory.create(new Class<?>[0], new Object[0], new NothingHandler(clazz));
        } catch (Exception e) {
            LOGGER.error("createNothingProxy", format("None proxy creation failed %s ", clazz), e);
        }
        return null;
    }

}