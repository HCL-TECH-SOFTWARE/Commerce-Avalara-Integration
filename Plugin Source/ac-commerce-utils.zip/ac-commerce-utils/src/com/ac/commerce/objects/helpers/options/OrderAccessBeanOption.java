package com.ac.commerce.objects.helpers.options;

import com.ibm.commerce.order.objects.OrderAccessBean;
import com.ibm.commerce.order.objects.OrderItemAccessBean;
import com.ac.commerce.objects.helpers.HasObjectDefined;
import com.ac.util.Option;

public interface OrderAccessBeanOption extends HasObjectDefined<OrderAccessBean> {

    Option<Long> getOrderIdInEntityType();

    Option<String> getOrderId();

    Option<Long> getMemberIdInEntityType();

    Option<String> getAddressId();

    Option<String> getPlaceOrderTime();

    OrderItemAccessBean[] getOrderItems();

    Option<Integer> getBuschnId();
}
