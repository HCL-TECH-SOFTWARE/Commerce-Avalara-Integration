/**
 * 
 */
package com.ac.commerce.objects.helpers;

import java.rmi.RemoteException;

import javax.annotation.Nullable;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.naming.NamingException;

import com.ibm.ivj.ejb.runtime.AbstractAccessBean;
import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.Option;
import com.ac.util.property.Property;

/**
 * @author a.kudla
 * 
 */
public final class AccessBeans {

    private static final ACLogger LOGGER = new ACLogger(AccessBeans.class);

    private AccessBeans() {
        // Utility class
    }

    public static <Bean, T> T getPropertyValue(Bean bean, Property<Bean, T> property) {
        return property.getValue(bean);
    }

    public static <Bean, T> T getPropertyValue(Option<Bean> bean, Property<Bean, T> property) {
        return bean.map(property).getOrElse(null);
    }

    /**
     * Null-safe remove of access bean
     * 
     * @param accessBean
     *            Access bean to remove
     */
    public static void remove(@Nullable AbstractAccessBean accessBean) {
        String methodName = "remove(AbstractAccessBean accessBean)";
        try {
            if (accessBean != null) {
                accessBean.getEJBRef().remove();
            }
        } catch (RemoteException e) {
            LOGGER.error(methodName, e.getMessage(), e);
        } catch (RemoveException e) {
            LOGGER.error(methodName, e.getMessage(), e);
        } catch (CreateException e) {
            LOGGER.error(methodName, e.getMessage(), e);
        } catch (FinderException e) {
            LOGGER.error(methodName, e.getMessage(), e);
        } catch (NamingException e) {
            LOGGER.error(methodName, e.getMessage(), e);
        }
    }

    /**
     * Null-safe remove of access bean
     * 
     * @param accessBean
     *            Access bean to remove
     */
    public static void remove(@Nullable AbstractAccessBean... accessBeans) {
        if (accessBeans != null) {
            for (AbstractAccessBean abstractAccessBean : accessBeans) {
                remove(abstractAccessBean);
            }
        }
    }
}
