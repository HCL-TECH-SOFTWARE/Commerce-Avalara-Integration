package com.ac.commerce.objects.helpers;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import com.ibm.commerce.ordermanagement.objects.RMAAccessBean;

/**
 * @author a.kudla
 * 
 *         Helper class to work with RMA access beans
 * 
 */
public final class RMAAccessBeans {
    private RMAAccessBeans() {
        // Utility class
    }

    public static RMAAccessBean bean(Long returnId) throws RemoteException, CreateException, FinderException, NamingException {
        RMAAccessBean rAB = new RMAAccessBean();
        rAB.setInitKey_rmaId(returnId.toString());
        rAB.instantiateEntity();
        return rAB;
    }

}
