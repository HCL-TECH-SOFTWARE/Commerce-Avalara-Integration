package com.ac.commerce.objects.helpers;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import com.ibm.commerce.catalog.objects.CatalogEntryDescriptionAccessBean;

/**
 * @author a.kudla
 * 
 *         Helper class to work with CatalogEntryDescription access beans
 * 
 */
public final class CatalogEntryDescriptionAccessBeans {

    private CatalogEntryDescriptionAccessBeans() {
        // Utility class
    }

    public static CatalogEntryDescriptionAccessBean bean(String catId) throws RemoteException, CreateException, FinderException,
        NamingException {
        // setting language Id as "-1" which is english.
        return bean(catId, "-1");
    }

    public static CatalogEntryDescriptionAccessBean bean(String catId, String languageId) throws RemoteException, CreateException,
        FinderException, NamingException {
        CatalogEntryDescriptionAccessBean catDescAB = new CatalogEntryDescriptionAccessBean();
        catDescAB.setInitKey_catalogEntryReferenceNumber(catId);
        catDescAB.setInitKey_language_id(languageId);
        catDescAB.instantiateEntity();
        return catDescAB;
    }
}
