package com.ac.commerce.objects.helpers;

import javax.annotation.Nullable;

public interface HasObjectDefined<T> {
    boolean isObjectDefined();

    @Nullable
    T getDefinedBean();
}
