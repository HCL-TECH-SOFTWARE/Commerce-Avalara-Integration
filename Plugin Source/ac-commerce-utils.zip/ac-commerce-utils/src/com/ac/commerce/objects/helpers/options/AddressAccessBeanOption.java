package com.ac.commerce.objects.helpers.options;

import java.util.List;

import com.ibm.commerce.user.objects.AddressAccessBean;
import com.ac.commerce.objects.helpers.HasObjectDefined;
import com.ac.util.Option;

public interface AddressAccessBeanOption extends HasObjectDefined<AddressAccessBean> {

    AddressAccessBeanOption findSelfAddressByMember(Long memberId);

    List<AddressAccessBeanOption> findByMemberId(Long memberId);

    Option<String> getStatus();

    Option<String> getAddressType();

    Option<String> getAddressId();

    Option<String> getNickName();

    Option<String> getPrimary();

    Option<String> getPhone1();
    
    Option<String> getMobilePhone1();

    Option<String> getEmail1();
}
