package com.ac.commerce.objects.helpers;

import static com.ac.commerce.objects.helpers.AccessBeansHandler.createNothingProxy;
import static com.ac.commerce.objects.helpers.AccessBeansHandler.createProxy;

import java.rmi.RemoteException;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import com.ibm.commerce.order.objects.OrderAccessBean;
import com.ac.commerce.objects.helpers.options.OrderAccessBeanOption;
import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.Option;
import com.ac.util.property.LongProperty;

/**
 * @author a.kudla
 * 
 *         Helper class to work with Order access beans
 * 
 */
public final class OrderAccessBeans {

    private static final ACLogger LOGGER = new ACLogger(OrderAccessBeans.class);

    public static final LongProperty<OrderAccessBean> ORDER_ID_IN_EJB_TYPE = new LongProperty<OrderAccessBean>() {

        @Override
        @Nullable
        protected Long getVal(OrderAccessBean bean) {
            Option<Long> orderId = optionBean(bean).getOrderIdInEntityType();
            return orderId.getOrElse(null);
        }
    };

    private OrderAccessBeans() {
        // Utility class
    }

    public static OrderAccessBean bean(String orderId) throws RemoteException, CreateException, FinderException, NamingException {
        OrderAccessBean orderAB = new OrderAccessBean();
        orderAB.setInitKey_orderId(orderId);
        orderAB.instantiateEntity();
        return orderAB;
    }

    public static OrderAccessBean bean(@Nonnull Long orderId) throws RemoteException, CreateException, FinderException, NamingException {
        return bean(orderId.toString());
    }

    @Nonnull
    public static OrderAccessBeanOption optionBean(String orderId) {
        final String methodName = "optionBean";
        try {
            return createProxy(bean(orderId), OrderAccessBeanOption.class);
        } catch (Exception e) {
            LOGGER.error(methodName, "Exception while searching order bean", e);
        }
        return createNothingProxy(OrderAccessBeanOption.class);
    }

    public static OrderAccessBeanOption optionBean(@Nonnull Long orderId) {
        return optionBean(orderId.toString());
    }

    @Nonnull
    public static OrderAccessBeanOption optionBean(OrderAccessBean bean) {
        return createProxy(bean, OrderAccessBeanOption.class);
    }

}
