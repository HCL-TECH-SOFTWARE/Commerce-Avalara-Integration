package com.ac.commerce.objects.helpers;

import java.rmi.RemoteException;
import java.util.List;

import javax.ejb.FinderException;
import javax.naming.NamingException;

import com.ibm.commerce.ordermanagement.objects.RMAItemAccessBean;
import com.ac.util.Enumerations;

/**
 * @author a.kudla
 * 
 *         Helper class to work with RMAItem access beans
 * 
 */
public final class RMAItemAccessBeans {

    private RMAItemAccessBeans() {
        // Utility class
    }

    public static List<RMAItemAccessBean> findByRmaId(Long returnId) throws RemoteException, FinderException, NamingException {
        RMAItemAccessBean rmaIAB = new RMAItemAccessBean();
        return Enumerations.asList(rmaIAB.findByRmaId(returnId));
    }
}
