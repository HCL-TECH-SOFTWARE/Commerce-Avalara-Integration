package com.ac.commerce.objects.helpers;

import static com.ac.commerce.objects.helpers.AccessBeansHandler.createNothingProxy;
import static com.ac.commerce.objects.helpers.AccessBeansHandler.createProxy;

import java.rmi.RemoteException;
import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import com.ibm.commerce.user.objects.AddressAccessBean;
import com.ac.commerce.objects.helpers.options.AddressAccessBeanOption;
import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.Enumerations;
import com.ac.util.Lists;
import com.ac.util.None;
import com.ac.util.Option;
import com.ac.util.property.StringProperty;

/**
 * @author a.kudla
 * 
 *         Helper class to work with Address access beans
 * 
 */
public final class AddressAccessBeans {
    static final ACLogger LOGGER = new ACLogger(AddressAccessBeans.class);

    public static final StringProperty<AddressAccessBean> ADDRESS_ID = new StringProperty<AddressAccessBean>() {

        @Override
        @Nullable
        protected String getVal(AddressAccessBean bean) {
            Option<String> addressId = optionBean(bean).getAddressId();
            return addressId.getOrElse(null);
        }
    };

    public static final StringProperty<AddressAccessBean> ADDRESS_TYPE = new StringProperty<AddressAccessBean>() {

        @Override
        @Nullable
        protected String getVal(AddressAccessBean bean) {
            Option<String> addressType = optionBean(bean).getAddressType();
            return addressType.getOrElse(null);
        }
    };

    public static final StringProperty<AddressAccessBean> NICK_NAME = new StringProperty<AddressAccessBean>() {

        @Override
        @Nullable
        protected String getVal(AddressAccessBean bean) {
            Option<String> nickName = optionBean(bean).getNickName();
            return nickName.getOrElse(null);
        }
    };

    public static final StringProperty<AddressAccessBean> STATUS = new StringProperty<AddressAccessBean>() {

        @Override
        @Nullable
        protected String getVal(AddressAccessBean bean) {
            Option<String> status = optionBean(bean).getStatus();
            return status.getOrElse(null);
        }
    };

    public static final StringProperty<AddressAccessBean> PRIMARY = new StringProperty<AddressAccessBean>() {

        @Override
        @Nullable
        protected String getVal(AddressAccessBean bean) {
            Option<String> primary = optionBean(bean).getPrimary();
            return primary.getOrElse(null);
        }
    };

    public static final StringProperty<AddressAccessBean> PHONE1 = new StringProperty<AddressAccessBean>() {

        @Override
        @Nullable
        protected String getVal(AddressAccessBean bean) {
            Option<String> phone1 = optionBean(bean).getPhone1();
            return phone1.getOrElse(null);
        }
    };

    public static final StringProperty<AddressAccessBean> EMAIL1 = new StringProperty<AddressAccessBean>() {

        @Override
        @Nullable
        protected String getVal(AddressAccessBean bean) {
            Option<String> phone1 = optionBean(bean).getEmail1();
            return phone1.getOrElse(null);
        }
    };

    private AddressAccessBeans() {
        // Utility class
    }

    public static AddressAccessBean bean(Long billingAddressId) throws RemoteException, CreateException, FinderException, NamingException {
        return bean(billingAddressId.toString());
    }

    public static AddressAccessBean bean(String billingAddressId) throws RemoteException, CreateException, FinderException, NamingException {
        AddressAccessBean bean = new AddressAccessBean();
        bean.setInitKey_addressId(billingAddressId);
        bean.instantiateEntity();
        return bean;
    }

    /**
     * @param addressId
     * @return
     */
    @Nullable
    public static Option<AddressAccessBean> bean(Option<String> addressId) {
        try {
            if (addressId.isDefined()) {
                return Option.of(bean(addressId.get()));
            }
        } catch (Exception e) {
            LOGGER.error("bean", "Exception while searching address bean", e);
        }
        return None.instance();
    }

    @Nonnull
    public static AddressAccessBeanOption optionBean(String storeId) {
        try {
            return optionBean(bean(storeId));
        } catch (Exception e) {
            LOGGER.error("optionBean", "Exception while searching address bean", e);
        }
        return createNothingProxy(AddressAccessBeanOption.class);
    }

    @Nonnull
    public static AddressAccessBeanOption optionBean(AddressAccessBean bean) {
        return createProxy(bean, AddressAccessBeanOption.class);
    }

    @Nonnull
    public static List<AddressAccessBean> findByMemberId(Option<Long> userId) {
        if (userId.isDefined()) {
            return findByMemberId(userId.get());
        }
        return Lists.newArrayList();
    }

    @Nonnull
    public static List<AddressAccessBean> findByMemberId(Long userId) {
        try {
            return Enumerations.asList(new AddressAccessBean().findByMemberId(userId));
        } catch (Exception e) {
            LOGGER.error("findByMemberId", "Exception while searching addressess in findByMemberId ", e);
        }
        return Lists.newArrayList();
    }

    /**
     * @param memberId
     * @return
     */
    public static Option<AddressAccessBean> findSelfAddressByMember(Option<Long> memberId) {
        if (memberId.isDefined()) {
            try {
                return Option.of(new AddressAccessBean().findSelfAddressByMember(memberId.get()));
            } catch (Exception e) {
                LOGGER.error("findByMemberId", "Exception while searching addressess in findByMemberId ", e);
            }
        }
        return None.instance();
    }

}
