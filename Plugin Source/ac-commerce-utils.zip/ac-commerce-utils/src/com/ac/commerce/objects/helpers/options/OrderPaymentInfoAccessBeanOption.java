/**
 * 
 */
package com.ac.commerce.objects.helpers.options;

import com.ibm.commerce.order.objects.OrderPaymentInfoAccessBean;
import com.ac.commerce.objects.helpers.HasObjectDefined;
import com.ac.util.Option;

/**
 * @author a.kudla
 * 
 */
public interface OrderPaymentInfoAccessBeanOption extends HasObjectDefined<OrderPaymentInfoAccessBean> {
    Option<String> getPaymentPairName();

    Option<String> getPaymentPairValue();

}
