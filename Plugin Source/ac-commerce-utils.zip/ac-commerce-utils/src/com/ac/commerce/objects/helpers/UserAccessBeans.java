package com.ac.commerce.objects.helpers;

import static com.ibm.commerce.member.constants.ECMemberCommandParameterConstants.EC_USER_GUEST_SHOPPER;
import static com.ac.commerce.objects.helpers.AccessBeansHandler.createNothingProxy;
import static com.ac.commerce.objects.helpers.AccessBeansHandler.createProxy;

import java.rmi.RemoteException;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import com.ibm.commerce.user.objects.UserAccessBean;
import com.ac.commerce.objects.helpers.options.UserAccessBeanOption;
import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.Option;
import com.ac.util.property.StringProperty;

/**
 * @author a.kudla
 * 
 *         Helper class to work with User access beans
 * 
 */
public final class UserAccessBeans {
    static final ACLogger LOGGER = new ACLogger(UserAccessBeans.class);

    public static final StringProperty<UserAccessBean> REGISTER_TYPE = new StringProperty<UserAccessBean>() {

        @Override
        @Nullable
        protected String getVal(UserAccessBean bean) {
            Option<String> registerType = optionBean(bean).getRegisterType();
            return registerType.getOrElse(null);
        }
    };

    public static final UserAccessBeanOption NOTHING_PROXY = createNothingProxy(UserAccessBeanOption.class);

    private UserAccessBeans() {
        // Utility class
    }

    public static UserAccessBean bean(Long memberId) throws RemoteException, CreateException, FinderException, NamingException {
        return bean(memberId.toString());
    }

    public static UserAccessBean bean(String memberId) throws RemoteException, CreateException, FinderException, NamingException {
        UserAccessBean userBean = new UserAccessBean();
        userBean.setInitKey_memberId(memberId);
        userBean.instantiateEntity();
        return userBean;
    }

    public static UserAccessBeanOption optionBean(Option<Long> memberId) {
        return memberId.isDefined() ? optionBean(memberId.get().toString()) : NOTHING_PROXY;
    }

    public static UserAccessBeanOption optionBean(String memberId) {
        try {
            return createProxy(bean(memberId), UserAccessBeanOption.class);
        } catch (Exception e) {
            LOGGER.error("optionBean", "Exception while searching user bean", e);
        }
        return NOTHING_PROXY;
    }

    @Nonnull
    public static UserAccessBeanOption optionBean(UserAccessBean bean) {
        return createProxy(bean, UserAccessBeanOption.class);
    }

    public static boolean isGuest(UserAccessBean bean) {
        return EC_USER_GUEST_SHOPPER.equals(REGISTER_TYPE.getValue(bean));
    }

    public static boolean isGuest(@Nullable String userId) {
        return EC_USER_GUEST_SHOPPER.equals(optionBean(userId).getRegisterType().get());
    }

    public static boolean isGuest(@Nullable Long userId) {
        return userId == null ? true : isGuest(userId.toString());
    }
}
