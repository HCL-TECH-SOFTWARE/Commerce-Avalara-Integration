package com.ac.commerce.objects.helpers;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import com.ibm.commerce.order.objects.OrderItemAccessBean;

/**
 * @author a.kudla
 * 
 *         Helper class to work with OrderItem access beans
 * 
 */
public final class OrderItemAccessBeans {

    private OrderItemAccessBeans() {
        // Utility class
    }

    public static OrderItemAccessBean bean(String orderItemId) throws RemoteException, CreateException, FinderException, NamingException {
        OrderItemAccessBean orderitemaccessbean = new OrderItemAccessBean();
        orderitemaccessbean.setInitKey_orderItemId(orderItemId);
        orderitemaccessbean.instantiateEntity();
        return orderitemaccessbean;
    }

    public static OrderItemAccessBean bean(Long orderItemId) throws RemoteException, CreateException, FinderException, NamingException {
        return bean(orderItemId.toString());
    }
}
