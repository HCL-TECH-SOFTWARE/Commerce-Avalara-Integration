/**
 * 
 */
package com.ac.commerce.objects.helpers;

import static com.ac.commerce.objects.helpers.AccessBeansHandler.createProxy;

import java.util.List;
import java.util.logging.Logger;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.ibm.commerce.catalog.objects.StoreCatalogAccessBean;
import com.ibm.commerce.foundation.common.util.logging.LoggingHelper;
import com.ac.commerce.objects.helpers.options.StoreCatalogAccessBeanOption;
import com.ac.util.Enumerations;
import com.ac.util.Lists;
import com.ac.util.Option;
import com.ac.util.property.StringProperty;

/**
 * @author a.kudla
 * 
 */
public final class StoreCatalogAccessBeans {

    static final Logger LOGGER = LoggingHelper.getLogger(StoreCatalogAccessBeans.class);

    public static final StringProperty<StoreCatalogAccessBean> MASTER_CATALOG = new StringProperty<StoreCatalogAccessBean>() {

        @Override
        @Nullable
        protected String getVal(StoreCatalogAccessBean bean) {
            Option<String> masterCatalog = optionBean(bean).getMasterCatalog();
            return masterCatalog.getOrElse(null);
        }
    };

    public static final StringProperty<StoreCatalogAccessBean> CATALOG_REFERENCE_NUMBER = new StringProperty<StoreCatalogAccessBean>() {

        @Override
        @Nullable
        protected String getVal(StoreCatalogAccessBean bean) {
            Option<String> catalogReferenceNumber = optionBean(bean).getCatalogReferenceNumber();
            return catalogReferenceNumber.getOrElse(null);
        }
    };

    private StoreCatalogAccessBeans() {
        // Utility class
    }

    @Nonnull
    public static StoreCatalogAccessBeanOption optionBean(StoreCatalogAccessBean bean) {
        return createProxy(bean, StoreCatalogAccessBeanOption.class);
    }

    @Nonnull
    public static List<StoreCatalogAccessBean> findByStoreId(Integer storeId) {
        try {
            return Enumerations.asList(new StoreCatalogAccessBean().findByStoreId(storeId));
        } catch (Exception e) {
            LOGGER.log(LoggingHelper.DEFAULT_TRACE_LOG_LEVEL, "Exception while searching store catalogs in findByMemberId ", e);
        }
        return Lists.newArrayList();
    }

}
