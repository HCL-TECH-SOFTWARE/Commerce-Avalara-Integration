package com.ac.commerce.objects.helpers.options;

import com.ibm.commerce.user.objects.UserAccessBean;
import com.ac.commerce.objects.helpers.HasObjectDefined;
import com.ac.util.Option;

public interface UserAccessBeanOption extends HasObjectDefined<UserAccessBean> {
    Option<String> getRegisterType();

    Option<String> getRegistration();
}
