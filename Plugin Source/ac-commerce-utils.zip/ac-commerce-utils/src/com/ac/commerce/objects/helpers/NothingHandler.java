/**
 * 
 */
package com.ac.commerce.objects.helpers;

import static java.lang.String.format;

import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

import javassist.util.proxy.MethodHandler;

import com.ibm.commerce.foundation.common.util.logging.LoggingHelper;
import com.ac.util.None;
import com.ac.util.Option;
import com.ac.util.exception.ACRuntimeException;

class NothingHandler<T> implements MethodHandler {
    static final Logger LOGGER = LoggingHelper.getLogger(NothingHandler.class);

    private Class<T> clazz;

    public NothingHandler(Class<T> clazz) {
        this.clazz = clazz;
    }

    @Override
    public Object invoke(Object self, Method method, Method proceed, Object[] args) throws Throwable {
        LOGGER.log(Level.FINER, format("Invoking NothingHandler.%s", method.getName()));
        if (method.getReturnType().equals(Option.class)) {
            return None.instance();
        }

        String name = method.getName();

        if (name.equals("toString")) {
            return format("None<%s>", clazz);
        }
        if (name.equals("isObjectDefined")) {
            return false;
        }

        if (name.equals("getDefinedBean")) {
            return null;
        }

        throw new ACRuntimeException("no method found");
    }
}