package com.ac.commerce.objects.helpers;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import com.ibm.commerce.fulfillment.objects.ShippingModeAccessBean;

/**
 * @author a.kudla
 * 
 *         Helper class to work with ShippingMode access beans
 * 
 */
public final class ShippingModeAccessBeans {

    private ShippingModeAccessBeans() {
        // Utility class
    }

    public static ShippingModeAccessBean bean(String shippingModeId) throws RemoteException, CreateException, FinderException,
        NamingException {
        ShippingModeAccessBean shippingModeAB = new ShippingModeAccessBean();
        shippingModeAB.setInitKey_shippingModeId(shippingModeId);
        shippingModeAB.instantiateEntity();
        return shippingModeAB;
    }

}
