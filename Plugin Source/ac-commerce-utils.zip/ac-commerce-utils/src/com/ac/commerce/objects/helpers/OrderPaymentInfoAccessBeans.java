/**
 * 
 */
package com.ac.commerce.objects.helpers;

import static com.ac.commerce.objects.helpers.AccessBeansHandler.createProxy;

import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.ibm.commerce.order.objects.OrderAccessBean;
import com.ibm.commerce.order.objects.OrderPaymentInfoAccessBean;
import com.ac.commerce.objects.helpers.options.OrderPaymentInfoAccessBeanOption;
import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.Enumerations;
import com.ac.util.Lists;
import com.ac.util.Option;
import com.ac.util.property.StringProperty;

/**
 * @author a.kudla
 * 
 *         Helper class to work with Order payment access beans
 */
public final class OrderPaymentInfoAccessBeans {

    static final ACLogger LOGGER = new ACLogger(OrderPaymentInfoAccessBeans.class);

    private OrderPaymentInfoAccessBeans() {
        // Utility class
    }

    public static final StringProperty<OrderPaymentInfoAccessBean> PAYMENT_PAIR_NAME = new StringProperty<OrderPaymentInfoAccessBean>() {

        @Override
        @Nullable
        protected String getVal(OrderPaymentInfoAccessBean bean) {
            Option<String> paymentPairName = optionBean(bean).getPaymentPairName();
            return paymentPairName.getOrElse(null);
        }
    };

    public static final StringProperty<OrderPaymentInfoAccessBean> PAYMENT_PAIR_VALUE = new StringProperty<OrderPaymentInfoAccessBean>() {

        @Override
        @Nullable
        protected String getVal(OrderPaymentInfoAccessBean bean) {
            Option<String> paymentPairValue = optionBean(bean).getPaymentPairValue();
            return paymentPairValue.getOrElse(null);
        }
    };

    @Nonnull
    public static OrderPaymentInfoAccessBeanOption optionBean(OrderPaymentInfoAccessBean bean) {
        return createProxy(bean, OrderPaymentInfoAccessBeanOption.class);
    }

    @Nonnull
    public static List<OrderPaymentInfoAccessBean> findByOrder(OrderAccessBean order) {
        final String methodName = "findByOrder";
        try {
            return Enumerations.asList(new OrderPaymentInfoAccessBean().findByOrder(order.getOrderIdInEntityType()));
        } catch (Exception e) {
            LOGGER.error(methodName, "Exception while searching order payment infos in findByOrder ", e);
        }
        return Lists.newArrayList();
    }

    public static void removeFromOrder(OrderAccessBean order) {
        final String methodName = "removeFromOrder";
        try {
            for (OrderPaymentInfoAccessBean paymentInfo : findByOrder(order)) {
                paymentInfo.remove();//getEJBRef().remove();
            }
        } catch (Exception e) {
            LOGGER.error(methodName, "Exception while removing order payment infos from order ", e);
        }
    }

}
