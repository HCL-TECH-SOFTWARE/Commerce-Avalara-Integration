package com.ac.commerce.objects.helpers;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import com.ibm.commerce.catalog.objects.CatalogEntryAccessBean;

/**
 * @author v.mykhailov
 * 
 *         Helper class to work with CatalogEntry access beans
 */
public final class CatalogEntryAccessBeans {

    private CatalogEntryAccessBeans() {
        // Utility class
    }

    public static CatalogEntryAccessBean bean(Long catEntryId) throws RemoteException, CreateException, FinderException, NamingException {
        return bean(catEntryId.toString());
    }

    public static CatalogEntryAccessBean bean(String catEntryId) throws RemoteException, CreateException, FinderException, NamingException {
        CatalogEntryAccessBean catEntryAb = new CatalogEntryAccessBean();
        catEntryAb.setInitKey_catalogEntryReferenceNumber(catEntryId);
        catEntryAb.instantiateEntity();
        return catEntryAb;
    }
}
