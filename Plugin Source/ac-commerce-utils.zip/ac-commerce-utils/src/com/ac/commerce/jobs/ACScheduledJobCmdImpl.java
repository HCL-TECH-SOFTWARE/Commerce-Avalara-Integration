package com.ac.commerce.jobs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.ibm.commerce.base.objects.SchedulerStatusAccessBean;
import com.ibm.commerce.beans.DataBeanManager;
import com.ibm.commerce.command.AsyncControllerCommandImpl;
import com.ibm.commerce.command.CommandContext;
import com.ibm.commerce.command.ViewCommandContext;
import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.order.beans.OrderItemDataBean;
import com.ibm.commerce.scheduler.beans.SchedulerStatusDataBean;
import com.ibm.commerce.server.ECConstants;
import com.ibm.commerce.utils.TimestampHelper;
import com.ibm.ws.cache.servlet.CacheProxyResponse;
import com.ac.commerce.email.ACAttachment;
import com.ac.commerce.email.ACSendMsgCmd;
import com.ac.commerce.util.CommandFactory;
import com.ac.commerce.util.configuration.ACPropertyLoader;
import com.ac.commerce.util.configuration.ACPropertyLoaderFactory;
import com.ac.util.exception.ACRuntimeException;

/**
 * ACScheduledJobCmdImpl - base class with usable service methods (start/stop messages, track of success/failure, ...).
 * 
 * The class does not have its own logger, child class should pass its own logger to all methods
 */
@SuppressWarnings("serial")
public abstract class ACScheduledJobCmdImpl extends AsyncControllerCommandImpl {

    private static final String SCHEDULED_JOB_PROPERTIES_FILE = "com.ac.commerce.jobs.scheduled_job";
    private static final String PROP_SCHEDULED_JOB_EMAIL_FROM = "SCHEDULED_JOB_EMAIL_FROM";
    private static final String PROP_SCHEDULED_JOB_EMAIL_TO = "SCHEDULED_JOB_EMAIL_TO";
    private static final String PROP_SCHEDULED_JOB_REPOSITORY = "SCHEDULED_JOB_REPOSITORY";

    private static final String PARAM_INFO = "info";
    private static final String PARAM_DEBUG = "debug";
    private static final String PARAM_READONLY = "readonly";

    protected static final String NO_SPECIFIC_INFO = "No specific information.";

    private static final ACPropertyLoader PROPERTY_LOADER = ACPropertyLoaderFactory.getInstance();
    private static final String EMAIL_FROM = PROPERTY_LOADER.getString(SCHEDULED_JOB_PROPERTIES_FILE, PROP_SCHEDULED_JOB_EMAIL_FROM);
    private static final String EMAIL_TO = PROPERTY_LOADER.getString(SCHEDULED_JOB_PROPERTIES_FILE, PROP_SCHEDULED_JOB_EMAIL_TO);
    private static final String REPOSITORY = PROPERTY_LOADER.getString(SCHEDULED_JOB_PROPERTIES_FILE, PROP_SCHEDULED_JOB_REPOSITORY);

    private List<ACAttachment> contentToAdd = new ArrayList<ACAttachment>();
    private String errorMessage;
    private String throwableMessage;
    private boolean jobFailed;
    private String emailMessage;
    private TypedProperty emailProperties = new TypedProperty();
    private String emailSubject;
    private long startJobTime;

    private boolean info;
    private boolean debug;
    private boolean readonly;

    private ACJobLogger jobLogger;

    @Override
    public boolean preExecute() {
        jobLogger = new ACJobLogger(getClass(), getCommandIfName(), this);
        jobLogger.journalBeginJob();

        startJobTime = System.currentTimeMillis();
        info = getRequestProperties().containsKey(PARAM_INFO);
        if (info) {
            try {
                writeToResponse("Job information:<br/>" + getInfo());
            } catch (IOException e) {
                throw new ACRuntimeException(e);
            }
        }
        debug = getRequestProperties().containsKey(PARAM_DEBUG);
        readonly = getRequestProperties().containsKey(PARAM_READONLY);
        return info;
    }

    @Override
    public void postExecute() {
        jobLogger.journalEndJob();
        endJob();
    }

    protected String getInfo() {
        return "<br/>info=* - show information<br/>debug=* - send result to response<br/>readonly=* - execute job as readonly";
    }

    protected ACJobLogger getJobLogger() {
        if (jobLogger == null) {
            // NOTE! if jobLogger is null verify where it has used. It shouldn't be used in constructors and places
            // which executes before preExecute() method
            throw new IllegalStateException("JobLogger must not be used in constructors, field initializers, etc.");
        }
        return jobLogger;
    }

    private void updateJobStatus() {
        String methodName = "updateJobStatus";
        jobLogger.entering(methodName);
        try {
            Long jobInstanceId = getJobInstanceId();
            if (jobInstanceId != null) {
                SchedulerStatusAccessBean sBean = new SchedulerStatusAccessBean();
                sBean.setInitKey_instanceReferenceNumber(jobInstanceId.toString());
                sBean.setState(isJobFailed() ? ECConstants.EC_SCHED_STATE_COMPLETED_FAILED : ECConstants.EC_SCHED_STATE_COMPLETED);
                sBean.setResult(isJobFailed() ? ECConstants.EC_SCHED_RESULT_FAILED : ECConstants.EC_SCHED_RESULT_SUCCESS);
                sBean.setEnd(TimestampHelper.getCurrentTime());
                // TODO - NEED THIS COMMIT HERE IMPORTANT!!!!!
                //                sBean.commitCopyHelper();
                
                
            } else {
                jobLogger.warn(methodName, "The job was started by unknown activator (not scheduler).");
            }
        } catch (Exception e) {
            jobLogger.warn(methodName, "Error occured while updating job status.", e);
        } finally {
            jobLogger.exiting(methodName);
        }
    }

    /**
     * endJob - records the end of successful or failed job in log files with log level INFO, bypassing actual log threshold.
     * 
     * If the job has failed status, e-mail letter 'ScheduledJobStatusNotify' is built and sent
     */
    private void endJob() {
        String methodName = "endJob";
        jobLogger.entering(methodName);

        updateJobStatus();
        if (jobFailed) {
            try {
                if (emailSubject == null) {
                    emailSubject = isJobFailed() ? "Failed Job " + getClass().getName() : "Information " + getClass().getName();
                }
                sendMessage(EMAIL_TO, "ScheduledJobStatusNotify");

                jobLogger.info(methodName, "Email sent successfully to " + EMAIL_TO);
            } catch (Exception e) {
                jobLogger.warn(methodName, "Error occured while sending job info through e-mail.", e);
            }
        }
        jobLogger.exiting(methodName);
    }

    @SuppressWarnings("unchecked")
    protected void sendMessage(String emailTo, String msgType) throws ECException {
        CommandContext ctx = (CommandContext) getCommandContext().clone();
        ACSendMsgCmd cmdSendMsg = CommandFactory.createTask(ACSendMsgCmd.class, ctx);
        cmdSendMsg.setMsgType(msgType);
        cmdSendMsg.setStoreID(getStoreId());
        // Create properties to be passed to email jsp
        getEmailProperties().put("className", getClass().getName());
        if (getErrorMessage() != null) {
            getEmailProperties().put("errorMessage", getErrorMessage());
        }
        if (getEmailMessage() != null) {
            getEmailProperties().put("emailMessage", getEmailMessage());
        }
        if (getThrowableMessage() != null) {
            getEmailProperties().put("throwableMessage", getThrowableMessage());
        }
        if (getJobInstanceId() != null) {
            getEmailProperties().put("JobInstanceId", getJobInstanceId());
            getEmailProperties().put("JobReferenceId", getJobReferenceId());
        }
        if (!isJobFailed()) {
            getEmailProperties().put("messageHeader", "Information about job...");
            getEmailProperties().put("showStandardMessage", "false");
        } else {
            getEmailProperties().put("showStandardMessage", "true");
        }
        for (ACAttachment vo : contentToAdd) {
            if (vo.getContentType() == ACAttachment.FILE_DATA) {
                cmdSendMsg.attachFile(vo.getFile(), vo.getType());
            } else {
                cmdSendMsg.attachContent(vo.getData().getBytes(), vo.getName(), vo.getType());
            }
        }

        cmdSendMsg.compose(null, ctx, getEmailProperties());
        cmdSendMsg.setSubject(emailSubject);
        cmdSendMsg.setFrom(EMAIL_FROM);
        cmdSendMsg.setTo(emailTo);
        cmdSendMsg.sendTransacted();
        cmdSendMsg.execute();
    }

    protected void addAttachment(String data, String name, String type) {
        contentToAdd.add(new ACAttachment(data, name, type));
    }

    protected void writeToResponse(String str) throws IOException {
        CommandContext cc = getCommandContext();
        if (cc instanceof ViewCommandContext) { // the request is initiated from the web channel
            ((CacheProxyResponse) ((ViewCommandContext) cc).getResponse()).getOutputStream().print(str.replaceAll("\r", "<br/>"));
        } else {
            jobLogger.warn("writeToResponse", "Request initiator is not a web channel. Value to write: " + str);
        }
    }

    /**
     * @param errorMessage
     *            The errorMessage to set.
     */
    protected void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    protected void addErrorMessage(String errorMessage) {
        if (this.errorMessage != null) {
            this.errorMessage = this.errorMessage + "\n" + errorMessage;
        } else {
            this.errorMessage = errorMessage;
        }
    }

    /**
     * @return Returns the errorMessage.
     */
    protected String getErrorMessage() {
        return errorMessage;
    }

    /**
     * @param throwableMessage
     *            The throwableMessage to set.
     */
    protected void setThrowableMessage(String throwableMessage) {
        this.throwableMessage = throwableMessage;
    }

    /**
     * @return Returns the throwableMessage.
     */
    protected String getThrowableMessage() {
        return throwableMessage;
    }

    /**
     * @param emailMessage
     *            The emailMessage to set.
     */
    protected void setEmailMessage(String logMessage) {
        emailMessage = logMessage;
    }

    /**
     * @return Returns the emailMessage.
     */
    protected String getEmailMessage() {
        return emailMessage;
    }

    /**
     * @param jobFailed
     *            The jobFailed to set.
     */
    protected void setJobFailed(boolean errorOccured) {
        jobFailed = errorOccured;
    }

    /**
     * @return Returns the jobFailed.
     */
    protected boolean isJobFailed() {
        return jobFailed;
    }

    /**
     * @param emailProperties
     *            The emailProperties to set.
     */
    protected void setEmailProperties(TypedProperty emailProperties) {
        this.emailProperties = emailProperties;
    }

    /**
     * @return Returns the emailProperties.
     */
    protected TypedProperty getEmailProperties() {
        return emailProperties;
    }

    /**
     * @param emailSubject
     *            The emailSubject to set.
     */
    protected void setEmailSubject(String emailSubject) {
        this.emailSubject = emailSubject;
    }

    /**
     * @return Returns the emailSubject.
     */
    protected String getEmailSubject() {
        return emailSubject;
    }

    protected boolean isDebug() {
        return debug;
    }

    protected boolean isReadonly() {
        return readonly;
    }

    protected String getRepository() {
        return REPOSITORY;
    }
}
