package com.ac.commerce.jobs;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Formatter;
import java.util.logging.LogRecord;
import com.ibm.commerce.exception.ExceptionHandler;

/**
 * <code>SIJobLogFormatter</code> does custom formatting of log records
 * 
 * This is simplified SimpleFormatter code, redesigned to get very compact and efficient log file.
 */
public class ACJobLogFormatter extends Formatter {
    private static SimpleDateFormat DATE_FORMAT;

    public ACJobLogFormatter() {
        super();
    }

    @Override
    public String format(LogRecord r) {
        char lvl = r.getLevel().getName().charAt(0);
        String output = String.format("[%s] %c %s\n", getDateFormat().format(new Date()), lvl, formatMessage(r));
        if (null != r.getThrown()) {
            Throwable t = r.getThrown();
            output += String.format("Throwable occurred: %s\n", ExceptionHandler.convertStackTraceToString(t));
        }
        return output;
    }

    private SimpleDateFormat getDateFormat() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss:SSS");
        return dateFormat;
    }
}
