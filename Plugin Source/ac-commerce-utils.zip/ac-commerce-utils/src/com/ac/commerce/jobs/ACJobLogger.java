package com.ac.commerce.jobs;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.ibm.commerce.command.ControllerCommand;
import com.ac.commerce.util.configuration.ACPropertyLoader;
import com.ac.commerce.util.configuration.ACPropertyLoaderFactory;
import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.Tuple3;
import com.ac.util.Tuples;

public class ACJobLogger extends ACLogger {

    private static final ACLogger LOGGER = new ACLogger(ACJobLogger.class);
    private static final Map<String, Tuple3<Logger, FileHandler, String>> LOGGER_POOL = new ConcurrentHashMap<String, Tuple3<Logger, FileHandler, String>>();
    private static final ACPropertyLoader PROPERTY_LOADER = ACPropertyLoaderFactory.getInstance();

    private static final int DEFAULT_MAX_BYTES = 10000000;
    private static final int DEFAULT_ROTATION = 5;

    public static final String PROPERTIES_FILE = "com.ac.commerce.jobs.scheduled_job";
    public static final String LOG_DIRECTORY = "log.directory";
    public static final String LOG_JOURNAL_PATH = "log.journal.file";
    public static final String LOG_JOURNAL_ROTATION = "log.journal.rotation";
    public static final String LOG_JOURNAL_MAX_BYTES = "log.journal.maxbytes";

    public static final String LOG_SESSION_ROTATION = "log.session.rotation";
    public static final String LOG_SESSION_MAX_BYTES = "log.session.maxbytes";

    // Job journal variables
    private Logger journalLogger;
    private FileHandler journalFileHandler;
    private static String journalFileName = getProperty(LOG_JOURNAL_PATH);

    // Job session logger variables
    private String sessionFileName;
    private Logger sessionLogger;
    private FileHandler sessionFileHandler;

    private boolean jobFailed;
    private long startJobTime;

    private String cmdName;
    private Long jobInstanceId;

    // Used in log output, for example: [232002,93002,ReleaseToFulfillment]
    private String jobIdentification;

    public ACJobLogger(Class<?> loggedClass, String cmdName) {
        this(loggedClass, cmdName, null);
    }

    public ACJobLogger(Class<?> loggedClass, String cmdName, ControllerCommand cmd) {
        super(loggedClass);
        // if have full name like com.package.test.ClassName - take only class name
        this.cmdName = cmdName;

        if (cmd != null && cmd.getRequestProperties() != null) {
            jobInstanceId = cmd.getRequestProperties().getLong("jobInstanceId", null);
        }
        jobIdentification = String.format("%d [%s]", jobInstanceId, cmdName);
        initJournalLogger();
        initSessionLogger();
    }

    /**
     * Records the start of the job.
     * 
     * This method should be called as early as possibly to mark start of the job.
     * 
     * The processing includes:
     * 
     * 1) log the start in jobs journal 2) log the start in job log file 3) log the start in OOB logger in force mode (with log level INFO,
     * bypassing actual log threshold)
     */
    public void journalBeginJob() {
        startJobTime = System.currentTimeMillis();
        String msg = String.format("%s JOB IS STARTED. Detailed log file: %s", jobIdentification, getSessionFileName());
        journalLogger.info(msg);
        sessionLogger.info(msg);
        // to OOB
        LOGGER.forceLogInfo(msg);
    }

    /**
     * endJob - records the end of successful or failed job in log files with log level INFO, bypassing actual log threshold.
     * 
     * If the job has failed status, e-mail letter 'ScheduledJobStatusNotify' is built and sent
     */
    public void journalEndJob() {
        String status = !isJobFailed() ? "Success" : "FAILED!";
        String msg = String.format("%s JOB IS FINISHED. Status: %s, duration: %s", jobIdentification, status,
            (System.currentTimeMillis() - startJobTime)/(1000 * 60));
        journalLogger.info(msg);
        sessionLogger.info(msg);
        // to OOB
        LOGGER.forceLogInfo(msg);

        sessionFileHandler.close();
        // FIXME vmykhailov possible we need to close journalFileHandler only once, when the last job has processed.
        // Investigate how it works in concurrent env. when multiple jobs complete their work
        journalFileHandler.close();

        LOGGER_POOL.remove(journalFileName);
        LOGGER_POOL.remove(cmdName);
    }

    /**
     * Records the start of processing loop.
     * 
     * This method should be called before the job starts processing but after it knows the quantative parameters of work to be done.
     * 
     * For example, some job starts, calls beginJob() method, and executes SQLs thus building the list of orders to process. After that the
     * job should call beginProcessing() to inform how many orders it plan to process.
     * 
     * The processing includes:
     * 
     * 1) log the quantities info in jobs journal 2) log the quantities info in job log file 3) log the quantities info in OOB logger with
     * INFO level
     */
    public void journalBeginProcessing(String objectsNum) {
        String msg = String.format("%s Begin processing: %s", jobIdentification, objectsNum);
        journalLogger.info(msg); // to jobs journal
        sessionLogger.info(msg); // to OOB log file, limited to info level

        LOGGER.forceLogInfo(msg);
    }

    public void journalBeginProcessing() {
        journalBeginProcessing("");
    }

    /**
     * Records the end of processing loop.
     * 
     * This method should be called after the job finishes processing but before endJob.
     * 
     * The processing includes printing out calculated quantities of objects processed:
     * 
     * 1) log the processed quantities info in jobs journal 2) log the processed quantities info in job log file 3) log the processed
     * quantities info in OOB logger with INFO level
     */
    public void journalEndProcessing(String result) {
        String msg = String.format("%s Finished processing, results: %s", jobIdentification, result);
        journalLogger.info(msg);
        sessionLogger.info(msg);

        LOGGER.forceLogInfo(msg);
    }

    public void journalEndProcessing() {
        journalEndProcessing("");
    }

    /**
     * Generic method to write some specific message in jobs journal
     * 
     * @param record
     *            message to write in jobs journal
     */
    public void journalInfo(String record) {
        String msg = String.format("%s Message: %s", jobIdentification, record);
        journalLogger.info(msg); // to jobs journal
        sessionLogger.info(msg); // to OOB log file, limited to info level
    }

    public void setJobFailed(boolean jobFailed) {
        this.jobFailed = jobFailed;
    }

    public boolean isJobFailed() {
        return jobFailed;
    }

    public String getSessionFileName() {
        if (sessionFileName == null) {
            sessionFileName = getProperty(LOG_DIRECTORY) + File.separator + cmdName + ".log";
        }
        return sessionFileName;
    }

    private void initJournalLogger() {
        String methodName = "initJournalLogger";
        LOGGER.entering(methodName);

        try {
            if (LOGGER_POOL.containsKey(journalFileName)) {
                journalLogger = LOGGER_POOL.get(journalFileName)._1;
                journalFileHandler = LOGGER_POOL.get(journalFileName)._2;

                LOGGER.trace(methodName, "Getting journal logger from cache: {0}", journalFileName);
            } else {
                int maxBytes = getIntProperty(LOG_JOURNAL_MAX_BYTES, DEFAULT_MAX_BYTES);
                int rotationCount = getIntProperty(LOG_JOURNAL_ROTATION, DEFAULT_ROTATION);
                journalFileHandler = new FileHandler(journalFileName, maxBytes, rotationCount, true);
                journalFileHandler.setLevel(Level.ALL);
                journalFileHandler.setFormatter(new ACJobLogFormatter());
                // Initialize jobs journal logger
                // To work independently from other loggers
                journalLogger = Logger.getAnonymousLogger();
                // to NOT duplicate its messages to the root logger
                journalLogger.setUseParentHandlers(false);
                journalLogger.addHandler(journalFileHandler);
                journalLogger.setLevel(Level.ALL);
                // add to pool
                LOGGER_POOL.put(journalFileName, Tuples.tuple3(journalLogger, journalFileHandler, journalFileName));

                LOGGER.trace(methodName, "Create new journal logger and add it to cache: {0}", journalFileName);
            }
        } catch (IOException ex) {
            LOGGER.error(methodName, "IOException occurred", ex);
        } catch (SecurityException ex) {
            LOGGER.error(methodName, "SecurityException occurred", ex);
        }
        LOGGER.exiting(methodName);
    }

    private void initSessionLogger() {
        String methodName = "initSessionLogger";
        LOGGER.entering(methodName);

        try {
            if (LOGGER_POOL.containsKey(cmdName)) {
                sessionLogger = LOGGER_POOL.get(cmdName)._1;
                sessionFileHandler = LOGGER_POOL.get(cmdName)._2;
                sessionFileName = LOGGER_POOL.get(cmdName)._3;

                LOGGER.trace(methodName, "Getting session logger from cache: {0}={1}", cmdName, sessionFileName);
            } else {
                int maxBytes = getIntProperty(LOG_SESSION_MAX_BYTES, DEFAULT_MAX_BYTES);
                int rotationCount = getIntProperty(LOG_SESSION_ROTATION, DEFAULT_ROTATION);
                sessionFileName = getSessionFileName();
                sessionFileHandler = new FileHandler(sessionFileName, maxBytes, rotationCount, true);
                sessionFileHandler.setLevel(Level.ALL);
                sessionFileHandler.setFormatter(new ACJobLogFormatter());
                sessionLogger = Logger.getAnonymousLogger();
                sessionLogger.addHandler(sessionFileHandler);
                sessionLogger.setLevel(Level.ALL);
                // to NOT duplicate its messages to the root logger
                sessionLogger.setUseParentHandlers(false);
                // add to pool
                LOGGER_POOL.put(cmdName, Tuples.tuple3(sessionLogger, sessionFileHandler, sessionFileName));

                LOGGER.trace(methodName, "Create new session logger and add it to cache: {0}={1}", cmdName, sessionFileName);
            }
            setLogger(sessionLogger);
        } catch (IOException ex) {
            LOGGER.error(methodName, "IOException occurred", ex);
        } catch (SecurityException ex) {
            LOGGER.error(methodName, "SecurityException occurred", ex);
        }
        LOGGER.exiting(methodName);
    }

    private static String getProperty(String name) {
        return PROPERTY_LOADER.getString(PROPERTIES_FILE, name);
    }
    
    private static Integer getIntProperty(String name, int defaultValue) {
        return PROPERTY_LOADER.getInt(PROPERTIES_FILE, name, defaultValue);
    }

    @Override
    public Logger getLogger() {
        return sessionLogger;
    }

    public Logger getJournalLogger() {
        return journalLogger;
    }
}