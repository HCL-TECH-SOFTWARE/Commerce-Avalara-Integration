package com.ac.commerce.jobs;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

import com.ibm.commerce.exception.ECException;
import com.ac.commerce.util.ACCommerceConstants;

@SuppressWarnings("serial")
public abstract class ACFeedImportJobCmdImpl extends ACScheduledJobCmdImpl {

    public static final String CVS_DELETE_RECORD = "1";
    public static final char CVS_QUOTE_CHAR = '/';
    public static final char CVS_COLUMN_SEPARATOR = ',';
    public static final Integer CVS_LINES_TO_SKIP = 1;

    private CSVReader csvReader;
    private CSVWriter csvWriter;
    private String currentFile;
    protected Integer langId;

    @Override
    public boolean preExecute() {
        // TODO Auto-generated method stub
        return super.preExecute();
    }

    private CSVReader initCSVReader(String filePath) {
        String methodName = "initCSVReader";
        CSVReader reader = null;
        try {
            reader = new CSVReader(new FileReader(filePath), CVS_COLUMN_SEPARATOR, CVS_QUOTE_CHAR, CVS_LINES_TO_SKIP);
        } catch (FileNotFoundException e) {
            // if feed file not exist it is not error. It is OK situation, just do nothing
            getJobLogger().warn(methodName, e.getMessage(), e);
            return null;
        }
        return reader;
    }

    protected CSVReader getCSVReader(String filePath) {
        if (csvReader == null || !filePath.equals(currentFile)) {
            csvReader = initCSVReader(filePath);
            currentFile = filePath;
        }
        return csvReader;
    }

    private CSVWriter initCSVWriter(String filePath) {
        String methodName = "initCSVWriter";
        CSVWriter writer = null;
        try {
            writer = new CSVWriter(new FileWriter(filePath), CVS_COLUMN_SEPARATOR, CVS_QUOTE_CHAR);
        } catch (IOException e) {
            getJobLogger().error(methodName, e.getMessage(), e);
            return null;
        }
        return writer;
    }

    protected CSVWriter getCSVWriter(String filePath) {
        if (csvWriter == null || !filePath.equals(currentFile)) {
            csvWriter = initCSVWriter(filePath);
            currentFile = filePath;
        }
        return csvWriter;
    }

    @Override
    public void validateParameters() throws ECException {
        langId = getRequestProperties().getInteger(ACCommerceConstants.LANG_ID_PARAM, -1);
    }

    /**
     * Moves file to destination folder and adds date/time suffix
     *
     * @param file
     *            file to move
     * @param destFolder
     *            destination folder
     */
    protected void moveProcessedFile(File file, String destFolder) {
        String methodName = "moveProcessedFile";
        String baseName = FilenameUtils.getBaseName(file.getName());
        String extension = FilenameUtils.getExtension(file.getName());

        File destination = new File(destFolder);
        if (!destination.exists())
            destination.mkdirs();

        try {
            FileUtils.moveFile(file, new File(destination, baseName + buildDateTimeSuffix() + "." + extension));
        } catch (IOException e) {
            getJobLogger().error(methodName, "Cannot move file after processing of " + file.getName(), e);
        }
    }

    protected String buildDateTimeSuffix() {
        StringBuilder suffix = new StringBuilder();

        suffix.append("_").append(new SimpleDateFormat("yyyy-MM-dd'T'HH-mm-ss").format(new Date()));

        return suffix.toString();
    }
}
