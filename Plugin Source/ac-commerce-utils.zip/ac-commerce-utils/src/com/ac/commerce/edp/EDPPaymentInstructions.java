/**
 * 
 */
package com.ac.commerce.edp;

import java.math.BigDecimal;

import com.ibm.commerce.edp.api.EDPPaymentInstruction;
import com.ac.util.property.BigDecimalProperty;
import com.ac.util.property.LongProperty;

/**
 * Common utility class with helper methods to work with EDPPaymentInstruction
 * 
 * @author a.kudla
 */
public final class EDPPaymentInstructions {

    private EDPPaymentInstructions() {
        // Utility class
    }

    public static final LongProperty<EDPPaymentInstruction> ID = new LongProperty<EDPPaymentInstruction>() {

        @Override
        protected Long getVal(EDPPaymentInstruction bean) {
            return bean.getId();
        }
    };

    public static final BigDecimalProperty<EDPPaymentInstruction> AMOUNT = new BigDecimalProperty<EDPPaymentInstruction>() {

        @Override
        protected BigDecimal getVal(EDPPaymentInstruction bean) {
            return bean.getAmount();
        }
    };
}
