package com.ac.commerce.solr;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.response.QueryResponse;

import com.ac.commerce.util.ServiceHelper;

/**
 * Service that allow do direct queries to solr server
 * 
 * @author a.lebedinskiy <a.lebedinskiy>
 * 
 */
public interface SolrService {

    public static SolrService eINSTANCE = ServiceHelper.getLoggingProxy(SolrService.class, new SolrServiceImpl());

    /**
     * Execute query on solr server and returns result
     * 
     * @param indexType
     * @param query
     * @return
     * @throws SolrServiceException
     */
    public QueryResponse executeQuery(SolrServiceIndexType indexType, SolrQuery query) throws SolrServiceException;

    public static enum SolrServiceIndexType {
        CatalogGroup("CatalogGroup"), CatalogEntry("CatalogEntry"), UnstructuredContent("UnstructuredContent");
        private final String indexTypeName;

        SolrServiceIndexType(String name) {
            indexTypeName = name;
        }

        public String getIndexTypeName() {
            return indexTypeName;
        }
    }

    public static class SolrServiceException extends Exception {

        public SolrServiceException() {
            super();
        }

        public SolrServiceException(String message, Throwable cause) {
            super(message, cause);
        }

        public SolrServiceException(String message) {
            super(message);
        }

        public SolrServiceException(Throwable cause) {
            super(cause);
        }
    }
}
