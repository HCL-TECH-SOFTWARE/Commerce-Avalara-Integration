package com.ac.commerce.solr;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.xml.sax.SAXException;

import com.ibm.commerce.foundation.internal.server.services.search.config.solr.SolrSearchConfigurationRegistry;
import com.ibm.commerce.foundation.internal.server.services.search.config.solr.SolrSearchServerConfig;
import com.ibm.commerce.foundation.internal.server.services.search.util.SearchQueryHelper;
import com.ac.commerce.util.BeanUtils;
import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.context.ACCommandContextHelper;
import com.ac.util.context.ACCommandContextHelper.ACCommandContextHelperException;
import com.ac.util.exception.ACRuntimeException;

/**
 * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
 * 
 */
public class SolrServiceImpl implements SolrService {
    private static final ACLogger LOGGER = new ACLogger(BeanUtils.class);
    private static final int DEFAULT_LANG_ID = -1;
    private final Map iSolrServers = new ConcurrentHashMap();
    private Integer storeId;
    private Integer langId;

    public SolrServiceImpl() {
        String methodName = "<constructor>";
        try {
            storeId = ACCommandContextHelper.EINSTANCE.getThreadLocalCommandContext().getStoreId();
            langId = DEFAULT_LANG_ID;
        } catch (ACCommandContextHelperException e) {
            LOGGER.error(methodName, e.getMessage(), e);
            throw new ACRuntimeException(e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public QueryResponse executeQuery(SolrServiceIndexType indexType, SolrQuery query) throws SolrServiceException {
        QueryResponse queryResponse = null;
        try {

            SolrSearchConfigurationRegistry searchRegistry = SolrSearchConfigurationRegistry.getInstance();

            String indexName = indexType.getIndexTypeName();
            String core = searchRegistry.getCoreName(storeId, indexName, langId);
            SolrServer solrServer = getSolrServer(searchRegistry, core);

            int retries = 0;
            SolrSearchServerConfig solrSearchServerConfig = searchRegistry.getSolrSearchServerConfiguration(core);

            if (!solrSearchServerConfig.isEmbeddedServer() && solrSearchServerConfig.getCommonHttpServerConfig() != null
                && solrSearchServerConfig.getCommonHttpServerConfig().getMaxRetries() != null) {

                retries = solrSearchServerConfig.getCommonHttpServerConfig().getMaxRetries().intValue();
            }

            int retryTimeInterval = 1000;
            if (!solrSearchServerConfig.isEmbeddedServer() && solrSearchServerConfig.getCommonHttpServerConfig() != null
                && solrSearchServerConfig.getCommonHttpServerConfig().getRetryTimeInterval() != null) {

                retryTimeInterval = solrSearchServerConfig.getCommonHttpServerConfig().getRetryTimeInterval().intValue();
            }

            queryResponse = SearchQueryHelper.query(solrServer, query, org.apache.solr.client.solrj.SolrRequest.METHOD.POST, retries,
                retryTimeInterval);
        } catch (Exception e) {
            throw new SolrServiceException(e);
        }
        return queryResponse;
    }

    private SolrServer getSolrServer(SolrSearchConfigurationRegistry searchRegistry, String core) throws IOException,
        ParserConfigurationException, SAXException {
        SolrServer solrServer = (SolrServer) iSolrServers.get(core);
        if (solrServer == null) {
            solrServer = searchRegistry.getServer(core, null, null);
            iSolrServers.put(core, solrServer);
        }
        return solrServer;
    }
}
