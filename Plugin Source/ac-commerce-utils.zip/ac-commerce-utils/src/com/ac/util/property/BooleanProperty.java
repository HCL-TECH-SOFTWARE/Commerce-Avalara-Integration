/**
 * 
 */
package com.ac.util.property;

import com.ac.util.function.Predicate;

/**
 * @author a.kudla
 * 
 */
public abstract class BooleanProperty<Bean> extends Property<Bean, Boolean> {
    private final Predicate<Bean> PREDICATE = new Predicate<Bean>() {

        @Override
        public boolean test(Bean bean) {
            return getValue(bean).booleanValue();
        }
    };

    public Predicate<Bean> predicate() {
        return PREDICATE;
    }
}
