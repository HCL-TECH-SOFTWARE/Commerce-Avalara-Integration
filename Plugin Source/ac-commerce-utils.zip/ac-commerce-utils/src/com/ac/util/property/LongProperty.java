/**
 * 
 */
package com.ac.util.property;

/**
 * @author a.kudla
 * 
 */
public abstract class LongProperty<Bean> extends Property<Bean, Long> {

}
