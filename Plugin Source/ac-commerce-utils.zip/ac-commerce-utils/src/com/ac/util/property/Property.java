package com.ac.util.property;

import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.None;
import com.ac.util.Objects;
import com.ac.util.Option;
import com.ac.util.function.Function;
import com.ac.util.function.Predicate;

public abstract class Property<Bean, T> {
    public static final ACLogger LOGGER = new ACLogger(Property.class);

    private final Function<Bean, T> function = new Function<Bean, T>() {

        @Override
        public T apply(Bean bean) {
            return getValue(bean);
        }
    };

    protected abstract T getVal(Bean bean);

    public T getValue(Bean bean) {
        try {
            return getVal(bean);
        } catch (Exception e) {
            LOGGER.error("getValue", "Exception while retrieving value: ", e);
        }
        return null;
    }

    public Option<T> getValue(Option<Bean> bean) {
        if (bean.isDefined()) {
            return Option.of(getValue(bean.get()));
        }
        return None.instance();
    }

    public Function<Bean, T> function() {
        return function;
    }

    public Predicate<Bean> eq(final T value) {
        return new Predicate<Bean>() {

            @Override
            public boolean test(Bean bean) {
                return Objects.eq(getValue(bean), value);
            }

        };
    }

    public Predicate<Bean> isNull() {
        return new Predicate<Bean>() {

            @Override
            public boolean test(Bean bean) {
                return getValue(bean) == null;
            }

        };
    }

    public Predicate<Bean> isNotNull() {
        return isNull().not();
    }

    public Predicate<Bean> in(final T... values) {
        return new Predicate<Bean>() {

            @Override
            public boolean test(Bean bean) {
                return Objects.in(getValue(bean), values);
            }

        };
    }
}
