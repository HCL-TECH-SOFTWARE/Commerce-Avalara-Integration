/**
 * 
 */
package com.ac.util.property;

import java.math.BigDecimal;

/**
 * @author a.kudla
 * 
 */
public abstract class BigDecimalProperty<Bean> extends Property<Bean, BigDecimal> {

}
