package com.ac.util.property;

import org.apache.commons.lang.StringUtils;

import com.ac.util.function.Predicate;

public abstract class StringProperty<Bean> extends Property<Bean, String> {

    @Override
    protected abstract String getVal(Bean bean);

    public Predicate<Bean> equalsIgnoreCase(final String value) {
        return new Predicate<Bean>() {

            @Override
            public boolean test(Bean bean) {
                return StringUtils.equalsIgnoreCase(getValue(bean), value);
            }

        };
    }

}
