/**
 * 
 */
package com.ac.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * @author a.kudla
 * 
 */
public final class Maps {

    private Maps() {
        // Utility class
    }

    @Nonnull
    public static <K, V> Map<K, V> asMap(K key, V value) {
        Map<K, V> ret = new HashMap<K, V>();
        ret.put(key, value);
        return ret;
    }

    /**
     * Method put value to map cache
     * 
     * @param <K>
     *            cache key
     * @param <V>
     *            cache value
     * @param map
     *            cache map, type of Map<K, List<V>>
     * @param key
     * @param value
     */
    @SuppressWarnings("unchecked")
    public static <K, V> void putInCache(@Nullable Map<K, List<V>> map, K key, V value) {
        if (map != null) {
            if (map.containsKey(key)) {
                map.get(key).add(value);
            } else {
                map.put(key, Arrays.asList(value));
            }
        }
    }

    /**
     * Method put value to map cache, values across one cache cell can't duplicates
     * 
     * @param <K>
     *            cache key
     * @param <V>
     *            cache value
     * @param map
     *            cache map, type of Map<K, Set<V>>
     * @param key
     * @param value
     */
    @SuppressWarnings("unchecked")
    public static <K, V> void putInCacheSet(@Nullable Map<K, Set<V>> map, K key, V value) {
        if (map != null) {
            if (map.containsKey(key)) {
                map.get(key).add(value);
            } else {
                map.put(key, new HashSet<V>(Arrays.asList(value)));
            }
        }
    }
}
