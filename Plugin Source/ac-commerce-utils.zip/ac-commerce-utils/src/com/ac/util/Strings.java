package com.ac.util;

import java.util.List;

import org.apache.commons.lang.StringUtils;

public final class Strings {
    private Strings() {
    }

    public static String join(List<String> list, String separator) {
        if (list == null) {
            return "";
        }
        return StringUtils.join(list.iterator(), separator);
    }
}
