package com.ac.util;

/**
 * Represents null for {@link Option}
 * 
 * @author a.kudla
 * 
 * @param <T>
 */
public final class None<T> extends Option<T> {
    @SuppressWarnings("rawtypes")
    private static final None INSTANCE = new None();

    private None() {
        // /Singleton
    }

    @SuppressWarnings("unchecked")
    public static <T> None<T> instance() {
        return INSTANCE;
    }

    @Override
    public T get() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean isDefined() {
        return false;
    }

    @Override
    public String toString() {
        return "None";
    }
}
