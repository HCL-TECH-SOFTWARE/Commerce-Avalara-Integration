package com.ac.util;

/**
 * @author a.kudla
 * 
 *         2 tuple implementation for multiple request/response parameters.
 * @see http://en.wikipedia.org/wiki/Tuple
 * @param <First>
 * @param <Second>
 * @param <Third>
 */
public class Tuple<First, Second> {
    public final First _1;
    public final Second _2;

    public Tuple(First f, Second s) {
        _1 = f;
        _2 = s;
    }

    @Override
    public String toString() {
        return "Tuple [" + _1 + ", " + _2 + "]";
    }
}
