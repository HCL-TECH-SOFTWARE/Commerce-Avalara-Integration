package com.ac.util.httprequest;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

import com.ac.commerce.util.logging.ACLogger;

/**
 * Default implementation of {@link ACHttpRequestUtils}
 * 
 * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
 * 
 */
public class ACHttpRequestUtilsImpl implements ACHttpRequestUtils {
    private final static ACLogger LOGGER = new ACLogger(ACHttpRequestUtilsImpl.class);

    private static final String HTTP_X_FORWARDED_FOR = "HTTP_X_FORWARDED_FOR";
    private static final String HTTP_CLIENT_IP = "HTTP_CLIENT_IP";
    private static final String WL_PROXY_CLIENT_IP = "WL-Proxy-Client-IP";
    private static final String PROXY_CLIENT_IP = "Proxy-Client-IP";
    private static final String UNKNOWN = "unknown";
    private static final String X_FORWARDED_FOR = "X-Forwarded-For";
    private static final String[] IP_HEADERS_ARRAY = { X_FORWARDED_FOR, PROXY_CLIENT_IP, WL_PROXY_CLIENT_IP, HTTP_CLIENT_IP,
        HTTP_X_FORWARDED_FOR };

    /**
     * {@inheritDoc}
     */
    @Override
    public String getClientIpAddr(HttpServletRequest request) {
        String methodName = "getClientIpAddr";
        LOGGER.entering(methodName, request);
        String ip = StringUtils.EMPTY;
        if (null == request) {
            LOGGER.fine(methodName, "request == null so return empty value");

        } else {
            for (String headerName : IP_HEADERS_ARRAY) {
                ip = request.getHeader(headerName);
                LOGGER.fine(methodName, "ip from header '{0}' == {1}", headerName, ip);
                if (!StringUtils.isEmpty(ip) && !UNKNOWN.equalsIgnoreCase(ip)) {
                    LOGGER.fine(methodName, "ip from header '{0}' == {1} is determined so skip look at other headers", headerName, ip);
                    break;
                }
            }
            if (StringUtils.isEmpty(ip) || UNKNOWN.equalsIgnoreCase(ip)) {
                LOGGER.fine(methodName, "ip is not determined from headers so ip will be retrieved from getRemoteAddr");
                ip = request.getRemoteAddr();
                LOGGER.fine(methodName, "ip from request.getRemoteAddr() == {0}", ip);
            }
        }
        LOGGER.exiting(methodName, ip);
        return ip;
    }

}
