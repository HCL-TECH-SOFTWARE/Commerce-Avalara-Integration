package com.ac.util.httprequest;

import javax.servlet.http.HttpServletRequest;

import com.ac.commerce.util.ServiceHelper;
/**
 * Utils for http request
 * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
 *
 */
public interface ACHttpRequestUtils {
    /**
     * Singleton instance of {@link ACHttpRequestUtils}
     */
    ACHttpRequestUtils EINSTANCE = ServiceHelper.getLoggingProxy(ACHttpRequestUtils.class, new ACHttpRequestUtilsImpl());
    /**
     * Return client ip address in case request is null return empty string
     * @param request
     * @return
     */
    String getClientIpAddr(HttpServletRequest request);
}
