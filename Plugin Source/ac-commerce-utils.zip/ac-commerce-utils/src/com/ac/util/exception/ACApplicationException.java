/*
 * Created on May 16, 2007
 * 
 * TODO To change the template for this generated file go to Window - Preferences - Java - Code Style - Code Templates
 */
package com.ac.util.exception;

import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.ras.ECMessage;

/**
 * @author svg
 * 
 *         TODO To change the template for this generated type comment go to Window - Preferences - Java - Code Style - Code Templates
 */
public class ACApplicationException extends ECApplicationException {

    public ACApplicationException() {
        super();
    }

    public ACApplicationException(ECMessage msg, String className, String methodName) {
        super(msg, className, methodName);
    }

    public ACApplicationException(ECMessage msg, String className, String methodName, Object msgParam[]) {
        super(msg, className, methodName, msgParam);
    }

    public ACApplicationException(ECMessage msg, String className, String methodName, Object msgParam[], TypedProperty exceptionData) {
        super(msg, className, methodName, msgParam, exceptionData);
    }

    public ACApplicationException(ECMessage msg, String className, String methodName, Object msgParam[], TypedProperty exceptionData,
        boolean logMessage) {
        super(msg, className, methodName, msgParam, exceptionData, logMessage);
    }

    public ACApplicationException(ECMessage msg, String className, String methodName, Object msgParam[], String errorTaskName) {
        super(msg, className, methodName, msgParam, errorTaskName);
    }

    public ACApplicationException(ECMessage msg, String className, String methodName, Object msgParam[], String errorTaskName,
        TypedProperty exceptionData) {
        super(msg, className, methodName, msgParam, errorTaskName, exceptionData);
    }

    public ACApplicationException(ECMessage msg, String className, String methodName, Object msgParam[], String errorTaskName,
        TypedProperty exceptionData, boolean logMessage) {
        super(msg, className, methodName, msgParam, errorTaskName, exceptionData, logMessage);
    }

    public ACApplicationException(ECMessage msg, String className, String methodName, Object msgParam[], String errorTaskName,
        boolean logMessage) {
        super(msg, className, methodName, msgParam, errorTaskName, logMessage);
    }

    public ACApplicationException(ECMessage msg, String className, String methodName, Object msgParam[], boolean logMessage) {
        super(msg, className, methodName, msgParam, logMessage);
    }

    public ACApplicationException(ECMessage msg, String className, String methodName, String errorTaskName) {
        super(msg, className, methodName, errorTaskName);
    }

    public ACApplicationException(ECMessage msg, String className, String methodName, String errorTaskName, TypedProperty exceptionData) {
        super(msg, className, methodName, errorTaskName, exceptionData);
    }

    public ACApplicationException(ECMessage msg, String className, String methodName, String errorTaskName, TypedProperty exceptionData,
        boolean logMessage) {
        super(msg, className, methodName, errorTaskName, exceptionData, logMessage);
    }

    public ACApplicationException(ECMessage msg, String className, String methodName, String errorTaskName, boolean logMessage) {
        super(msg, className, methodName, errorTaskName, logMessage);
    }

    public ACApplicationException(ECMessage msg, String className, String methodName, boolean logMessage) {
        super(msg, className, methodName, logMessage);
    }

}
