package com.ac.util;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.ac.util.function.Predicate;

/**
 * 
 * Helper for enumerations manipulation.
 * 
 * @author a.kudla
 * 
 */
public final class Enumerations {
    private Enumerations() {
        // Utility class
    }

    /**
     * Returns first element from {@code en}. If {@code en} is null returns null.
     * 
     * @param <T>
     * @param {@code @Nullable} en
     * @return {@code @Nullable} element
     */
    @SuppressWarnings("unchecked")
    @Nullable
    public static <T> T first(@Nullable Enumeration en) {
        if (en == null || !en.hasMoreElements()) {
            return null;
        }

        return (T) en.nextElement();
    }

    /**
     * Creates list from enumeration {@code en}.
     * 
     * @param <T>
     * @param {@code @Nullable} en
     * @return {@code @Nonnull} list
     */
    @Nonnull
    @SuppressWarnings("unchecked")
    public static <T> List<T> asList(@SuppressWarnings("rawtypes") @Nullable Enumeration en) {
        List<T> ret = new ArrayList<T>();
        if (en == null) {
            return ret;
        }
        while (en.hasMoreElements()) {
            ret.add((T) en.nextElement());
        }
        return ret;
    }

    /**
     * Returns first element in {@code list} matching predicate {@code pred}. If {@code list} or {@code pred} is null returns null. If
     * {@code pred} doesn't match any element returns null.
     * 
     * @param <T>
     * @param {@code @Nullable} list
     * @param {@code @Nullable} pred
     * @return
     */
    @Nonnull
    public static <T> Option<T> find(@Nullable Enumeration<T> en, @Nullable Predicate<T> pred) {
        if (en == null || pred == null) {
            return None.instance();
        }
        while (en.hasMoreElements()) {
            T obj = en.nextElement();
            if (pred.test(obj)) {
                return new Some<T>(obj);
            }
        }
        return None.instance();
    }
}
