/**
 * 
 */
package com.ac.util.function;

import javax.annotation.Nonnull;

import com.ac.util.Tuple;
import com.ac.util.Tuples;
import com.ac.util.property.Property;

/**
 * @author a.kudla
 * 
 */
public final class Functions {

    private Functions() {
        // Utility class
    }

    public static <Bean, T1, T2> Function<Bean, Tuple<T1, T2>> tuple(@Nonnull final Property<Bean, T1> prop1,
        @Nonnull final Property<Bean, T2> prop2) {
        return new Function<Bean, Tuple<T1, T2>>() {

            @Override
            public Tuple<T1, T2> apply(Bean bean) {
                return Tuples.tuple(prop1.getValue(bean), prop2.getValue(bean));
            }
        };
    }

}
