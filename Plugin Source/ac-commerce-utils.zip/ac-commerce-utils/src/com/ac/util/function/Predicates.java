package com.ac.util.function;

import javax.annotation.Nonnull;

import org.apache.commons.lang.StringUtils;

import com.ac.util.Objects;

public final class Predicates {
    /**
     * @author a.kudla
     * 
     * @param <T>
     */
    public static final class Equals<T> extends Predicate<T> {
        /**
         * 
         */
        private final T second;

        /**
         * @param second
         */
        public Equals(T second) {
            this.second = second;
        }

        @Override
        public boolean test(T obj) {
            return Objects.eq(obj, second);
        }
    }

    private Predicates() {
        // Utility class
    }

    public static <T> Predicate<T> unit(final boolean val) {
        return new Predicate<T>() {
            @Override
            public boolean test(T value) {
                return val;
            }
        };
    }

    @Nonnull
    public static <T> Predicate<T> not(@Nonnull final Predicate<T> p) {
        return new Predicate<T>() {
            @Override
            public boolean test(T value) {
                return !p.test(value);
            }
        };
    }

    public static <T> Predicate<T> and(final Predicate<T>... predicates) {
        if (predicates == null || predicates.length == 0) {
            return Predicate.FALSE;
        }
        return new Predicate<T>() {

            @Override
            public boolean test(T value) {
                for (Predicate<T> pred : predicates) {
                    if (!pred.test(value)) {
                        return false;
                    }
                }
                return true;
            }
        };
    }

    public static <T> Predicate<T> or(final Predicate<T>... predicates) {
        if (predicates == null || predicates.length == 0) {
            return Predicate.FALSE;
        }
        return new Predicate<T>() {

            @Override
            public boolean test(T value) {
                for (Predicate<T> pred : predicates) {
                    if (pred.test(value)) {
                        return true;
                    }
                }
                return false;
            }
        };
    }

    public static <T> Predicate<T> or(final Predicate<T> first, final Predicate<T> second) {
        return new Predicate<T>() {

            @Override
            public boolean test(T value) {
                return first.test(value) || second.test(value);
            }
        };
    }

    public static <T> Predicate<T> eq(final T second) {
        return new Equals<T>(second);
    }

    public static StringPredicate equalsIgnoreCase(final String second) {
        return new StringPredicate(second) {

            @Override
            public boolean test(String first) {
                return StringUtils.equalsIgnoreCase(first, second);
            }
        };
    }

    public static StringPredicate startsWith(final String second) {
        return new StringPredicate(second) {

            @Override
            public boolean test(String first) {
                return first != null && second != null && first.startsWith(second);
            }
        };
    }
}
