package com.ac.util.function;

import java.io.Serializable;

/**
 * Apply a function to the input argument, yielding an appropriate result. A function may variously provide a mapping between types, object
 * instances or keys and values or any other form of transformation upon the input.
 * 
 * @param <T>
 *            the type of the input to the {@code apply} operation.
 * @param <R>
 *            the type of the result of the {@code apply} operation.
 * 
 */
public interface Function<T, R> extends Serializable {
    /**
     * Compute the result of applying the function to the input argument
     * 
     * @param t
     *            the input object
     * @return the function result
     */
    R apply(T value);
}
