package com.ac.util.function;

/**
 * Determines if the input object matches some criteria.
 * 
 * @param <T>
 *            the type of argument to {@code test}
 */
public abstract class Predicate<T> {
    /**
     * Returns {@code true} if the input object matches some criteria.
     * 
     * @param t
     *            the input object
     * @return {@code true} if the input object matches some criteria, otherwise {@code false}
     */

    public static final Predicate TRUE = new Predicate<Object>() {
        @Override
        public boolean test(Object value) {
            return true;
        }
    };

    public static final Predicate FALSE = new Predicate<Object>() {
        @Override
        public boolean test(Object value) {
            return false;
        }
    };

    public abstract boolean test(T value);

    public Predicate<T> not() {
        return Predicates.not(this);
    }

    public Predicate<T> and(Predicate<T> second) {
        return Predicates.and(this, second);
    }

    public Predicate<T> or(Predicate<T> second) {
        return Predicates.or(this, second);
    }
}
