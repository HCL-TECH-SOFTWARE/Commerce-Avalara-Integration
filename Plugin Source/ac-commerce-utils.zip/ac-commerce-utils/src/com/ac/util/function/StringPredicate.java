/**
 * 
 */
package com.ac.util.function;

/**
 * @author a.kudla
 * 
 */
public abstract class StringPredicate extends Predicate<String> {

    private final String second;

    /**
     * @param second
     */
    public StringPredicate(String second) {
        this.second = second;
    }

    @Override
    public abstract boolean test(String first);

    public String getSecond() {
        return second;
    }

}
