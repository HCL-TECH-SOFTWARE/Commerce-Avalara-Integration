package com.ac.util;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * 
 * Helper for arrays manipulation.
 * 
 * @author a.kudla
 * 
 */
public final class Arrays {
    private Arrays() {
        // Utility class
    }

    /**
     * Creates list from {@code array}.
     * 
     * @param <T>
     * @param {@code @Nullable} array
     * @return {@code @Nonnull} list
     */
    @Nonnull
    public static <T> List<T> asList(@Nullable T... array) {
        List<T> ret = new ArrayList<T>();
        if (array == null) {
            return ret;
        }
        for (T el : array) {
            ret.add(el);
        }
        return ret;
    }

    /**
     * Get first element from {@code array}. If {@code array} is empty returns null.
     * 
     * @param <T>
     * @param {@code @Nullable} array
     * @return {@code @Nullable} element.
     */
    @Nullable
    public static <T> T first(@Nullable T... array) {
        if (array == null || array.length == 0) {
            return null;
        }
        return array[0];
    }

    /**
     * Null-safe array copy
     * 
     * @param <T>
     *            array type
     * @param array
     *            array to copy
     * @param length
     *            array length
     * @return copy of array
     */
    @Nullable
    public static <T> T[] copyOf(@Nullable T[] array, int length) {
        return array == null ? null : java.util.Arrays.copyOf(array, length);
    }
}
