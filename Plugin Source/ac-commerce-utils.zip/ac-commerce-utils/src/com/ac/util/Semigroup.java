/**
 * 
 */
package com.ac.util;

import javax.annotation.Nullable;

import com.ac.util.function.BiFunction;

/**
 * 
 * A Semigroup in type S must satisfy two laws:
 * <ol>
 * <li>
 * Closure: for all a, b in S, append(a, b) is also in S. This is enforced by the type system.</li>
 * <li>
 * Associativity: for all a, b and c in S, the equation append(append(a, b), c) = append(a, append(b , c)) holds.</li>
 * </ol>
 * 
 * @author a.kudla
 * 
 */
public abstract class Semigroup<T> {
    private final BiFunction<T, T, T> function = new BiFunction<T, T, T>() {
        @Override
        public T apply(T t1, T t2) {
            return append(t1, t2);
        }
    };

    public abstract T append(@Nullable T t1, @Nullable T t2);

    public BiFunction<T, T, T> function() {
        return function;
    }

}
