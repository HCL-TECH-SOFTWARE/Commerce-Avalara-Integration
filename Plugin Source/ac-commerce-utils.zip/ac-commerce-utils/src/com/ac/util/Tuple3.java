package com.ac.util;

/**
 * @author a.kudla
 * 
 *         3 tuple implementation for multiple request/response parameters.
 * @see http://en.wikipedia.org/wiki/Tuple
 * 
 * @param <First>
 * @param <Second>
 * @param <Third>
 */
public class Tuple3<First, Second, Third> {
    public final First _1;
    public final Second _2;
    public final Third _3;

    public Tuple3(First f, Second s, Third t) {
        _1 = f;
        _2 = s;
        _3 = t;
    }
}