package com.ac.util;

import static com.ac.util.Semigroups.BIGDECIMAL_SEMIGROUP;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import org.apache.commons.lang3.ObjectUtils;

import com.ac.util.function.BiFunction;
import com.ac.util.function.Function;
import com.ac.util.function.Predicate;
import com.ac.util.property.BigDecimalProperty;
import com.ac.util.property.Property;

/**
 * 
 * Helper for list manipulation.
 * 
 * @author a.kudla
 * 
 */
public final class Lists {
    private Lists() {
        // Utility class
    }

    @Nonnull
    @SuppressWarnings("unchecked")
    public static <T> List<T> nonNull(@SuppressWarnings("rawtypes") @Nullable List list) {
        if (list == null) {
            return new ArrayList<T>();
        }
        return list;
    }

    @SuppressWarnings("unchecked")
    @Nullable
    public static <T> T head(@SuppressWarnings("rawtypes") @Nullable List list) {
        if (list == null || list.isEmpty()) {
            return null;
        }
        return (T) list.get(0);
    }

    @SuppressWarnings("unchecked")
    public static <T> T head(@SuppressWarnings("rawtypes") @Nullable List list, T defaultValue) {
        if (list == null || list.isEmpty()) {
            return defaultValue;
        }
        return Option.of((T) list.get(0)).getOrElse(defaultValue);
    }

    @SuppressWarnings("unchecked")
    @Nullable
    public static <T> List<T> tail(@SuppressWarnings("rawtypes") @Nullable List list) {
        if (list == null || list.isEmpty() || list.size() == 1) {
            return null;
        }
        return list.subList(1, list.size());
    }

    @SuppressWarnings("unchecked")
    @Nonnull
    public static <T> List<T> asList(@SuppressWarnings("rawtypes") @Nonnull Enumeration e) {
        List<T> ret = new ArrayList<T>();
        while (e.hasMoreElements()) {
            ret.add((T) e.nextElement());
        }
        return ret;
    }

    @Nonnull
    public static <T1, T2> Hashtable<T1, T2> asHashtable(@Nullable List<Tuple<T1, T2>> l) {
        Hashtable<T1, T2> ret = new Hashtable<T1, T2>();
        if (l != null) {
            for (Tuple<T1, T2> t : l) {
                ret.put(t._1, t._2);
            }
        }
        return ret;
    }

    @Nonnull
    public static <Bean, To> List<To> map(@Nullable List<Bean> list, @Nonnull Property<Bean, To> tr) {
        return map(list, tr.function());
    }

    @Nonnull
    public static <From, To> List<To> map(@Nullable List<From> list, @Nullable Function<From, To> tr) {
        List<To> ret = new ArrayList<To>();
        if (list == null || tr == null) {
            return ret;
        }
        for (From f : list) {
            ret.add(tr.apply(f));
        }
        return ret;
    }

    public static <From> void foreach(@Nullable List<From> list, @Nullable Function<From, Void> func) {
        if (list == null || func == null) {
            return;
        }
        for (From f : list) {
            func.apply(f);
        }
    }

    @Nonnull
    public static <T> Tuple<List<T>, List<T>> partition(@Nullable List<T> list, @Nonnull Predicate<T> pred) {
        List<T> first = newArrayList();
        List<T> second = newArrayList();
        Tuple<List<T>, List<T>> ret = Tuples.tuple(first, second);
        if (list != null) {
            for (T el : list) {
                if (pred.test(el)) {
                    first.add(el);
                } else {
                    second.add(el);
                }
            }
        }
        return ret;
    }

    @Nullable
    public static <A, B> A foldl(@Nullable List<B> list, A zero, BiFunction<A, B, A> f) {
        A res = zero;
        if (list != null) {
            for (B b : list) {
                res = f.apply(res, b);
            }
        }
        return res;
    }

    @Nonnull
    public static <Bean> BigDecimal sum(@Nullable List<Bean> list, @Nonnull BigDecimalProperty<Bean> pr) {
        BigDecimal res = foldl(list, BigDecimal.ZERO, Semigroups.biFunction(BIGDECIMAL_SEMIGROUP, pr));
        return res == null ? BigDecimal.ZERO : res;
    }

    @Nonnull
    public static <T> ArrayList<T> newArrayList(T... ts) {
        ArrayList<T> res = new ArrayList<T>();
        if (ts != null) {
            Collections.addAll(res, ts);
        }
        return res;
    }

    @Nonnull
    public static <T> ArrayList<T> newArrayList(Collection<T> c) {
        return new ArrayList<T>(c);
    }

    @Nonnull
    public static <T> String[] toStringArray(Collection<T> c) {
        if (c == null || c.isEmpty()) {
            return new String[0];
        }

        String[] result = new String[c.size()];
        int i = 0;
        for (T t : c) {
            result[i++] = ObjectUtils.toString(t);
        }
        return result;
    }

    public static <T> List<T> unmodifiableList(T... t) {
        return Collections.unmodifiableList(Arrays.asList(t));
    }
}
