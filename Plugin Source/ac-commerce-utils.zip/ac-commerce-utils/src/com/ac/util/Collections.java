package com.ac.util;

import java.util.Collection;
import java.util.Iterator;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.ac.util.function.Predicate;

/**
 * 
 * Helper for collections manipulation.
 * 
 * @author a.kudla
 * 
 */
public final class Collections {
    private Collections() {
        // Utility class.
    }

    /**
     * Filters collection {@code col} with predicate {@code pred}. If {@code col} or {@code pred} is null returns null.
     * 
     * @param <T>
     * @param {@code @Nullable} col
     * @param {@code @Nullable} pred
     */
    public static <T> void filter(@Nullable Collection<T> col, @Nullable Predicate<T> pred) {
        if (col == null || pred == null) {
            return;
        }
        Iterator<T> it = col.iterator();
        while (it.hasNext()) {
            T obj = it.next();
            if (pred.test(obj)) {
                continue;
            }
            it.remove();
        }

    }

    /**
     * Returns first element in {@code list} matching predicate {@code pred}. If {@code list} or {@code pred} is null returns null. If
     * {@code pred} doesn't match any element returns null.
     * 
     * @param <T>
     * @param {@code @Nullable} coll
     * @param {@code @Nullable} pred
     * @return
     */
    @Nonnull
    public static <T> Option<T> find(@Nullable Collection<T> coll, @Nullable Predicate<T> pred) {
        if (coll == null || pred == null) {
            return None.instance();
        }
        for (T obj : coll) {
            if (pred.test(obj)) {
                return new Some<T>(obj);
            }
        }
        return None.instance();
    }

    /**
     * Null-safe size check for two collections
     * 
     * @param c1
     *            collection 1
     * @param c2
     *            collection 2
     * @return true if size of both collections is equal, otherwise false
     */
    public static boolean isSizeEquals(@Nullable Collection<?> c1, @Nullable Collection<?> c2) {
        return c1 != null && c2 != null && c1.size() == c2.size();
    }

}
