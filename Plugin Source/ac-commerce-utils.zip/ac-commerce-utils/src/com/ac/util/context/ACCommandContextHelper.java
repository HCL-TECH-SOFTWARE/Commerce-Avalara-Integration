package com.ac.util.context;

import com.ibm.commerce.command.CommandContext;
import com.ibm.commerce.foundation.common.datatypes.BusinessContextType;
import com.ac.commerce.util.ServiceHelper;

/**
 * Helper for standard operations with commandContext
 * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
 *
 */
public interface ACCommandContextHelper {
    ACCommandContextHelper EINSTANCE = ServiceHelper.getLoggingProxy(ACCommandContextHelper.class, new ACCommandContextHelperImpl());
    /**
     * Return CommandContext that correspond to current thread
     * @return
     */
    CommandContext getThreadLocalCommandContext() throws ACCommandContextHelperException;
    /**
     * Convert commandContext to businessContext
     * @param commandContext
     * @return
     */
    BusinessContextType convertToBusinessContext(CommandContext commandContext) throws ACCommandContextHelperException;
    
    /**
     * Exception for {@link ACCommandContextHelper} methods Unique type of exception give us ability easy to determine class where
     * this exception were thrown Also there are sonar rule that do not allow throw java.lang.Exception
     * "Signature Declare Throws Exception method/constructor shouldn't explicitly throw java.lang.Exception" {@link https
     * ://dev.eclipse.org/sonar/rules/show/pmd:SignatureDeclareThrowsException?layout=false}
     * 
     * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
     * 
     */
    class ACCommandContextHelperException extends Exception{

        public ACCommandContextHelperException() {
            super();
        }

        public ACCommandContextHelperException(String message, Throwable cause) {
            super(message, cause);
        }

        public ACCommandContextHelperException(String message) {
            super(message);
        }

        public ACCommandContextHelperException(Throwable cause) {
            super(cause);
        }
        
    }
}
