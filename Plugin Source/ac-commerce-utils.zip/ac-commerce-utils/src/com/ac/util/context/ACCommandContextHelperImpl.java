package com.ac.util.context;

import com.ibm.commerce.command.CommandContext;
import com.ibm.commerce.component.contextservice.ActivityToken;
import com.ibm.commerce.component.contextservice.BusinessContextServiceFactory;
import com.ibm.commerce.component.contextserviceimpl.BusinessContextInternalService;
import com.ibm.commerce.context.base.BaseContext;
import com.ibm.commerce.context.baseimpl.ContextHelper;
import com.ibm.commerce.foundation.common.datatypes.BusinessContextType;
import com.ibm.commerce.foundation.common.datatypes.CommerceFoundationFactory;
import com.ibm.commerce.foundation.common.datatypes.ContextDataType;
import com.ac.commerce.util.logging.ACLogger;
/**
 * Default implementation of {@link ACCommandContextHelper}
 * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
 *
 */
public class ACCommandContextHelperImpl implements ACCommandContextHelper {
    private static final ACLogger LOGGER = new ACLogger(ACCommandContextHelperImpl.class);

    /**
     * {@inheritDoc}
     */
    @Override
    public CommandContext getThreadLocalCommandContext() throws ACCommandContextHelperException {
        String methodName = "getThreadLocalCommandContext";
        LOGGER.entering(methodName);
        CommandContext commandContext = null;
        try{
        ActivityToken newToken = ((BusinessContextInternalService) BusinessContextServiceFactory
            .getBusinessContextService()).getActivityToken();
        commandContext = ContextHelper.createCommandContext(newToken);
        }catch (RuntimeException e) {
            throw new ACCommandContextHelperException(e);
        }
        if(null == commandContext){
            LOGGER.fine(methodName, "command Context is null");
            throw new ACCommandContextHelperException("Not found command context in current Thread");
        }
        LOGGER.exiting(methodName, commandContext);
        return commandContext;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BusinessContextType convertToBusinessContext(CommandContext commandContext) throws ACCommandContextHelperException {
        String methodName = "convertToBusinessContext(CommandContext commandContext)";
        LOGGER.entering(methodName, commandContext);
        BusinessContextType businessContext = CommerceFoundationFactory.eINSTANCE.createBusinessContextType();

        ContextDataType contextData = CommerceFoundationFactory.eINSTANCE.createContextDataType();
        contextData.setName(BaseContext.KEY_STORE_ID);
        contextData.setValue(commandContext.getStoreId().toString());
        businessContext.getContextData().add(contextData);
        LOGGER.fine(methodName, "Context data type for '{0} is {1}'", BaseContext.KEY_STORE_ID, contextData);

        contextData = CommerceFoundationFactory.eINSTANCE.createContextDataType();
        contextData.setName(BaseContext.KEY_USER_ID);
        contextData.setValue(commandContext.getUserId().toString());
        businessContext.getContextData().add(contextData);
        LOGGER.fine(methodName, "Context data type for '{0} is {1}'", BaseContext.KEY_USER_ID, contextData);

        contextData = CommerceFoundationFactory.eINSTANCE.createContextDataType();
        contextData.setName(BaseContext.KEY_CHANNEL_ID);
        contextData.setValue(BaseContext.CHANNEL_ID_WEB);
        businessContext.getContextData().add(contextData);
        LOGGER.fine(methodName, "Context data type for '{0} is {1}'", BaseContext.KEY_CHANNEL_ID, contextData);

        LOGGER.exiting(methodName, businessContext);
        return businessContext;
    }

}
