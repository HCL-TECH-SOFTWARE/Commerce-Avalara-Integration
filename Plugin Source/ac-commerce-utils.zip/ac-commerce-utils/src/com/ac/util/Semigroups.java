/**
 * 
 */
package com.ac.util;

import java.math.BigDecimal;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.ac.util.function.BiFunction;
import com.ac.util.property.Property;

/**
 * @author a.kudla
 * 
 */
public final class Semigroups {

    public static final Semigroup<BigDecimal> BIGDECIMAL_SEMIGROUP = new Semigroup<BigDecimal>() {

        @Override
        public BigDecimal append(@Nullable BigDecimal t1, @Nullable BigDecimal t2) {
            if (t1 == null) {
                return t2;
            }
            if (t2 == null) {
                return t1;
            }
            return t1.add(t2);
        }
    };

    private Semigroups() {
        // Utility class
    }

    public static <T, Bean> BiFunction<T, Bean, T> biFunction(@Nonnull final Semigroup<T> semi, @Nonnull final Property<Bean, T> prop) {
        return new BiFunction<T, Bean, T>() {

            @Override
            public T apply(T t, Bean bean) {
                return semi.append(t, prop.getValue(bean));
            }

        };
    }

}
