/*
 * Created on May 16, 2007
 * 
 * TODO To change the template for this generated file go to Window - Preferences - Java - Code Style - Code Templates
 */
package com.ac.util.messages;

import com.ibm.commerce.ras.ECMessage;
import com.ibm.commerce.ras.ECMessageSeverity;
import com.ibm.commerce.ras.ECMessageType;

/**
 * @author svg
 * 
 *         TODO To change the template for this generated type comment go to Window - Preferences - Java - Code Style - Code Templates
 */
public class ACMessage extends ECMessage {
    public final static String SI_MESSAGES_RESOURCE_BUNDLE = "com.ac.util.messages.SIMessages";
    // make if this is system or user error
    public static final int USER = ECMessageType.USER;
    public static final int SYSTEM = ECMessageType.SYSTEM;

    // message severities
    public static final long ERROR = ECMessageSeverity.ERROR;
    public static final long WARNING = ECMessageSeverity.WARNING;
    public static final long STATUS = ECMessageSeverity.STATUS;
    public static final long INFO = ECMessageSeverity.INFO;

    public ACMessage(long msgSeverity, int msgType, String msgKey) {
        super(msgSeverity, msgType, msgKey, SI_MESSAGES_RESOURCE_BUNDLE);
    }

    // Add your messages here
    public static final ACMessage _ERR_GENERIC_WHILE_SENDING_FROOGLE_FEED = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_GENERIC_WHILE_SENDING_FROOGLE_FEED);
    public static final ACMessage _ERR_GENERIC_WHILE_SENDING_AMAZON_FEED = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_GENERIC_WHILE_SENDING_AMAZON_FEED);

    public static final ACMessage _ERR_GENERIC_WHILE_SENDING_TRAFFICLEADER_PRODUCT_FEED = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_GENERIC_WHILE_SENDING_TRAFFICLEADER_PRODUCT_FEED);
    public static final ACMessage _ERR_GENERIC_WHILE_TRANSFERRING_FILE = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_GENERIC_WHILE_TRANSFERRING_FILE);
    public static final ACMessage _ERR_INVALID_PRODUCT_ID_AS_PARAMETER = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_INVALID_PRODUCT_ID_AS_PARAMETER);
    public static final ACMessage _ERR_GENERIC_ERROR_OCCURED_PR_NEWPRODUCT = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_GENERIC_ERROR_OCCURED_PR_NEWPRODUCT);
    public static final ACMessage _ERR_GENERIC_ERROR_OCCURED_PR_CATHIER = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_GENERIC_ERROR_OCCURED_PR_CATHIER);
    public static final ACMessage _ERR_INVALID_EMAIL_ATTACHMENT = new ACMessage(ERROR, USER, ACMessageKey._ERR_INVALID_EMAIL_ATTACHMENT);
    public static final ACMessage _ERR_INVALID_SHIPMETHOD_SELECTED_STATE = new ACMessage(INFO, USER,
        ACMessageKey._ERR_INVALID_SHIPMETHOD_SELECTED_STATE);
    public static final ACMessage _ERR_INVALID_METHOD_OF_PAYMENT = new ACMessage(INFO, USER, ACMessageKey._ERR_INVALID_METHOD_OF_PAYMENT);
    public static final ACMessage _ERR_WHILE_ACTIVATING_GIFT_CART = new ACMessage(INFO, USER, ACMessageKey._ERR_WHILE_ACTIVATING_GIFT_CART);
    public static final ACMessage _ERR_BLANK_SECURITY_CODE = new ACMessage(INFO, USER, ACMessageKey._ERR_BLANK_SECURITY_CODE);
    public static final ACMessage _ERR_INVALID_GIVEX_RESPONSE = new ACMessage(INFO, USER, ACMessageKey._ERR_INVALID_GIVEX_RESPONSE);

    public static final ACMessage _ERR_ERROR_OCCURED_WHILE_SENDING_BACKORDER_FEED = new ACMessage(INFO, USER,
        ACMessageKey._ERR_ERROR_OCCURED_WHILE_SENDING_BACKORDER_FEED);
    public static final ACMessage _ERR_READING_BACKORDER_PARAMS = new ACMessage(INFO, USER, ACMessageKey._ERR_ERR_READING_BACKORDER_PARAMS);
    public static final ACMessage _ERR_REQUIRED_FIELD_AS_PARAMETER = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_REQUIRED_FIELD_AS_PARAMETER);
    public static final ACMessage _ERR_ONE_ENTRY_PER_CONTEST_ONLY = new ACMessage(ERROR, USER, ACMessageKey._ERR_ONE_ENTRY_PER_CONTEST_ONLY);
    public static final ACMessage _ERR_INVALID_EMAIL_ID = new ACMessage(ERROR, USER, ACMessageKey._ERR_INVALID_EMAIL_ID);
    public static final ACMessage _ERR_WHILE_SENDING_GIFTCARD_INFOMATION = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_WHILE_SENDING_GIFTCARD_INFOMATION);
    public static final ACMessage _ERR_INVALID_BESTSELLER_FORMAT = new ACMessage(ERROR, USER, ACMessageKey._ERR_INVALID_BESTSELLER_FORMAT);
    public static final ACMessage _ERR_INVALID_SHIPPING_BILLING_DATA = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_INVALID_SHIPPING_BILLING_DATA);
    public static final ACMessage _ERR_EMAIL_ID_NOT_MATCH = new ACMessage(ERROR, USER, ACMessageKey._ERR_EMAIL_ID_NOT_MATCH);
    public static final ACMessage _ERR_STATE_NOT_REQUIRED = new ACMessage(ERROR, USER, ACMessageKey._ERR_STATE_NOT_REQUIRED);
    public static final ACMessage _ERR_ANY_AS_PARAMETER = new ACMessage(ERROR, USER, ACMessageKey._ERR_ANY_AS_PARAMETER);
    public static final ACMessage _ERR_ACTIVATING_GIFT_CARD = new ACMessage(INFO, USER, ACMessageKey._ERR_ACTIVATING_GIFT_CARD);
    public static final ACMessage _ERR_WHILE_DELETING_ORDERITEMS_EXT = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_WHILE_DELETING_ORDERITEMS_EXT);
    public static final ACMessage _ERR_NO_FILE_PROVIDED_FOR_MIGRATION = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_NO_FILE_PROVIDED_FOR_MIGRATION);
    public static final ACMessage _ERR_INVALID_QUICKORDER_ITEM = new ACMessage(ERROR, USER, ACMessageKey._ERR_INVALID_QUICKORDER_ITEM);
    public static final ACMessage _ERR_WHILE_COMMITING_USER_MIG_TRANSACTION = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_WHILE_COMMITING_USER_MIG_TRANSACTION);
    public static final ACMessage _ERR_INVALID_CHALLENGE_ANSWER = new ACMessage(ERROR, USER, ACMessageKey._ERR_INVALID_CHALLENGE_ANSWER);
    public static final ACMessage _ERR_FROOGLE_WHILE_MOVING_FILE = new ACMessage(ERROR, USER, ACMessageKey._ERR_FROOGLE_WHILE_MOVING_FILE);
    public static final ACMessage _ERR_TRAFFICLEADER_WHILE_MOVING_FILE = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_TRAFFICLEADER_WHILE_MOVING_FILE);

    public static final ACMessage _ERR_NO_TRACKINVENTORY_FLAG = new ACMessage(INFO, USER, ACMessageKey._ERR_NO_TRACKINVENTORY_FLAG);

    public static final ACMessage _ERR_INVALID_PROMO_CODE = new ACMessage(INFO, USER, ACMessageKey._ERR_INVALID_PROMO_CODE);
    public static final ACMessage _ERR_INVALID_GIFTCARD_AMOUNT = new ACMessage(INFO, USER, ACMessageKey._ERR_INVALID_GIFTCARD_AMOUNT);
    public static final ACMessage _ERR_INVALID_CARD_CVV2 = new ACMessage(INFO, USER, ACMessageKey._ERR_INVALID_CARD_CVV2);

    public static final ACMessage _ERR_GIFT_CARD_ALREADY_PRESENT = new ACMessage(INFO, USER, ACMessageKey._ERR_GIFT_CARD_ALREADY_PRESENT);
    public static final ACMessage _ERR_GIFT_CARD_DUPLICATED_NUMBER = new ACMessage(INFO, USER,
        ACMessageKey._ERR_GIFT_CARD_DUPLICATED_NUMBER);
    public static final ACMessage _ERR_GIFT_CARD_ORDER_TOTAL_ZERO = new ACMessage(INFO, USER, ACMessageKey._ERR_GIFT_CARD_ORDER_TOTAL_ZERO);
    public static final ACMessage _ERR_GIFT_CARD_NUMBER_EXCEED = new ACMessage(INFO, USER, ACMessageKey._ERR_GIFT_CARD_NUMBER_EXCEED);

    public static final ACMessage _ERR_GIFT_CARD_INVALID_NUMBER_PIN = new ACMessage(INFO, USER,
        ACMessageKey._ERR_GIFT_CARD_INVALID_NUMBER_PIN);
    public static final ACMessage _ERR_GIFT_CARD_UNEXPECTED_ERROR = new ACMessage(INFO, USER, ACMessageKey._ERR_GIFT_CARD_UNEXPECTED_ERROR);

    public static final ACMessage _ERR_SB_NICKNAME_ALREDY_EXIST = new ACMessage(ERROR, USER, ACMessageKey._ERR_SB_NICKNAME_ALREDY_EXIST);
    public static final ACMessage _ERR_EXCEPTION_OCCURED_WHILE_GETTING_ORDER_ID = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_EXCEPTION_OCCURED_WHILE_GETTING_ORDER_ID);

    public static final ACMessage _ERR_UPDATING_HSBC_PROMO_CODE = new ACMessage(ERROR, USER, ACMessageKey._ERR_UPDATING_HSBC_PROMO_CODE);

    public static final ACMessage _ERR_ESP_PRESENT_WITH_OUT_MAIN_ITEM = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_ESP_PRESENT_WITH_OUT_MAIN_ITEM);

    public static final ACMessage _ERR_INVALID_USER_BIRTH_DATE = new ACMessage(ERROR, USER, ACMessageKey._ERR_INVALID_USER_BIRTH_DATE);
    public static final ACMessage _ERR_INVALID_RETURN_CREDIT_ADJUSTMENT = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_INVALID_RETURN_CREDIT_ADJUSTMENT);
    public static final ACMessage _ERR_BAD_INVENTORY = new ACMessage(ERROR, USER, ACMessageKey._ERR_BAD_INVENTORY);
    public static final ACMessage _ERR_NO_SHIPPING_MODES_AVAIL = new ACMessage(ERROR, USER, ACMessageKey._ERR_NO_SHIPPING_MODES_AVAIL);
    public static final ACMessage _ERR_INVALID_SHIP_MODE_IN_ORDER = new ACMessage(ERROR, USER, ACMessageKey._ERR_INVALID_SHIP_MODE_IN_ORDER);

    public static final ACMessage _ERR_WHILE_UPDATING_EDP_RECORD = new ACMessage(ERROR, USER, ACMessageKey._ERR_WHILE_UPDATING_EDP_RECORD);
    public static final ACMessage _ERR_NON_BUYABLE_PRODUCT = new ACMessage(ERROR, USER, ACMessageKey._ERR_NON_BUYABLE_PRODUCT);
    public static final ACMessage _ERR_VALID_SHIPMETHODS_NOT_AVAILABLE = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_VALID_SHIPMETHODS_NOT_AVAILABLE);

    public static final ACMessage _ERR_INVALID_GERS_EMPLOYEE_ID = new ACMessage(ERROR, USER, ACMessageKey._ERR_INVALID_GERS_EMPLOYEE_ID);

    public static final ACMessage _ERR_INVALID_PARAMS_FOR_RESENT_EMAIL = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_INVALID_PARAMS_FOR_RESENT_EMAIL);
    public static final ACMessage _ERR_WHILE_PROCESSING_GIFT_CART = new ACMessage(ERROR, USER, ACMessageKey._ERR_WHILE_PROCESSING_GIFT_CART);

    public static final ACMessage _ERR_WHILE_RESENDING_GIFTCARD_INFORMATION = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_WHILE_RESENDING_GIFTCARD_INFORMATION);

    public static final ACMessage _ERR_INVALID_GIFTCARD_STATUS_FOR_RESEND = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_INVALID_GIFTCARD_STATUS_FOR_RESEND);

    public static final ACMessage _ERR_CMD_PARAM_INVALID_LENGTH = new ACMessage(ERROR, USER, ACMessageKey._ERR_CMD_PARAM_INVALID_LENGTH);

    public static final ACMessage _ERR_OMNIFIND_REQUIRED_PARAMETER = new ACMessage(ERROR, USER,
        ACMessageKey._ERR_OMNIFIND_REQUIRED_PARAMETER);

    public static final ACMessage _ERR_ADDRESS_HELPER = new ACMessage(ERROR, USER, ACMessageKey._ERR_ADDRESS_HELPER);

    public static final ACMessage _BAD_SHIPPING_COUNTRY = new ACMessage(ERROR, USER, ACMessageKey._BAD_SHIPPING_COUNTRY);
}
