package com.ac.util.profiler;

import java.util.List;

import com.ac.util.profiler.impl.dto.ACProfileTreeElementDto;

public interface ACProfileTree {
    public List<ACProfileTreeElementDto> getRoot();
}
