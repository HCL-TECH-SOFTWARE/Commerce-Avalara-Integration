package com.ac.util.profiler.impl;

import javax.servlet.ServletRequest;

import com.ac.util.profiler.ACProfileTree;
import com.ac.util.profiler.ACProfiler;

/**
 * Dummy implementation of ACProfiler This implementation do nothing to save time
 * 
 * @author a.lebedinskiy <a.lebedinskiy@sysiq.com>
 * 
 */
public class ACProfilerDummyImpl implements ACProfiler {

    /**
     * {@inheritDoc}
     */
    @Override
    public void start(String label, ServletRequest request) {
        /**
         * No operation :-)
         */
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void stop(String label, ServletRequest request) {
        /**
         * No operation :-)
         */
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void stop(String label, String replaceToLabel, ServletRequest request) {
        /**
         * No operation :-)
         */
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isDummy() {
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ACProfileTree getProfileTree(ServletRequest request) {
        /**
         * No operation :-)
         */
        return null;
    }

}
