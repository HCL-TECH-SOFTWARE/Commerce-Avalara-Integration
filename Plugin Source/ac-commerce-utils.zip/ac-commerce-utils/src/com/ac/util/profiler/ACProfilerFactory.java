package com.ac.util.profiler;

import java.util.Properties;

import org.apache.commons.lang3.BooleanUtils;

import com.ac.commerce.util.configuration.ACPropertyLoaderFactory;
import com.ac.util.profiler.impl.ACProfilerDummyImpl;
import com.ac.util.profiler.impl.ACProfilerImpl;

/**
 * Factory that returns correct instance of SAProfiler
 * 
 * @author a.lebedinskiy <a.lebedinskiy@sysiq.com>
 * 
 */
public final class ACProfilerFactory {
    protected static final String PROPERTIES = "com.ac.utils.profiler.profiler";
    protected static ACProfiler instance;

    private ACProfilerFactory() {
        // Utility class
    }

    public static ACProfiler getInstance() {
        if (instance == null) {
            Properties properties = ACPropertyLoaderFactory.getInstance().getProperties(PROPERTIES);
            String dummyprofiler = properties.getProperty("dummyprofiler", "true");
            if (BooleanUtils.toBoolean(dummyprofiler)) {
                instance = new ACProfilerDummyImpl();
            } else {
                instance = new ACProfilerImpl(properties);
            }
        }
        return instance;
    }
}
