package com.ac.util.profiler.impl;

import java.util.Properties;

import javax.servlet.ServletRequest;

import com.ac.util.profiler.ACProfileTree;
import com.ac.util.profiler.ACProfiler;

public class ACProfilerImpl implements ACProfiler {
    public static final String ATTRIBUTE_NAME = ACProfilerImpl.class.getCanonicalName();

    protected long threshold;

    public ACProfilerImpl(Properties properties) {
        String thresholdStr = properties.getProperty("threshold", "100");
        threshold = Long.parseLong(thresholdStr);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void start(String label, ServletRequest request) {
        getProfileTreeImpl(request).start(label);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isDummy() {
        return false;
    }

    private ACProfileTreeImpl getProfileTreeImpl(ServletRequest request) {
        ACProfileTreeImpl tree = (ACProfileTreeImpl) request.getAttribute(ATTRIBUTE_NAME);
        if (null == tree) {
            tree = new ACProfileTreeImpl(threshold);
            request.setAttribute(ATTRIBUTE_NAME, tree);
        }
        return tree;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void stop(String label, ServletRequest request) {
        getProfileTreeImpl(request).stop(label, null);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void stop(String label, String replaceToLabel, ServletRequest request) {
        getProfileTreeImpl(request).stop(label, replaceToLabel);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ACProfileTree getProfileTree(ServletRequest request) {
        return getProfileTreeImpl(request);
    }

}
