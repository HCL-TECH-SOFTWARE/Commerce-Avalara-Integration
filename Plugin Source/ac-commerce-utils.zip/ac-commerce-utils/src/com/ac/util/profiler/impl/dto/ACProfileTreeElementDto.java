package com.ac.util.profiler.impl.dto;

import java.util.ArrayList;
import java.util.List;

public class ACProfileTreeElementDto {
    private String label;
    private long begin;
    private long end;
    private final List<ACProfileTreeElementDto> children = new ArrayList<ACProfileTreeElementDto>();

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public long getBegin() {
        return begin;
    }

    public void setBegin(long begin) {
        this.begin = begin;
    }

    public long getEnd() {
        return end;
    }

    public void setEnd(long end) {
        this.end = end;
    }

    public List<ACProfileTreeElementDto> getChildren() {
        return children;
    }
}
