package com.ac.util.profiler;

import javax.servlet.ServletRequest;

/**
 * Interface that describes behavior of profiler
 * 
 * @author a.lebedinskiy <a.lebedinskiy@sysiq.com>
 * 
 */
public interface ACProfiler {
    public static final ACProfiler INSTANCE = ACProfilerFactory.getInstance();

    /**
     * Starts timer for defined label
     * 
     * @param label
     * @param request
     */
    void start(String label, ServletRequest request);

    /**
     * Stops timer for defined label
     * 
     * @param label
     * @param request
     */
    void stop(String label, ServletRequest request);

    /**
     * Stops timer for defined label and rename label
     * 
     * @param label
     * @replaceToLabel
     * @param request
     */
    void stop(String label, String replaceToLabel, ServletRequest request);

    /**
     * Returns profile tree
     * 
     * @param request
     * @return
     */
    ACProfileTree getProfileTree(ServletRequest request);

    /**
     * Returns true if instance is dummy
     * 
     * @return
     */
    boolean isDummy();

    public static class SIProfilerException extends Exception {

        public SIProfilerException() {
            super();
        }

        public SIProfilerException(String message, Throwable cause) {
            super(message, cause);
        }

        public SIProfilerException(String message) {
            super(message);
        }

        public SIProfilerException(Throwable cause) {
            super(cause);
        }
    }
}
