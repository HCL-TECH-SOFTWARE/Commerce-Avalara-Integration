package com.ac.util.profiler.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.logging.Logger;

import org.apache.commons.lang.StringUtils;

import com.ibm.commerce.foundation.common.util.logging.LoggingHelper;
import com.ac.util.profiler.ACProfileTree;
import com.ac.util.profiler.impl.dto.ACProfileTreeElementDto;

public class ACProfileTreeImpl implements ACProfileTree {
    private static final Logger LOGGER = LoggingHelper.getLogger(ACProfileTreeImpl.class);
    private final List<ACProfileTreeElementDto> rootElements = new ArrayList<ACProfileTreeElementDto>();
    private final Map<String, Stack<ACProfileTreeElementDto>> labelsStack = new HashMap<String, Stack<ACProfileTreeElementDto>>();
    private final Stack<ACProfileTreeElementDto> treeStack = new Stack<ACProfileTreeElementDto>();
    private final List<String> errors = new ArrayList<String>();
    protected long threshold;

    public ACProfileTreeImpl(long threshold) {
        this.threshold = threshold;
    }

    @Override
    public List<ACProfileTreeElementDto> getRoot() {
        return rootElements;
    }

    public void start(String label) {
        ACProfileTreeElementDto el = new ACProfileTreeElementDto();
        el.setLabel(label);
        el.setBegin(System.currentTimeMillis());

        if (0 == treeStack.size()) {
            rootElements.add(el);
        } else {
            ACProfileTreeElementDto parent = treeStack.peek();
            parent.getChildren().add(el);
        }
        treeStack.push(el);
        Stack<ACProfileTreeElementDto> stack = getStackByLabel(label);
        stack.push(el);
    }

    public void stop(String label, String replaceToLabel) {

        Stack<ACProfileTreeElementDto> stack = getStackByLabel(label);
        ACProfileTreeElementDto pop = stack.pop();
        String labelToShow = label;
        if (null != replaceToLabel) {
            labelToShow = replaceToLabel;
        }
        if (null != pop) {
            pop.setEnd(System.currentTimeMillis());
            long time = pop.getEnd() - pop.getBegin();
            if (time >= threshold) {
                LOGGER.info("Label '" + labelToShow + "' " + time + "ms");
            }
        } else {
            String error = "Label '" + label + "' has not been started";
            errors.add(error);
            LOGGER.severe(error);
        }

        ACProfileTreeElementDto popStack = treeStack.pop();
        if (null == popStack || !StringUtils.equals(label, popStack.getLabel())) {
            String error = "Label '" + label + "' should not be ended";
            errors.add(error);
            LOGGER.severe(error);
        }

        if (null != pop && null != replaceToLabel) {
            pop.setLabel(replaceToLabel);
        }

    }

    private Stack<ACProfileTreeElementDto> getStackByLabel(String label) {
        Stack<ACProfileTreeElementDto> stack = labelsStack.get(label);
        if (null == stack) {
            stack = new Stack<ACProfileTreeElementDto>();
            labelsStack.put(label, stack);
        }
        return stack;
    }
}
