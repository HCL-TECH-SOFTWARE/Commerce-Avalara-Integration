package com.ac.util;

import static java.lang.String.format;

import com.ac.util.function.Function;
import com.ac.util.property.Property;

/**
 * Represents value for {@link Option}
 * 
 * @author a.kudla
 * 
 * @param <T>
 */
public class Some<T> extends Option<T> {

    private T value;

    public Some(T value) {
        this.value = value;
    }

    @Override
    public boolean isDefined() {
        return true;
    }

    @Override
    public T get() {
        return value;
    }

    @Override
    public T getOrElse(T els) {
        return get();
    }

    @Override
    public String toString() {
        return format("Some(%s)", value);
    }

    @Override
    public <To> Option<To> map(Function<T, To> func) {
        return Option.of(func.apply(value));
    }

    @Override
    public <To> Option<To> map(Property<T, To> prop) {
        return map(prop.function());
    }
}
