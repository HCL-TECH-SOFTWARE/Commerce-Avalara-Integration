package com.ac.util.configuration;

import javax.annotation.Nonnull;

import org.apache.commons.lang.StringUtils;

import com.ac.util.Option;

public interface EnvironmentTypeConfiguration {

    public static final EnvironmentTypeConfiguration INSTANCE = new EnvironmentTypeConfigurationImpl();

    @Nonnull
    public Option<EnvironmentType> getEnvironmentType();

    public static enum EnvironmentType {
        DEVELOPER(""), QA_SERVER("qa"), QA_USA_SERVER("qausa"), DEV_SERVER("dev"), PRODUCTION_SERVER("prod"), STAGING_SERVER("staging"), TEST("test");
        private final String environmentTypeName;

        EnvironmentType(String name) {
            environmentTypeName = name;
        }

        public String getEnvironmentTypeName() {
            return environmentTypeName;
        }

        public static EnvironmentType getByEnvironmentTypeName(String environmentTypeName) {
            for (EnvironmentType type : values()) {
                if (StringUtils.equalsIgnoreCase(type.getEnvironmentTypeName(), environmentTypeName)) {
                    return type;
                }
            }
            return null;
        }
    }

}
