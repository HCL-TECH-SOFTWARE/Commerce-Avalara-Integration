package com.ac.util.configuration;

public interface WcServerCustomConfigConstants {
    String ENVIRONMENT_TYPE_CONFIGURATION = "EnvironmentTypeConfiguration";
    String URL_TAG_CONFIGURATION = "UrlTagConfiguration";
    String TARGET_SERVER_NAME = "TargetServerName";
}
