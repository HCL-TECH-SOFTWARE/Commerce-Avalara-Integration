package com.ac.util.configuration;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.ibm.commerce.foundation.common.util.logging.LoggingHelper;
import com.ibm.commerce.server.ServerConfiguration;
import com.ac.util.Option;
import com.ac.util.exception.ACRuntimeException;

public final class ACServerConfiguration {
    private static final Logger LOGGER = LoggingHelper.getLogger(ACServerConfiguration.class);

    public static class ConfigElement {

        private final boolean isDefined;
        private final Element element;

        public ConfigElement(Node node) {
            isDefined = node != null;
            element = (Element) node;
        }

        public boolean isDefined() {
            return isDefined;
        }

        @Nonnull
        public Option<String> getAttribute(String name) {
            String ret = isDefined() ? element.getAttribute(name) : null;
            return Option.of(ret);
        }

        public boolean getBooleanAttribute(String name) {
            Option<String> attribute = getAttribute(name);
            return attribute.isDefined() ? Boolean.parseBoolean(attribute.get()) : false;
        }

        public String getStringAttribute(String name) {
            Option<String> attribute = getAttribute(name);
            return attribute.isDefined() ? attribute.get() : StringUtils.EMPTY;
        }

        @Nonnull
        public Option<Element> getElement() {
            return Option.of(element);
        }

    }

    private ACServerConfiguration() {
        // Utility class
    }

    @Nonnull
    public static ConfigElement element(String nodeName) {
        try {
            return new ConfigElement(ServerConfiguration.singleton().getConfigCache(nodeName));
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Can not read configuration for environment type ", e);
            throw new ACRuntimeException("Can not read configuration for environment type ", e);
        }
    }
}
