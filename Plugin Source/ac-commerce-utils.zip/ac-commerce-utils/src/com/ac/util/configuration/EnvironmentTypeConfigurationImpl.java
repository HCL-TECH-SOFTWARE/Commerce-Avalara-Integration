package com.ac.util.configuration;

import static com.ac.util.Option.of;
import static com.ac.util.configuration.WcServerCustomConfigConstants.ENVIRONMENT_TYPE_CONFIGURATION;

import java.net.URL;
import java.util.logging.Logger;

import javax.annotation.Nonnull;

import com.ibm.commerce.foundation.common.util.logging.LoggingHelper;
import com.ac.util.Option;
import com.ac.util.exception.ACRuntimeException;

public class EnvironmentTypeConfigurationImpl implements EnvironmentTypeConfiguration {

    private static final String CONFIG_WC_SERVER_XML = "config/wc-server.xml";

    private static final Logger LOGGER = LoggingHelper.getLogger(EnvironmentTypeConfigurationImpl.class);

    private EnvironmentType envType = null;

    @Override
    @Nonnull
    public Option<EnvironmentType> getEnvironmentType() {
        if (envType == null) {
            EnvironmentType environmentType = null;
            Option<String> environmentTypeStr = ACServerConfiguration.element(ENVIRONMENT_TYPE_CONFIGURATION).getAttribute("type");
            if (environmentTypeStr.isDefined()) {
                environmentType = EnvironmentType.getByEnvironmentTypeName(environmentTypeStr.get());
                if (null == environmentType) {
                    LOGGER.severe("Environment type not found for " + environmentTypeStr);
                    throw new ACRuntimeException("Environment type not found for " + environmentTypeStr);
                }
                LOGGER.info("Found '" + environmentType.getEnvironmentTypeName() + "' environment type, used EnvironmentType."
                    + environmentType.name());
            }
            envType = environmentType;
        }
        return of(envType);
    }

    protected Option<String> getConfigFileName() {
        String filename = null;
        URL configFileURL = Thread.currentThread().getContextClassLoader().getResource(CONFIG_WC_SERVER_XML);
        if (configFileURL != null) {
            filename = configFileURL.getFile();
        }
        return of(filename);
    }

}
