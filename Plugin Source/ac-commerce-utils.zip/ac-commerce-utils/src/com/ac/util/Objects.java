package com.ac.util;

/**
 * Helper class for objects manipulation
 * 
 * @author a.kudla
 * 
 */
public final class Objects {

    private Objects() {
        // Utility class
    }

    public static <T> boolean in(T value, T... values) {
        for (T v : values) {
            if (eq(value, v)) {
                return true;
            }
        }
        return false;
    }

    public static boolean eq(Object value, Object v) {
        if (value == null && v == null) {
            return true;
        }
        if (value != null && value.equals(v)) {
            return true;
        }
        return false;
    }
}
