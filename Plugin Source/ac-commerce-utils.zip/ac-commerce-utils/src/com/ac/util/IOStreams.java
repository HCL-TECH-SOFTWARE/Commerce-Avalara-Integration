package com.ac.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.logging.Logger;

import javax.annotation.Nullable;

import com.ibm.commerce.foundation.common.util.logging.LoggingHelper;

/**
 * 
 * Helper for streams manipulation.
 * 
 * @author a.kudla
 * 
 */
public final class IOStreams {
    private static final Logger LOGGER = LoggingHelper.getLogger(IOStreams.class);

    private IOStreams() {
        // Utility class
    }

    /**
     * Safely close stream. Usually called from finally blocks.
     * 
     * @param is
     */
    public static void close(@Nullable InputStream is) {
        if (is != null) {
            try {
                is.close();
            } catch (IOException e) {
                LOGGER.severe("Error while closing " + is);
            }
        }
    }

    /**
     * Safely close stream. Usually called from finally blocks.
     * 
     * @param is
     */
    public static void close(@Nullable OutputStream os) {
        if (os != null) {
            try {
                os.close();
            } catch (IOException e) {
                LOGGER.severe("Error while closing " + os);
            }
        }
    }
}
