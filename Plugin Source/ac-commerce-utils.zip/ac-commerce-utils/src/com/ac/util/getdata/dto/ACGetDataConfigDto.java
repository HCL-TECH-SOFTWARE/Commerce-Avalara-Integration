package com.ac.util.getdata.dto;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ibm.commerce.foundation.common.datatypes.ContextDataType;
/**
 * This object used as configuration for {@link com.ac.util.ACGetDataService.ACGetDataService}
 * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
 *
 */
public class ACGetDataConfigDto {
    private String recordSetReferenceId;
    private String expression;
    private String expressionLanguage;
    private BigInteger recordSetStartNumber;
    private BigInteger maxItems;
    private String expressionBuilder;
    private final Map<String, String[]> parameters = new HashMap<String, String[]>();
    private final List<ContextDataType> contextData = new ArrayList<ContextDataType>();
    
    public List<ContextDataType> getContextData() {
        return contextData;
    }

    public Map<String, String[]> getParameters() {
        return parameters;
    }

    public String getExpression() {
        return expression;
    }

    public void setExpression(String expression) {
        this.expression = expression;
    }

    public String getExpressionLanguage() {
        return expressionLanguage;
    }

    public void setExpressionLanguage(String expressionLanguage) {
        this.expressionLanguage = expressionLanguage;
    }

    public String getExpressionBuilder() {
        return expressionBuilder;
    }

    public void setExpressionBuilder(String expressionBuilder) {
        this.expressionBuilder = expressionBuilder;
    }

    public BigInteger getRecordSetStartNumber() {
        return recordSetStartNumber;
    }

    public void setRecordSetStartNumber(BigInteger recordSetStartNumber) {
        this.recordSetStartNumber = recordSetStartNumber;
    }

    public BigInteger getMaxItems() {
        return maxItems;
    }

    public void setMaxItems(BigInteger maxItems) {
        this.maxItems = maxItems;
    }
    
    public String getRecordSetReferenceId() {
        return recordSetReferenceId;
    }

    public void setRecordSetReferenceId(String recordSetReferenceId) {
        this.recordSetReferenceId = recordSetReferenceId;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("SIGetDataConfigDto [recordSetReferenceId=");
        builder.append(recordSetReferenceId);
        builder.append(", expression=");
        builder.append(expression);
        builder.append(", expressionLanguage=");
        builder.append(expressionLanguage);
        builder.append(", recordSetStartNumber=");
        builder.append(recordSetStartNumber);
        builder.append(", maxItems=");
        builder.append(maxItems);
        builder.append(", expressionBuilder=");
        builder.append(expressionBuilder);
        builder.append(", parameters=");
        builder.append(parameters);
        builder.append(", contextData=");
        builder.append(contextData);
        builder.append("]");
        return builder.toString();
    }
}
