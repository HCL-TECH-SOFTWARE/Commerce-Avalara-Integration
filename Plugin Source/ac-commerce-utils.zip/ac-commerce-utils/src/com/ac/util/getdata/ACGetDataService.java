package com.ac.util.getdata;

import java.util.List;

import com.ibm.commerce.command.CommandContext;
import com.ac.commerce.util.ServiceHelper;
import com.ac.util.getdata.dto.ACGetDataConfigDto;

/**
 * Purpose of this service to retrieve data in java in the same way as it done on view layer
 * <pre>
 * On view layer
 * 
 * &lt;wcf:getData type=&quot;com.ibm.commerce.giftcenter.facade.datatypes.GiftListType[]&quot; var=&quot;shoppingLists&quot; expressionBuilder=&quot;findWishListsForUser&quot;&gt; 
 *   &lt;wcf:contextData name=&quot;storeId&quot; data=&quot;${storeId}&quot; /&gt;
 * &lt;/wcf:getData&gt;
 * </pre>
 * <pre>
 * In java
 * {@code
 * ACGetDataConfigDto config = new ACGetDataConfigDto();
 * ContextDataType store = CommerceFoundationFactory.eINSTANCE.createContextDataType();
 * store.setName("storeId");
 * store.setValue("10152");
 * config.getContextData().add(store);
 * config.setExpressionBuilder("findWishListsForUser");
 * List<GiftListType> data = ACGetDataService.EINSTANCE.getData(com.ibm.commerce.giftcenter.facade.datatypes.GiftListType.class, commandContext, config);
 * }
 * </pre>
 * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
 *
 */
public interface ACGetDataService {
    /**
     * Singleton instance of {@link ACGetDataService}
     */
    ACGetDataService EINSTANCE = ServiceHelper.getLoggingProxy(ACGetDataService.class, new ACGetDataServiceImpl());

    /**
     * Return data according to configuration object "config"
     * @param <T>
     * @param typeClass
     * @param commandContext
     * @param config
     * @return
     * @throws SIGetDataServiceException
     */
    <T> List<T> getData(Class<T> typeClass, CommandContext commandContext, ACGetDataConfigDto config) throws ACGetDataServiceException;


    /**
     * Exception for {@link ACGetDataService} methods Unique type of exception give us ability easy to determine class where
     * this exception were thrown Also there are sonar rule that do not allow throw java.lang.Exception
     * "Signature Declare Throws Exception method/constructor shouldn't explicitly throw java.lang.Exception" {@link https
     * ://dev.eclipse.org/sonar/rules/show/pmd:SignatureDeclareThrowsException?layout=false}
     * 
     * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
     * 
     */
    class ACGetDataServiceException extends Exception {

        public ACGetDataServiceException() {
            super();
        }

        public ACGetDataServiceException(String message, Throwable cause) {
            super(message, cause);
        }

        public ACGetDataServiceException(String message) {
            super(message);
        }

        public ACGetDataServiceException(Throwable cause) {
            super(cause);
        }
    }
}
