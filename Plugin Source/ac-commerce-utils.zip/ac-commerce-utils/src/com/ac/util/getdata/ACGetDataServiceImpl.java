package com.ac.util.getdata;

import java.io.File;
import java.io.Serializable;
import java.net.URL;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

import javax.security.auth.callback.CallbackHandler;

import org.apache.commons.lang.StringUtils;

import com.ibm.commerce.command.CommandContext;
import com.ibm.commerce.foundation.common.datatypes.BusinessContextType;
import com.ibm.commerce.foundation.internal.client.taglib.config.GetDataConfig;
import com.ibm.commerce.foundation.internal.common.security.auth.callback.handler.LocalComponentInvocationIdentityCallbackHandlerImpl;
import com.ibm.commerce.oagis9.datatypes.ExpressionType;
import com.ibm.commerce.oagis9.datatypes.GetType;
import com.ibm.commerce.oagis9.datatypes.Oagis9Factory;
import com.ac.commerce.util.logging.ACLogger;
import com.ac.util.cache.ACCache;
import com.ac.util.context.ACCommandContextHelper;
import com.ac.util.context.ACCommandContextHelper.ACCommandContextHelperException;
import com.ac.util.getdata.dto.ACGetDataConfigDto;

/**
 * Default implementation of {@link ACGetDataService}
 * 
 * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
 * 
 */
public class ACGetDataServiceImpl implements ACGetDataService {
    private static final String WEB_INF_CONFIG_FOLDER_PATH = "/WEB-INF/config";

    private static final ACLogger LOGGER = new ACLogger(ACGetDataServiceImpl.class);

    private GetDataConfig configuration = null;

    /**
     * {@inheritDoc}
     */
    @Override
    public <T> List<T> getData(Class<T> typeClass, CommandContext commandContext, ACGetDataConfigDto config)
        throws ACGetDataServiceException {
        String methodName = "getData(Class<T> typeClass, CommandContext commandContext, SIGetDataConfigDto config)";
        LOGGER.entering(methodName, typeClass, commandContext, config);
        List ret = new ArrayList();

        LOGGER.fine(methodName, "Start determination of component type");
        String componentType = null;
        if (typeClass.isArray()) {
            LOGGER.fine(methodName, "typeClass={0} is array type is {0}", typeClass);
            throw new ACGetDataServiceException("Component type should not be array");
        } else {
            componentType = typeClass.getCanonicalName();
        }
        LOGGER.fine(methodName, "component type is {0}", componentType);

        LOGGER.fine(methodName, "Start retrieving configuration");
        GetDataConfig configuration = getConfiguration();
        LOGGER.fine(methodName, "configuration={0}", configuration);

        GetDataConfig.DataTypeConfig dataTypeConfig = configuration.getDataTypeConfigByType(componentType);
        if (dataTypeConfig != null) {
            try {
                LOGGER.fine(methodName, "Start retrievin client facade");
                Object clientFacade = dataTypeConfig.createNewClientFacade(getBusinessContext(commandContext), getCallbackHandler());
                LOGGER.fine(methodName, "clientFacade={0}", clientFacade);

                ExpressionType expression = getExpression(config, dataTypeConfig);
                
                GetType getVerb = getGetType(config, expression);

                LOGGER.fine(methodName, "Retrieve data from ckientFacade '{0}' by verb '{1}'", clientFacade, getVerb);
                Object iDataArea = dataTypeConfig.invokeClientFacadeMethod(clientFacade, getVerb);
                LOGGER.fine(methodName, "Retrieved data is {0}", iDataArea);

                boolean singleObject = !(componentType.lastIndexOf('[') > -1);
                LOGGER.fine(methodName, "Return object is single ={0}", singleObject);

                if (singleObject) {
                    Object retObj = dataTypeConfig.getSingleResultFromDataArea(iDataArea);
                    LOGGER.fine(methodName, "Add return object to ret result {0}", retObj);
                    ret.add(retObj);
                }
                else {
                    Object[] arrayFromDataArea = dataTypeConfig.getArrayFromDataArea(iDataArea, componentType);
                    LOGGER.fine(methodName, "Add return object to ret result {0}", arrayFromDataArea);
                    ret.addAll(Arrays.asList(arrayFromDataArea));
                }

            } catch (ACGetDataServiceException e) {
                LOGGER.error(methodName, "", e);
                throw e;
            } catch (Exception e) {
                throw new ACGetDataServiceException(e);
            }
        } else {
            String msg = (new StringBuilder("No data-type definition found for ")).append(componentType).append(" in ")
                .append(configuration.getConfigFilename()).append(".").toString();
            throw new ACGetDataServiceException(msg);
        }

        LOGGER.exiting(methodName, ret);
        return ret;
    }

    /**
     * Generate GetType
     * @param config
     * @param expression
     * @return
     */
    protected GetType getGetType(ACGetDataConfigDto config, ExpressionType expression) {
        String methodName = "getGetType(ACGetDataConfigDto config, ExpressionType expression)";
        LOGGER.entering(methodName, config, expression);
        GetType getVerb = Oagis9Factory.eINSTANCE.createGetType();
        if (StringUtils.isNotEmpty(config.getRecordSetReferenceId())) {
            LOGGER.fine(methodName, "setRecordSetReferenceId with value={0}", config.getRecordSetReferenceId());
            getVerb.setRecordSetReferenceId(config.getRecordSetReferenceId());
        }

        if (null != config.getRecordSetStartNumber()) {
            LOGGER.fine(methodName, "setRecordSetStartNumber with value={0}", config.getRecordSetStartNumber());
            getVerb.setRecordSetStartNumber(config.getRecordSetStartNumber());
        }

        if (null != config.getMaxItems()) {
            LOGGER.fine(methodName, "setMaxItems with value={0}", config.getMaxItems());
            getVerb.setMaxItems(config.getMaxItems());
        }
            
        LOGGER.fine(methodName, "expression is  {0}", expression);
        getVerb.getExpression().add(expression);
        LOGGER.exiting(methodName, getVerb);
        return getVerb;
    }

    /**
     * Generate expression
     * @param config
     * @param dataTypeConfig
     * @return
     * @throws ACGetDataServiceException
     */
    protected ExpressionType getExpression(ACGetDataConfigDto config, GetDataConfig.DataTypeConfig dataTypeConfig)
        throws ACGetDataServiceException {
        String methodName = "getExpression(ACGetDataConfigDto config, GetDataConfig.DataTypeConfig dataTypeConfig)";
        LOGGER.entering(methodName, config, dataTypeConfig);
        ExpressionType expression = null;
        try {
            if (null != config.getExpressionBuilder()) {
                LOGGER.fine(methodName, "build expression by builder {0}", config.getExpressionBuilder());
                com.ibm.commerce.foundation.internal.client.taglib.config.GetDataConfig.ExpressionBuilderConfig expressionBuilderConfig = dataTypeConfig
                    .getExpressionBuilderConfig(config.getExpressionBuilder());
                if (expressionBuilderConfig == null) {
                    String msg = (new StringBuilder("No expression builder has been configured with the name: \""))
                        .append(config.getExpressionBuilder()).append("\".").toString();

                    throw new ACGetDataServiceException(msg);
                }
                expression = expressionBuilderConfig.buildExpression(config.getParameters());
            } else {
                expression = Oagis9Factory.eINSTANCE.createExpressionType();
                String expressionLanguage = config.getExpressionLanguage() != null ? config.getExpressionLanguage() : "_wcf:XPath";
                LOGGER.fine(methodName, "build expression by expression lang '{0}' and ", expressionLanguage, config.getExpression());
                expression.setExpressionLanguage(expressionLanguage);
                expression.setValue(config.getExpression());

            }
        } catch (Exception e) {
            throw new ACGetDataServiceException(e);
        }
        LOGGER.exiting(methodName, expression);
        return expression;
    }

    /**
     * Lazy load of configuration
     * 
     * @return
     * @throws ACGetDataServiceException
     */
    protected GetDataConfig getConfiguration() throws ACGetDataServiceException {
        String methodName = "getConfiguration()";
        LOGGER.entering(methodName);
        if (null == configuration) {
            LOGGER.fine(methodName, "configuration == null, Start load of configuration");
            configuration = loadConfiguration();
            LOGGER.fine(methodName, "Finished loading of configuration, configuration={0}", configuration);
        }
        LOGGER.exiting(methodName, configuration);
        return configuration;
    }

    /**
     * Load configuration
     * 
     * @return
     * @throws ACGetDataServiceException
     */
    protected GetDataConfig loadConfiguration() throws ACGetDataServiceException {
        String methodName = "loadConfiguration()";
        LOGGER.entering(methodName);
        LOGGER.fine(methodName, "Start retrieve of path for folder {0}", WEB_INF_CONFIG_FOLDER_PATH);
        URL resource = Thread.currentThread().getContextClassLoader().getResource(WEB_INF_CONFIG_FOLDER_PATH);
        LOGGER.fine(methodName, "Path for folder {0} is {1}", WEB_INF_CONFIG_FOLDER_PATH, resource);
        String file = resource.getFile();

        LOGGER.fine(methodName, "file = {0}", file);

        File configFolder = new File(file);
        LOGGER.fine(methodName, "configFolder = {0}", configFolder);

        File[] listFiles = configFolder.listFiles();
        LOGGER.fine(methodName, "listFiles = {0}", (Object) listFiles);
        Comparator<File> orderOfFileComparator = new SIGetDataServiceFileComparator();

        PriorityQueue<File> queue = new PriorityQueue<File>(listFiles.length, orderOfFileComparator);
        LOGGER.fine(methodName, "Start adding folder to PriorityQueue");
        for (File fileObj : listFiles) {
            if (fileObj.isDirectory()) {
                LOGGER.fine(methodName, "{0} is folder add it to queue", fileObj);
                queue.add(fileObj);
            } else {
                LOGGER.fine(methodName, "{0} is not folder so skip adding it to queue", fileObj);
            }
        }
        LOGGER.fine(methodName, "Finished adding folder to PriorityQueue, queue={0}", queue);
        GetDataConfig configuration = new GetDataConfig();
        LOGGER.fine(methodName, "Start load configuration from folders");
        while (queue.size() != 0) {
            File folder = queue.remove();
            try {
                LOGGER.fine(methodName, "Load configuration for folder ={0}", folder);
                configuration.setConfigRoot(folder);
                configuration.loadConfiguration();
                LOGGER.fine(methodName, "Configuration for folder ={0}", folder);
            } catch (Exception e) {
                LOGGER.error(methodName, MessageFormat.format("Exception during loading configuration for folder ={0}", folder), e);
                throw new ACGetDataServiceException(e);
            }
        }
        LOGGER.fine(methodName, "Finished load configuration from folders");
        LOGGER.exiting(methodName, configuration);
        return configuration;
    }

    /**
     * Convert command context to business context
     * 
     * @param commandContext
     * @return
     * @throws SICommandContextHelperException 
     */
    protected BusinessContextType getBusinessContext(CommandContext commandContext) throws ACCommandContextHelperException {
        String methodName = "getBusinessContext(CommandContext commandContext)";
        LOGGER.entering(methodName, commandContext);
        BusinessContextType businessContext = ACCommandContextHelper.EINSTANCE.convertToBusinessContext(commandContext);
        LOGGER.exiting(methodName, businessContext);
        return businessContext;
    }

    /**
     * Return Callback handler for facde client
     * 
     * @return
     */
    protected CallbackHandler getCallbackHandler() {
        String methodName = "getCallbackHandler()";
        LOGGER.entering(methodName);
        LocalComponentInvocationIdentityCallbackHandlerImpl callbackHandler = new LocalComponentInvocationIdentityCallbackHandlerImpl();
        LOGGER.exiting(methodName, callbackHandler);
        return callbackHandler;
    }

    /**
     * File comparator that helps to determine order of loading of config folders First of all should be loaded simple folders than that
     * folders that ends with "-fep" after that folders that ends with "-ext"
     * 
     * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
     * 
     */
    protected static class SIGetDataServiceFileComparator implements Comparator<File>, Serializable {
        private static final long serialVersionUID = 1L;
        private static final String EXT = "-ext/";
        private static final String FEP = "-fep/";

        @Override
        public int compare(File object1, File object2) {
            String methodName = "SIGetDataServiceFileComparator.compare(File object1, File object2)";
            LOGGER.entering(methodName, object1, object2);
            int ret = getPriority(object1).compareTo(getPriority(object2));
            LOGGER.exiting(methodName, ret);
            return ret;
        }

        protected Integer getPriority(File fileObj) {
            String methodName = "SIGetDataServiceFileComparator.getPriority(File fileObj)";
            LOGGER.entering(methodName, fileObj);
            Integer ret = 0;
            if (fileObj.getAbsolutePath().endsWith(FEP)) {
                LOGGER.fine(methodName, "{0} is ends with {1}", fileObj, FEP);
                ret = 1;
            } else if (fileObj.getAbsolutePath().endsWith(EXT)) {
                LOGGER.fine(methodName, "{0} is ends with {1}", fileObj, EXT);
                ret = 2;
            }
            LOGGER.exiting(methodName, ret);
            return ret;
        }

    }

}
