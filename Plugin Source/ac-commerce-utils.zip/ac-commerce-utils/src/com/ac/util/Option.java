package com.ac.util;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.ac.util.function.Function;
import com.ac.util.property.Property;

/**
 * Optional class to deal with null pointers in Java
 * 
 * @see http://download.java.net/jdk8/docs/api/java/util/Optional.html
 * @see http://docs.guava-libraries.googlecode.com/git/javadoc/index.html?com/google/common/base/Optional.html
 * @see http://en.wikipedia.org/wiki/Null_Object_pattern
 * @author a.kudla
 * @param <T>
 */
public abstract class Option<T> {

    @Nonnull
    public static <T> Option<T> of(@Nullable T obj) {
        if (obj == null) {
            return None.instance();
        }
        return new Some<T>(obj);
    }

    public T getOrElse(T els) {
        return els;
    }

    public abstract T get();

    public abstract boolean isDefined();

    public <To> Option<To> map(Function<T, To> func) {
        return None.instance();
    }

    public <To> Option<To> map(Property<T, To> prop) {
        return None.instance();
    }
}
