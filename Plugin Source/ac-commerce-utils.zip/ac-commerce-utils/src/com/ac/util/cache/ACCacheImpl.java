package com.ac.util.cache;

import com.ibm.websphere.cache.DistributedObjectCache;
/**
 * Default implementation of SICache
 * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
 *
 */
public class ACCacheImpl implements ACCache {
    private DistributedObjectCache map = null;
    
    public ACCacheImpl(DistributedObjectCache map) {
        super();
        this.map = map;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean containsKey(Object key) {
        return map.containsKey(key);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void put(Object key, Object value) {
        this.put(key, value, null);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void put(Object key, Object value, ACCacheEntryProperties properties) {
        ACCacheEntryProperties props = properties;
        if (null == props) {
            props = new ACCacheEntryProperties();
        }
        map.put(key, value, props.getPriority(), props.getTimeToLive(), props.getSharingPolicy(), props
            .getDependencyIds().toArray());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void clear() {
        map.clear();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object get(Object key) {
        return map.get(key);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void invalidate(Object key) {
        map.invalidate(key);
    }
}
