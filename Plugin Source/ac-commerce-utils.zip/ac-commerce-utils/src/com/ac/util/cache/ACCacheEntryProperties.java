package com.ac.util.cache;

import java.util.ArrayList;
import java.util.List;
import com.ibm.websphere.cache.EntryInfo;
import com.ibm.ws.cache.CacheConfig;

/**
 * Settings for cache entry that describe behavior of cache entry in cache
 * 
 * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
 *
 */
public class ACCacheEntryProperties {
    public static final  int DEFAULT_TTL = 36000;// 10h
    private int priority = CacheConfig.MAX_PRIORITY;
    
    private int timeToLive = DEFAULT_TTL;

    private int sharingPolicy = EntryInfo.NOT_SHARED;

    private final List<Object> dependencyIds = new ArrayList<Object>();

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public int getTimeToLive() {
        return timeToLive;
    }

    public void setTimeToLive(int timeToLive) {
        this.timeToLive = timeToLive;
    }

    public int getSharingPolicy() {
        return sharingPolicy;
    }

    public void setSharingPolicy(int sharingPolicy) {
        this.sharingPolicy = sharingPolicy;
    }

    public List<Object> getDependencyIds() {
        return dependencyIds;
    }

    @Override
    public String toString() {
        return "SICacheEntryProperties [priority=" + priority + ", timeToLive=" + timeToLive + ", sharingPolicy=" + sharingPolicy
            + ", dependencyIds=" + dependencyIds + "]";
    }
}
