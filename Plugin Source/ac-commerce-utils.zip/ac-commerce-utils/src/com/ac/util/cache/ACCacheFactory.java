package com.ac.util.cache;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

import com.ibm.websphere.cache.CacheEntry;
import com.ibm.websphere.cache.ChangeListener;
import com.ibm.websphere.cache.DistributedObjectCache;
import com.ibm.websphere.cache.InvalidationListener;
import com.ibm.websphere.cache.PreInvalidationListener;
import com.ibm.websphere.cache.exception.DynamicCacheException;
import com.ibm.wsspi.cache.DistributedObjectCacheFactory;
import com.ac.commerce.util.logging.ACLogger;

/**
 * 
 * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
 * 
 */
public final class ACCacheFactory {
    private static final ACLogger LOGGER = new ACLogger(ACCache.class);
    private static DistributedObjectCache dummyMap = null;
    private static final String BASE_CACHE = "baseCache";
    
    

    /**
     * Utility class constructor
     */
    private ACCacheFactory() {
        super();
    }

    /**
     * Return cache that used for servlets, it can be used and for objects too
     * 
     * @return
     */
    public static ACCache getBaseCache() {
        String methodName = "getBaseCache()";

        ACCache ret = getCacheByName(BASE_CACHE);

        LOGGER.exiting(methodName, ret);
        return ret;
    }

    /**
     * Return cache by name
     * 
     * @param cacheName
     * @return
     */
    public static ACCache getCacheByName(String cacheName) {
        String methodName = "getCacheByName(String cacheName)";
        ACCache ret = null;
        LOGGER.entering(methodName, cacheName);

        DistributedObjectCache map = DistributedObjectCacheFactory.getMap(cacheName);
        if (null == map) {
            LOGGER.fine(methodName, "DistributedObjectCache was not found for cache with name {0}, dummy map will be used", cacheName);
            map = getDummyMap();
        }

        ret = new ACCacheImpl(map);

        if (LOGGER.isInfoLoggable()) {
            LOGGER.fine(methodName, "wrap existing logger with logging wrapper");
            ret = new ACCacheLoggingWrapper(ret, LOGGER);
        }

        LOGGER.exiting(methodName, ret);
        return ret;
    }

    /**
     * Return dummy implementation of DistributedObjectCache
     * 
     * @return
     */
    protected static DistributedObjectCache getDummyMap() {
        if (null == dummyMap) {
            dummyMap = createDummyMap();
        }
        return dummyMap;
    }

    /**
     * Create dummy implementation of DistributedObjectCache
     * 
     * @return
     */
    protected static DistributedObjectCache createDummyMap() {
        return new DummyDistributedObjectCache();
    }

    /**
     * Dummy implementation of {@link DistributedObjectCache}}
     * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
     *
     */
    static class DummyDistributedObjectCache extends DistributedObjectCache {

        @Override
        public int getMapType() {
            return 0;
        }

        @Override
        public void addAlias(Object obj, Object[] aobj) {

        }

        @Override
        public boolean addChangeListener(ChangeListener changelistener) {
            return false;
        }

        @Override
        public boolean addInvalidationListener(InvalidationListener invalidationlistener) {
            return false;
        }

        @Override
        public boolean addPreInvalidationListener(PreInvalidationListener preinvalidationlistener) {
            return false;
        }

        @Override
        public void clear() {

        }

        @Override
        public boolean containsKey(Object obj, boolean flag) {
            return false;
        }

        @Override
        public boolean enableListener(boolean flag) {
            return false;
        }

        @Override
        public CacheEntry getCacheEntry(Object obj) {
            return null;
        }

        @Override
        public void invalidate(Object obj) {
        }

        @Override
        public void invalidate(Object obj, boolean flag) {

        }

        @Override
        public void invalidate(Object obj, boolean flag, boolean flag1) {
        }

        @Override
        public boolean isEmpty(boolean flag) {
            return false;
        }

        @Override
        public void put(Object obj, Object obj1, Object obj2, int i, int j, int k, Object[] aobj, Object[] aobj1) {
        }

        @Override
        public void put(Object obj, Object obj1, Object obj2, int i, int j, int k, int l, Object[] aobj, Object[] aobj1) {
        }

        @Override
        public void put(Object obj, Object obj1, Object obj2, int i, int j, int k, int l, Object[] aobj, Object[] aobj1, boolean flag)
            throws DynamicCacheException {

        }

        @Override
        public CacheEntry putAndGet(Object obj, Object obj1, Object obj2, int i, int j, int k, Object[] aobj, Object[] aobj1) {
            return null;
        }

        @Override
        public CacheEntry putAndGet(Object obj, Object obj1, Object obj2, int i, int j, int k, int l, Object[] aobj, Object[] aobj1) {
            return null;
        }

        @Override
        public void releaseLruEntries(int i) {
        }

        @Override
        public void removeAlias(Object obj) {
        }

        @Override
        public boolean removeChangeListener(ChangeListener changelistener) {
            return false;
        }

        @Override
        public boolean removeInvalidationListener(InvalidationListener invalidationlistener) {
            return false;
        }

        @Override
        public boolean removePreInvalidationListener(PreInvalidationListener preinvalidationlistener) {
            return false;
        }

        @Override
        public int size(boolean flag) {
            return 0;
        }

        @Override
        public Object get(Object obj) {
            return null;
        }

        @Override
        public int getSharingPolicy() {
            return 0;
        }

        @Override
        public boolean isDRSBootstrapEnabled() {
            return false;
        }

        @Override
        public Set keySet(boolean flag) {
            return null;
        }

        @Override
        public Object put(Object obj, Object obj1) {
            return null;
        }

        @Override
        public Object put(Object obj, Object obj1, int i, int j, int k, Object[] aobj) {
            return null;
        }

        @Override
        public Object put(Object obj, Object obj1, int i, int j, int k, int l, Object[] aobj) {
            return null;
        }

        @Override
        public void setDRSBootstrap(boolean flag) {

        }

        @Override
        public void setPriority(int i) {

        }

        @Override
        public void setSharingPolicy(int i) {

        }

        @Override
        public void setTimeToLive(int i) {

        }

        @Override
        public boolean containsKey(Object key) {
            return false;
        }

        @Override
        public boolean containsValue(Object value) {
            return false;
        }

        @Override
        public Set entrySet() {
            return null;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public Set keySet() {
            return null;
        }

        @Override
        public void putAll(Map map) {

        }

        @Override
        public Object remove(Object key) {
            return null;
        }

        @Override
        public int size() {
            return 0;
        }

        @Override
        public Collection values() {
            return null;
        }

    }
}
