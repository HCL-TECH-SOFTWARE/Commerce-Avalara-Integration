package com.ac.util.cache;

import java.io.Serializable;

import com.ac.commerce.util.logging.ACLogger;

/**
 * Logging wrapper for {@link ACCache}
 * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
 *
 */
public class ACCacheLoggingWrapper implements ACCache {
    private ACLogger logger = null;
    private ACCache delegate = null;
    
    /**
     * Logging wrapper implementation
     * 
     * @param delegate
     * @param logger
     */
    public ACCacheLoggingWrapper(ACCache delegate, ACLogger logger) {
        super();
        this.delegate = delegate;
        this.logger = logger;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public void clear() {
        String methodName = "clear()";
        logger.entering(methodName);
        
        delegate.clear();
        
        logger.exiting(methodName);
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public Object get(Object key) {
        String methodName = "get(Object key)";
        logger.entering(methodName, key);
        
        Object ret = delegate.get(key);
        
        logger.exiting(methodName, ret);
        return ret;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public void invalidate(Object key) {
        String methodName = "invalidate(Object key)";
        logger.entering(methodName, key);
        
        delegate.invalidate(key);
        
        logger.exiting(methodName);
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public boolean containsKey(Object key) {
        String methodName = "containsKey(Object key)";
        logger.entering(methodName, key);
        
        boolean ret = delegate.containsKey(key);
        
        logger.exiting(methodName, ret);
        return ret;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public void put(Object key, Object value) {
        String methodName = "put(Object key, Object value)";
        logger.entering(methodName, key, value);
        assertKeyAndValue(key, value);
        
        delegate.put(key, value);
        
        logger.exiting(methodName);
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public void put(Object key, Object value, ACCacheEntryProperties properties) {
        String methodName = "put(Object key, Object value, SICacheEntryProperties properties)";
        logger.entering(methodName, key, value, properties);
        assertKeyAndValue(key, value);
        
        delegate.put(key, value, properties);
        
        logger.exiting(methodName);
    }
    /**
     * Check key and value for null and Serializable
     * @param key
     * @param value
     */
    protected void assertKeyAndValue(Object key, Object value){
        if(null == key){
            logger.info("key should not be null");
        }else if(!(key instanceof Serializable)){
            logger.info("key should be instance of Serializable in case of using disk ofload feature");
        }
        
        if(null == value){
            logger.info("value should not be null");
        }else if(!(value instanceof Serializable)){
            logger.info("value should be instance of Serializable in case of using disk ofload feature");
        }
    }
    
}
