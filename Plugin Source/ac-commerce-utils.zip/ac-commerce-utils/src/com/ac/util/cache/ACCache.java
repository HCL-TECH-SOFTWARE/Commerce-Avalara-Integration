package com.ac.util.cache;

/**
 * Interface that describes behavior of cache
 * 
 * @author a.lebedinskiy <a.lebedinskiy@sysiq.com>
 * 
 */
public interface ACCache {
    /**
     * Clear entire cache
     */
    void clear();

    /**
     * Return cache value by key
     * 
     * @param key
     * @return
     */
    Object get(Object key);

    /**
     * invalidate - invalidates the given key. 
     * If the key is for a specific cache entry, then only that object is invalidated. 
     * If the key is for a dependency id, then all objects that share that dependency id will be invalidated.
     * 
     * @param key
     */
    void invalidate(Object key);

    /**
     * Return true if cache entry with defined key exists
     * 
     * @param key
     * @return
     */
    boolean containsKey(Object key);

    /**
     * Put to cache value with default properties
     * 
     * @param key
     * @param value
     */
    void put(Object key, Object value);

    /**
     * Put to cache value with defined properties
     * 
     * @param key
     * @param value
     * @param properties
     */
    void put(Object key, Object value, ACCacheEntryProperties properties);
}
