package com.ac.util;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * Helper class for tuples.
 * 
 * @author a.kudla
 * 
 */
public final class Tuples {
    private Tuples() {
        // Utility class
    }

    @Nonnull
    public static final <F, S, T> Tuple3<F, S, T> tuple3(F f, S s, T t) {
        return new Tuple3<F, S, T>(f, s, t);
    }

    @Nonnull
    public static final <F, S> Tuple<F, S> tuple(F f, S s) {
        return new Tuple<F, S>(f, s);
    }

    @Nonnull
    public static <K, V> Map<K, V> asMap(@Nullable Tuple<K, V>... tuples) {
        Map<K, V> ret = new HashMap<K, V>();
        if (tuples != null) {

            for (Tuple<K, V> tuple : tuples) {
                ret.put(tuple._1, tuple._2);
            }
        }
        return ret;
    }
}
