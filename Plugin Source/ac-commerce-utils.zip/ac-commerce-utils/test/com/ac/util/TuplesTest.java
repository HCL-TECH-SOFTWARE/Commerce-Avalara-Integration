package com.ac.util;

import static com.ac.util.Tuples.asMap;
import static com.ac.util.Tuples.tuple;
import static com.ac.util.Tuples.tuple3;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.junit.Test;

public class TuplesTest {

    private static final String FIRST = "first";
    private static final String SECOND = "second";
    private static final String THIRD = "third";

    @Test
    public void tupleTest() {
        Tuple<String, String> tuple = tuple(FIRST, SECOND);
        assertNotNull(tuple);
        assertEquals(FIRST, tuple._1);
        assertEquals(SECOND, tuple._2);
    }

    @Test
    public void tuple3Test() {
        Tuple3<String, String, String> tuple = tuple3(FIRST, SECOND, THIRD);
        assertNotNull(tuple);
        assertEquals(FIRST, tuple._1);
        assertEquals(SECOND, tuple._2);
        assertEquals(THIRD, tuple._3);
    }

    @Test
    public void asMapTest() {
        Tuple<String, String> tuple1 = tuple(FIRST, SECOND);
        Tuple<String, String> tuple2 = tuple(SECOND, THIRD);
        Map<Object, Object> empty = asMap();
        assertNotNull(empty);
        assertTrue(empty.isEmpty());
        Map<String, String> map = asMap(tuple1, tuple2);
        assertNotNull(map);
        assertNotNull(map);
        assertEquals(SECOND, map.get(FIRST));
        assertEquals(THIRD, map.get(SECOND));
    }
}
