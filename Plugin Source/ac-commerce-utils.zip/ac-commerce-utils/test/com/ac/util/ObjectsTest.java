/**
 * 
 */
package com.ac.util;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author a.kudla
 * 
 */
public class ObjectsTest {

    @Test
    public void testIn() {
        Assert.assertFalse(Objects.in(null, "a", "b", "c"));
        Assert.assertTrue(Objects.in(null, "a", "b", null));
        Assert.assertTrue(Objects.in("a", "a", "b", "c"));
        Assert.assertFalse(Objects.in("f", "a", "b", "c"));
    }
}
