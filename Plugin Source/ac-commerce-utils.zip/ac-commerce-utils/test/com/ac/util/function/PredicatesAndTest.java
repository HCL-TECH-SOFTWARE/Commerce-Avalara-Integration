/**
 * 
 */
package com.ac.util.function;

import junit.framework.Assert;

import org.junit.Test;

/**
 * @author a.kudla
 * 
 */
public class PredicatesAndTest {
    public static final String VALUE = "value";
    public static final String PREFIX1 = "val";
    public static final String PREFIX2 = "unk";

    @Test
    public void test() {
        Predicate<String> p1 = Predicates.eq(VALUE);
        Predicate<String> p2 = Predicates.startsWith(PREFIX1);
        Predicate<String> p3 = Predicates.and(p1, p2);
        Assert.assertEquals(p3.test(""), false);
        Assert.assertEquals(p3.test(null), false);
        Assert.assertEquals(p3.test(VALUE), true);
    }

}
