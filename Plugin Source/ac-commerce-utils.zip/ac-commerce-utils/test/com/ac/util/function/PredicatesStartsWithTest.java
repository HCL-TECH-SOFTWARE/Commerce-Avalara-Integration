/**
 * 
 */
package com.ac.util.function;

import junit.framework.Assert;

import org.junit.Test;

/**
 * @author a.kudla
 * 
 */
public class PredicatesStartsWithTest {
    public static final String VALUE = "value";
    public static final String PREFIX = "val";

    @Test
    public void testNull() {
        Predicate<String> p = Predicates.startsWith(null);
        Assert.assertEquals(p.test(""), false);
        Assert.assertEquals(p.test(null), false);
        Assert.assertEquals(p.test(VALUE), false);
    }

    @Test
    public void testEmpty() {
        Predicate<String> p = Predicates.startsWith("");
        Assert.assertEquals(p.test(""), true);
        Assert.assertEquals(p.test(null), false);
        Assert.assertEquals(p.test(VALUE), true);
    }

    @Test
    public void testSomeValue() {
        Predicate<String> p = Predicates.startsWith(VALUE);
        Assert.assertEquals(p.test(""), false);
        Assert.assertEquals(p.test(null), false);
        Assert.assertEquals(p.test(VALUE), true);
    }

    @Test
    public void testSomePrefix() {
        Predicate<String> p = Predicates.startsWith(PREFIX);
        Assert.assertEquals(p.test(""), false);
        Assert.assertEquals(p.test(null), false);
        Assert.assertEquals(p.test(VALUE), true);
    }
}
