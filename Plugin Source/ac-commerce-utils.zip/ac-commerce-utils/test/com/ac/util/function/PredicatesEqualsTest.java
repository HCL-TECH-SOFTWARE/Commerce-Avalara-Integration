/**
 * 
 */
package com.ac.util.function;

import junit.framework.Assert;

import org.junit.Test;

/**
 * @author a.kudla
 * 
 */
public class PredicatesEqualsTest {

    public static final String SOME_VALUE = "some_value";

    @Test
    public void testNull() {
        Predicate<String> p = Predicates.eq(null);
        Assert.assertEquals(p.test(""), false);
        Assert.assertEquals(p.test(null), true);
        Assert.assertEquals(p.test(SOME_VALUE), false);
    }

    @Test
    public void testEmpty() {
        Predicate<String> p = Predicates.eq("");
        Assert.assertEquals(p.test(""), true);
        Assert.assertEquals(p.test(null), false);
        Assert.assertEquals(p.test(SOME_VALUE), false);
    }

    @Test
    public void testSomeValue() {
        Predicate<String> p = Predicates.eq(SOME_VALUE);
        Assert.assertEquals(p.test(""), false);
        Assert.assertEquals(p.test(null), false);
        Assert.assertEquals(p.test(SOME_VALUE), true);
    }
}
