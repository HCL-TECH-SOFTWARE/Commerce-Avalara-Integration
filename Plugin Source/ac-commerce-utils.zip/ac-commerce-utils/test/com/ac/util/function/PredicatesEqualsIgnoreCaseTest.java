/**
 * 
 */
package com.ac.util.function;

import junit.framework.Assert;

import org.junit.Test;

/**
 * @author a.kudla
 * 
 */
public class PredicatesEqualsIgnoreCaseTest {

    public static final String VALUE = "value";
    public static final String VALUE1 = "value1";
    public static final String VALUE_UPPER = "VALUE";

    @Test
    public void testNull() {
        Predicate<String> p = Predicates.equalsIgnoreCase(null);
        Assert.assertEquals(p.test(""), false);
        Assert.assertEquals(p.test(null), true);
        Assert.assertEquals(p.test(VALUE), false);
    }

    @Test
    public void testEmpty() {
        Predicate<String> p = Predicates.equalsIgnoreCase("");
        Assert.assertEquals(p.test(""), true);
        Assert.assertEquals(p.test(null), false);
        Assert.assertEquals(p.test(VALUE), false);
    }

    @Test
    public void testSomeValue() {
        Predicate<String> p = Predicates.equalsIgnoreCase(VALUE);
        Assert.assertEquals(p.test(""), false);
        Assert.assertEquals(p.test(null), false);
        Assert.assertEquals(p.test(VALUE), true);
    }

    @Test
    public void testSomeValueUpper() {
        Predicate<String> p = Predicates.equalsIgnoreCase(VALUE);
        Assert.assertEquals(p.test(""), false);
        Assert.assertEquals(p.test(null), false);
        Assert.assertEquals(p.test(VALUE), true);
        Assert.assertEquals(p.test(VALUE_UPPER), true);
        Assert.assertEquals(p.test(VALUE1), false);
    }
}
