package com.ac.util.httprequest;

import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;
/**
 * 
 * @author a.lebedinskiy<a.lebedinskiy@sysiq.com>
 *
 */
public class ACHttpRequestUtilsTest {
    @Test
    public void testGetClientIpAddrWithNullParam(){
        Assert.assertEquals("",  ACHttpRequestUtils.EINSTANCE.getClientIpAddr(null));
    }
    
    @Test
    public void testGetClientIpAddrFromHeader(){
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        Mockito.when(request.getHeader("HTTP_X_FORWARDED_FOR")).thenReturn("192.168.1.1");
        Mockito.when(request.getRemoteAddr()).thenReturn("192.168.2.2");
        Assert.assertEquals("192.168.1.1",  ACHttpRequestUtils.EINSTANCE.getClientIpAddr(request));
    }
    
    @Test
    public void testGetClientIpAddrGetRemoteAddr(){
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        Mockito.when(request.getHeader("HTTP_X_FORWARDED_FORffff")).thenReturn("192.168.1.1");
        Mockito.when(request.getRemoteAddr()).thenReturn("192.168.2.2");
        Assert.assertEquals("192.168.2.2",  ACHttpRequestUtils.EINSTANCE.getClientIpAddr(request));
    }
}
