package com.ac.util;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.ac.util.function.Function;
import com.ac.util.property.StringProperty;

public class ListsTest {

    private static final String TEST3 = "test3";
    private static final String TEST2 = "test2";
    private static final String TEST1 = "test1";
    private static final List<String> LIST = java.util.Arrays.asList(TEST1, TEST2, TEST3);
    private static final List<String> LIST_UPPER = Arrays.asList("TEST1", "TEST2", "TEST3");
    private static final List<TestBean> LIST_BEAN = Arrays.asList(new TestBean(TEST1), new TestBean(TEST2), new TestBean(TEST3));

    private static final Function<String, String> UPPER_CASE_FN = new Function<String, String>() {

        @Override
        public String apply(String value) {
            return value.toUpperCase();
        }

    };

    static class TestBean {
        String value;

        public TestBean(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

    }

    private static final StringProperty<TestBean> VALUE_PROP = new StringProperty<ListsTest.TestBean>() {

        @Override
        protected String getVal(TestBean bean) {
            return bean.getValue();
        }
    };

    @Test
    public void toStringArrayNull() {
        String[] stringArray = Lists.toStringArray(null);
        assertNotNull(stringArray);
        assertEquals(0, stringArray.length);
    }

    @Test
    public void toStringArrayEmpty() {
        String[] stringArray = Lists.toStringArray(Lists.newArrayList());
        assertNotNull(stringArray);
        assertEquals(0, stringArray.length);
    }

    @Test
    public void toStringArray() {
        String[] expectedString = new String[] { "1", "2", "3" };
        Integer[] expectedInteger = new Integer[] { 1, 2, 3 };

        assertArrayEquals(expectedString, Lists.toStringArray(Arrays.asList(expectedString)));
        assertArrayEquals(expectedString, Lists.toStringArray(Arrays.asList(expectedInteger)));
    }

    @Test
    public void newArrayList() {
        Assert.assertEquals(0, Lists.newArrayList().size());
        Assert.assertEquals(2, Lists.newArrayList(TEST1, TEST2).size());
    }

    @Test
    public void headTest() {
        Assert.assertNull(Lists.head(null));
        Assert.assertNull(Lists.head(Collections.EMPTY_LIST));
        Assert.assertNotNull(Lists.head(java.util.Arrays.asList(TEST1)));
        Assert.assertEquals(TEST1, Lists.head(LIST));

        Assert.assertEquals(TEST1, Lists.head(null, TEST1));
        Assert.assertEquals(TEST1, Lists.head(Collections.EMPTY_LIST, TEST1));
        Assert.assertEquals(TEST1, Lists.head(LIST, TEST2));
    }

    @Test
    public void tailTest() {
        List<String> listTail = java.util.Arrays.asList(TEST2, TEST3);
        List<String> listTailTail = java.util.Arrays.asList(TEST3);
        Assert.assertNull(Lists.tail(null));
        Assert.assertNull(Lists.tail(Collections.EMPTY_LIST));
        Assert.assertNull(Lists.tail(listTailTail));
        Assert.assertEquals(TEST2, Lists.head(Lists.tail(LIST)));
        Assert.assertEquals(listTail, Lists.tail(LIST));
        Assert.assertEquals(TEST3, Lists.head(Lists.tail(Lists.tail(LIST))));
        Assert.assertEquals(listTailTail, Lists.tail(Lists.tail(LIST)));
        Assert.assertNull(Lists.tail(Lists.tail(Lists.tail(LIST))));
    }

    @Test
    public void nonNullTest() {
        Assert.assertNotNull(Lists.nonNull(null));
        Assert.assertEquals(LIST, Lists.nonNull(LIST));
    }

    @Test
    public void map() {
        Assert.assertTrue(Lists.map(null, UPPER_CASE_FN).isEmpty());
        Assert.assertTrue(Lists.map(LIST, (Function<String, String>) null).isEmpty());
        Assert.assertEquals(LIST_UPPER, Lists.map(LIST, UPPER_CASE_FN));

        Assert.assertEquals(LIST, Lists.map(LIST_BEAN, VALUE_PROP));
    }

}
