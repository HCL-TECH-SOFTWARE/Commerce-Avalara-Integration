/**
 * 
 */
package com.ac.util;

import static com.ac.util.Option.of;
import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;

import org.junit.Test;

import com.ac.util.property.StringProperty;

/**
 * @author a.kudla
 * 
 */
public class OptionTest {

    static class TestDTO {
        private final String name;
        private final String lastName;

        /**
         * @param name
         * @param lastName
         */
        public TestDTO(String name, String lastName) {
            super();
            this.name = name;
            this.lastName = lastName;
        }

        public String getName() {
            return name;
        }

        public String getLastName() {
            return lastName;
        }

    }

    public static final StringProperty<TestDTO> NAME = new StringProperty<OptionTest.TestDTO>() {

        @Override
        protected String getVal(TestDTO bean) {
            return bean.getName();
        }
    };

    @Test
    public void testFactoryMethod() {
        assertTrue(of(null) instanceof None);
        assertEquals(of(null).getOrElse("else"), "else");
        assertTrue(of("get") instanceof Some);
        assertEquals(of("get").getOrElse("else"), "get");
    }

    @Test
    public void testMap() {
        TestDTO data = new TestDTO("first", "last");
        assertTrue(of(data).map(NAME).isDefined());
        assertEquals(of(data).map(NAME).get(), "first");
    }
}
