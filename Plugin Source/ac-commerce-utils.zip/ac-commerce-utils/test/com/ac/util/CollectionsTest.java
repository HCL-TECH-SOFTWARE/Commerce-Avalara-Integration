/**
 * 
 */
package com.ac.util;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.ac.util.function.Predicate;

/**
 * @author a.kudla
 * 
 */
public class CollectionsTest {

    private final static Predicate<String> LENGTH_GREATER_2 = new Predicate<String>() {

        @Override
        public boolean test(String value) {
            return value.length() > 1;
        }
    };

    private final static Predicate<String> STARTS_WITH_A = new Predicate<String>() {

        @Override
        public boolean test(String value) {
            return value.startsWith("A");
        }
    };

    @Test
    public void testFilter() {
        List<String> list = Arrays.asList("A", "B", "C", "AA", "BB", "CC");
        Collections.filter(list, LENGTH_GREATER_2);
        Assert.assertEquals(3, list.size());
        Collections.filter(list, STARTS_WITH_A);
        Assert.assertEquals(1, list.size());
    }

    @Test
    public void isSizeEquals() throws Exception {
        List<String> c1 = Arrays.asList("a", "b");
        List<String> c2 = Arrays.asList("a", "b");
        List<String> c3 = Arrays.asList("a");
        List<String> c4 = null;
        List<String> c5 = null;

        assertTrue(Collections.isSizeEquals(c1, c2));
        assertFalse(Collections.isSizeEquals(c1, c3));
        assertFalse(Collections.isSizeEquals(c1, c4));
        assertFalse(Collections.isSizeEquals(c4, c5));
    }
}
