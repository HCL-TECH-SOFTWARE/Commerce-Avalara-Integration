/**
 * 
 */
package com.ac.commerce.objects.helpers;

import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import com.ibm.commerce.order.objects.OrderAccessBean;
import com.ac.commerce.objects.helpers.options.OrderAccessBeanOption;
import com.ac.commerce.test.category.IntegrationTest;

@Category(IntegrationTest.class)
public class OrderAccessBeansTest {

    @Test
    public void testOrderItems() {
        OrderAccessBeanOption bean = OrderAccessBeans.optionBean(new OrderAccessBean());
        Assert.assertTrue(bean.isObjectDefined());
        Assert.assertNull(bean.getOrderItems());
    }
}
