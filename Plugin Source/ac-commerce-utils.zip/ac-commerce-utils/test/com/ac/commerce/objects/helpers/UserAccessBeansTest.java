/**
 * 
 */
package com.ac.commerce.objects.helpers;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author a.kudla
 * 
 */
public class UserAccessBeansTest {

    @Test
    public void testNothingProxy() {
        Assert.assertFalse(UserAccessBeans.NOTHING_PROXY.isObjectDefined());
        Assert.assertNull(UserAccessBeans.NOTHING_PROXY.getDefinedBean());
        Assert.assertFalse(UserAccessBeans.NOTHING_PROXY.getRegisterType().isDefined());
    }
}
