/**
 * 
 */
package com.ac.commerce.objects.helpers;

import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import com.ibm.commerce.common.objects.StoreAccessBean;
import com.ac.commerce.objects.helpers.options.StoreAccessBeanOption;
import com.ac.commerce.test.category.IntegrationTest;

@Category(IntegrationTest.class)
public class OptionBeansTest {

    private static final String STORE_ID = "10651";
    private static final String FAKE_STORE_ID = "99999";
    private static final String DIRECTORY = "AuroraStorefrontAssetStore";

    @Test
    public void testValidStore() {
        StoreAccessBeanOption optionBean = StoreAccessBeans.optionBean(STORE_ID);
        StoreAccessBean bean = optionBean.getDefinedBean();
        Assert.assertTrue(optionBean.isObjectDefined());
        Assert.assertNotNull(bean);
        Assert.assertTrue(optionBean.getDirectory().isDefined());
        Assert.assertEquals(DIRECTORY, optionBean.getDirectory().get());
    }

    @Test
    public void testInvalidStore() {
        StoreAccessBeanOption optionBean = StoreAccessBeans.optionBean(FAKE_STORE_ID);
        StoreAccessBean bean = optionBean.getDefinedBean();
        Assert.assertFalse(optionBean.isObjectDefined());
        Assert.assertNull(bean);
        Assert.assertFalse(optionBean.getDirectory().isDefined());
    }
}
