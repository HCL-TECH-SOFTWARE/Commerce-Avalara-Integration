package com.ac.commerce.jobs;

import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.stub;
import static org.mockito.Mockito.when;

import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.ibm.commerce.command.ControllerCommand;
import com.ibm.commerce.datatype.TypedProperty;
import com.ac.commerce.util.configuration.ACPropertyLoader;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ ACJobLogger.class, ACPropertyLoader.class })
/**
 * This is a complex unit test to verify functionality of SIJobLogger class
 */
public class ACJobLoggerTest {

    @Test
    public void jobLoggerComplexTest() throws Exception {
        // Mock job logger parameters
        ControllerCommand cmd = mock(ControllerCommand.class);
        TypedProperty reqProperties = new TypedProperty();
        reqProperties.put("jobInstanceId", "1");
        stub(cmd.getRequestProperties()).toReturn(reqProperties);
        stub(cmd.getCommandName()).toReturn("TestCommandName");

        // Mock property loader
        ACPropertyLoader propLoader = mock(ACPropertyLoader.class);
        when(propLoader.getString(ACJobLogger.PROPERTIES_FILE, ACJobLogger.LOG_DIRECTORY)).thenReturn("");

        // Create job Logger spy
        ACJobLogger jobLogger = new ACJobLogger(ACJobLoggerTest.class, cmd.getCommandName());
        ACJobLogger jobLoggerSpy = PowerMockito.spy(jobLogger);
        Whitebox.setInternalState(ACJobLogger.class, "PROPERTY_LOADER", propLoader);

        // Mock journal logger
        Logger journalLogger = mock(Logger.class);
        Whitebox.setInternalState(jobLoggerSpy, "journalLogger", journalLogger);
        Whitebox.setInternalState(jobLoggerSpy, "journalFileHandler", mock(FileHandler.class));

        // Mock session logger
        Logger sessionLogger = mock(Logger.class);
        Whitebox.setInternalState(jobLoggerSpy, "sessionLogger", sessionLogger);
        Whitebox.setInternalState(jobLoggerSpy, "logger", sessionLogger);
        Whitebox.setInternalState(jobLoggerSpy, "sessionFileHandler", mock(FileHandler.class));
        // verify main methods of journal Logger
        jobLoggerSpy.journalBeginJob();
        Mockito.verify(journalLogger).info(Matchers.contains("JOB IS STARTED"));

        jobLoggerSpy.journalBeginProcessing("Some Text1");
        Mockito.verify(journalLogger).info(Matchers.contains("Begin processing"));

        jobLoggerSpy.journalInfo("Some Text3");
        Mockito.verify(journalLogger).info(Matchers.contains("Some Text3"));

        jobLoggerSpy.journalEndProcessing("Some Text2");
        Mockito.verify(journalLogger).info(Matchers.contains("Finished processing"));

        // verify main methods of session logger
        jobLoggerSpy.info("My session text");
        Mockito.verify(sessionLogger).log(eq(Level.INFO), Matchers.contains("My session text"), eq(new Object[] {}));

        Exception badException = new Exception("Bad exception");
        jobLoggerSpy.error("My exception", badException);
        Mockito.verify(sessionLogger).logp(eq(Level.SEVERE), anyString(), anyString(), eq("My exception"), eq(badException));

        // MUST BE AT THE END OF METHOD, it closed all logger handles
        jobLoggerSpy.journalEndJob();
        Mockito.verify(journalLogger).info(Matchers.contains("JOB IS FINISHED"));
    }
}
