package com.ac.commerce.util;

import static org.junit.Assert.assertEquals;

import java.util.Map;

import org.junit.Test;

import com.ibm.commerce.datatype.TypedProperty;

public class TypedPropertiesTest {

    @Test
    public void getMap() throws Exception {
        TypedProperty tp = new TypedProperty();
        tp.put("KEY1", new String[] { "VAL1", "VAL2" });
        tp.put("KEY2", new Object[] { "VAL3", "VAL4" });
        tp.put("KEY3", "VAL5");
        tp.putUrlParam("KEY4", "VAL6");

        Map<Object, Object> result = TypedProperties.getMap(tp);
        assertEquals(4, result.size());
        assertEquals("VAL1", result.get("KEY1"));
        assertEquals("VAL3", result.get("KEY2"));
        assertEquals("VAL5", result.get("KEY3"));
        assertEquals("VAL6", result.get("KEY4"));
    }

    @Test
    public void copy() throws Exception {
        TypedProperty tp = new TypedProperty();
        tp.put("KEY1", new String[] { "VAL1", "VAL2" });
        tp.put("KEY2", new Object[] { "VAL3", "VAL4" });
        tp.put("KEY3", "VAL5");
        tp.putUrlParam("KEY4", "VAL6");

        TypedProperty copy = TypedProperties.copy(tp);
        assertEquals(tp, copy);
    }
}