package com.ac.commerce.util;

import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import com.ac.commerce.test.category.IntegrationTest;

@Category(IntegrationTest.class)
public class ACCommerceUtilsTest {

    private final static String STORE_ID = "10651";
    private final static String MAIN_STORE_ID = "0";
    private final static String FAKE_STORE_ID = "-9999";

    @Test
    public void testGetStoreName() {
        Assert.assertNotNull(ACCommerceUtils.getStoreName(STORE_ID));
        Assert.assertNull(ACCommerceUtils.getStoreName(MAIN_STORE_ID));
        Assert.assertNull(ACCommerceUtils.getStoreName(FAKE_STORE_ID));
        Assert.assertNull(ACCommerceUtils.getStoreName(null));
    }
}
