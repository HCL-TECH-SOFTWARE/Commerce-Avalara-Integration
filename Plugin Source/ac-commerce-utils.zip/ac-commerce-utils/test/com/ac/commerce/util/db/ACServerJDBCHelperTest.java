/**
 * 
 */
package com.ac.commerce.util.db;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import com.ac.commerce.test.category.IntegrationTest;
import com.ac.util.Option;
import com.ac.util.function.Function;

/**
 * @author a.kudla
 * 
 */
@Category(IntegrationTest.class)
public class ACServerJDBCHelperTest {

    private static class StoreInfo {
        final Integer storeId;
        final String directory;

        /**
         * @param storeId
         * @param directory
         */
        public StoreInfo(Integer storeId, String directory) {
            super();
            this.storeId = storeId;
            this.directory = directory;
        }

        @Override
        public String toString() {
            return "StoreInfo [storeId=" + storeId + ", directory=" + directory + "]";
        }

    }

    @Test
    public void testSelectAggregate() {
        Option<Integer> storeCount = ACServerJDBCHelper.selectAggregate("Select count(*) from store ");
        Assert.assertTrue(storeCount.getOrElse(0) > 0);
    }

    @Test
    public void testQuery() {
        List<List> storeList = ACServerJDBCHelper.query("Select * from store ");
        Assert.assertTrue(storeList.size() > 0);
    }

    @Test
    public void testQueryWithParameters() {
        List<List> storeList = ACServerJDBCHelper.query("Select * from store where store_id=?", "0");
        Assert.assertTrue(storeList.size() == 1);
    }

    @Test
    public void testQueryWithMapper() {
        List<StoreInfo> storeList = ACServerJDBCHelper.query("Select store_id, directory from store ", new Function<List, StoreInfo>() {

            @Override
            public StoreInfo apply(List list) {
                return new StoreInfo((Integer) list.get(0), (String) list.get(1));
            }
        });
        Assert.assertTrue(storeList.size() > 0);
    }
}
