package com.ac.commerce.util.configuration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Locale;
import java.util.Properties;

import org.junit.Test;

public class ACPropertyLoaderFileImplTest {

    // on linux platform directory names are case sensitive
    private static final String MY_STORE = "mystore";
    private static final String BASE_PROPERTIES_FILE = "com.ac.commerce.util.configuration.test_file";
    private ACPropertyLoader propertyLoader = ACPropertyLoaderFactory.getInstance();

    @Test
    public void testGetPropertyFileWithStoreName() {
        String expected = "com.ac.commerce.util.configuration.Store.test_file";
        String actual = propertyLoader.getPropertyFileName(BASE_PROPERTIES_FILE, "Store");
        assertEquals(expected, actual);
    }

    @Test
    public void testGetPropertyFileWithStoreNameAndLocale() {
        String expected = "com.ac.commerce.util.configuration.Store.test_file_en_US";
        String actual = propertyLoader.getPropertyFileName(BASE_PROPERTIES_FILE, "Store", Locale.US);
        assertEquals(expected, actual);
    }

    @Test
    public void testGetStringWithStoreName() {
        String expected = "somevalue";
        String actual = propertyLoader.getString(BASE_PROPERTIES_FILE, MY_STORE, "somekey");
        assertEquals(expected, actual);
    }

    @Test
    public void testGetString() {
        String expected = "defaultval";
        String actual = propertyLoader.getString(BASE_PROPERTIES_FILE, null, "somekey");
        assertEquals(expected, actual);
    }

    @Test
    public void testGetBooleanWithStoreName() {
        assertTrue(propertyLoader.getBoolean(BASE_PROPERTIES_FILE, MY_STORE, "featureXEnabled"));
    }

    @Test
    public void testGetBoolean() {
        assertFalse(propertyLoader.getBoolean(BASE_PROPERTIES_FILE, null, "featureXEnabled"));
    }

    @Test
    public void testGetLocalizedMessage() {
        String expected = "somevalue 1";
        String actual = propertyLoader.getLocalizedMessage(BASE_PROPERTIES_FILE, MY_STORE, "somekey", Locale.GERMANY, "1");
        assertEquals(expected, actual);
    }

    @Test
    public void getProperties() throws Exception {
        String fileName = BASE_PROPERTIES_FILE;
        Properties properties = propertyLoader.getProperties(fileName);
        assertEquals("defaultval", properties.getProperty("somekey"));
        assertTrue(propertyLoader.getPropertiesCacheKeys().contains(fileName));
    }

    @Test
    public void getPropertiesForStore() throws Exception {
        String fileName = BASE_PROPERTIES_FILE;
        String expectedFileName = "com.ac.commerce.util.configuration.mystore.test_file";
        Properties properties = propertyLoader.getProperties(fileName, MY_STORE);
        assertEquals("somevalue", properties.getProperty("somekey"));
        assertTrue(propertyLoader.getPropertiesCacheKeys().contains(expectedFileName));
    }

    @Test
    public void getResourceBundle() throws Exception {
        String fileName = BASE_PROPERTIES_FILE;
        String expectedFileName = "com.ac.commerce.util.configuration.mystore.test_file";
        Properties props = propertyLoader.getProperties(fileName, MY_STORE);
        assertEquals("somevalue", props.getProperty("somekey"));
        assertTrue(propertyLoader.getPropertiesCacheKeys().contains(expectedFileName));
    }

    @Test
    public void getResourceBundleForLocale() throws Exception {
        String fileName = BASE_PROPERTIES_FILE;
        String expectedFileName = "com.ac.commerce.util.configuration.mystore.test_file_" + Locale.GERMANY;
        propertyLoader.getProperties(BASE_PROPERTIES_FILE, MY_STORE);
        Properties props = propertyLoader.getProperties(fileName, MY_STORE, Locale.GERMANY);
        assertEquals("somevalue {0}", props.getProperty("somekey"));
        assertTrue(propertyLoader.getPropertiesCacheKeys().contains(expectedFileName));
    }

    @Test
    public void clearCaches() throws Exception {
        propertyLoader.clearCaches();

        assertEquals(0, propertyLoader.getPropertiesCacheKeys().size());
        // upload property files in cache
        propertyLoader.getProperties(BASE_PROPERTIES_FILE);
        propertyLoader.getProperties(BASE_PROPERTIES_FILE, MY_STORE);
        propertyLoader.getProperties(BASE_PROPERTIES_FILE, MY_STORE, Locale.GERMANY);

        assertEquals(3, propertyLoader.getPropertiesCacheKeys().size());
    }

    @Test
    public void putNewPropertyAndUpdateExistingOneInCache() throws Exception {
        String cacheKey = "cacheKey";
        assertFalse(propertyLoader.getPropertiesCacheKeys().contains(cacheKey));
        boolean updated = propertyLoader.putPropertyToCache("key", "value1", cacheKey);
        assertFalse(updated);
        assertTrue(propertyLoader.getPropertiesCacheKeys().contains(cacheKey));
        assertEquals("value1", propertyLoader.getProperties(cacheKey).getProperty("key"));

        assertTrue(propertyLoader.getPropertiesCacheKeys().contains(cacheKey));
        updated = propertyLoader.putPropertyToCache("key", "new value", cacheKey);
        assertTrue(updated);
        assertTrue(propertyLoader.getPropertiesCacheKeys().contains(cacheKey));
        assertEquals("new value", propertyLoader.getProperties(cacheKey).getProperty("key"));
    }
}
